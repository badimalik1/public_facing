﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Core
{
    public enum OperatingUnitTypes
    {
        None, 
        Unknown,
        USOU06,
        NLOU01,
        UKOU03
    }
}

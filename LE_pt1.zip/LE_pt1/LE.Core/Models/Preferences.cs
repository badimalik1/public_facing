﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Core
{
    public class Preferences
    {
        public int Id { get; set; }
        public string StartYear { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string ForecastMonthPeriod { get; set; }
    }
}

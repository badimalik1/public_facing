﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Data.Interfaces
{
    public interface INaturalAccountData
    {
        IEnumerable<Account> GetAccountsBySupplierName(string supplierName);
        IEnumerable<Account> GetRentAccountsBySupplierName(string supplierName);
    }
}

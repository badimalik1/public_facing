using LE.Data;
using LE.Data.Implementations;
using LE.Data.Interfaces;
using LEWebApp.Controllers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Serialization;

namespace LEWebApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration, ILoggerFactory loggerFactory)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddDbContextPool<LEDbContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString("leDBConnectionString"));
            });

            services.AddScoped<ITargetedSupplierData, TargetedSupplierData>();
            services.AddScoped<ICurrentStartData, CurrentStartData>();
            services.AddScoped<IRentData, RentData>();
            services.AddScoped<ITaxData, TaxData>();
            services.AddScoped<IUserData, UserData>();
            services.AddSingleton<IAppData, AppData>();

            services.AddKendo();

            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.AddMvc().AddJsonOptions(o => {
                if (o.SerializerSettings.ContractResolver != null)
                {
                    var castedResolver = o.SerializerSettings.ContractResolver as DefaultContractResolver;
                    castedResolver.NamingStrategy = null;
                }
            });

            services.AddMvc().AddJsonOptions(
            options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);

            var serviceProvider = services.BuildServiceProvider();
            var logger = serviceProvider.GetService<ILogger<CurrentStartData>>();
            var currentStartControllerLogger = serviceProvider.GetService<ILogger<CurrentStartController>>();

            //loggerFactory.AddFile("Logs/mylog-{Date}.txt"); ILogger<CurrentStartController>
            services.AddSingleton(typeof(ILogger), logger);
            services.AddSingleton(typeof(ILogger), currentStartControllerLogger);

            services.AddLogging(config =>
            {
                config.AddDebug();
                config.AddConsole();
                config.AddFile("/Logs/orbitLog-{Date}.txt");
                //etc
            });
            services.AddTransient<Helpers.EmailHelper>();
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseMvc( routes =>
            {

                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            }
            );
        }
    }
}

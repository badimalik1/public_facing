﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Interfaces
{
    public interface IAppData
    {
        User GetUser();
        void SetUser(User user);

        string GetName();
        void SetName(string name);

        string GetSection();
        void SetSection(string section);

        int GetIdAtRow(string name);
        void SetCurrentAddId(int id);
        int GetDeleteId(string name);
        void SetDeleteKeyVal(string naturalAccountName, int id);

        bool GetPORequired();
        void SetPORequired(bool isRequired);

        string GetNaturalAccountLineItem();
        void SetNaturalAccountLineItem(string account);



        List<int> GetSuppliersKnown();
        List<int> GetSuppliersGileadWide();
        List<string> GetSupplierNames();
        List<string> GetNewSupplierNames();
        void SetSuppliersKnown(List<int> supplierIds);
        void SetSuppliersGilead(List<int> supplierIds);
        void SetSupplierNames(List<string> supplierNames);
        void SetNewSupplierNames(List<string> supplierNames);

        string GetCurrentSupplier();
        void SetSupplier(string supplier);


        IEnumerable<TargetedSupplier> GetNewSupplier();
        Task<string> GetCurrentDepartment();
        void SetDepartment(string department);

        Task<IEnumerable<int>> GetSupplierIds();

        User GetUser(string username, string password);
        ICollection<DepartmentString> GetDepartments(int userId);

        Task<object> SetApplicationData(string route, object postObj);
        void SetNewSupplier(string supplierName, string supplierDescription);


    }
}

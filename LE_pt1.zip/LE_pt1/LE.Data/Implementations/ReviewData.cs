﻿using LE.Core;
using LE.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LE.Data.Implementations
{
    
    public class ReviewData : IReviewData
    {
        private readonly LEDbContext _db;

        public ReviewData(LEDbContext db)
        {
            _db = db;
        }

        public IEnumerable<CurrentStart> ReadRentForecast(string dept)
        {
            var rents = _db.CurrentStarts
                .Where(a => a.DepartmentNameNum == dept)
                .Where(n => n.NaturalAccountName == "Building Lease Expense" || n.NaturalAccountName.Contains("Short-Term Lease") || n.NaturalAccountName.Contains("Lease Expense") &&
                            n.NaturalAccountName == "Variable Lease Cost for Building" || n.NaturalAccountName == "Lease Expense" || n.NaturalAccountName == "Immaterial Lease" &&
                            n.NaturalAccountName.Contains("Operating Lease Expense") || n.POLineDescription.Contains("Lease") || n.NaturalAccountName.Contains("Lease"))
                .Where(r => r.AccountNumber != 70205)
                .Where(s => s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                .Where(t => !t.POLineDescription.Contains("Tax") && !t.AccountGroup.Contains("Tax"))
                .OrderBy(a => a.SupplierName)
                .Skip(5000 * (0))
                .Take(5000)
                .ToList();

            return rents;
        }

    }
}

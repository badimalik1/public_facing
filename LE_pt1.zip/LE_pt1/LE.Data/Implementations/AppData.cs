﻿using LE.Core;
using LE.Data.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Implementations
{
    public class AppData : BaseDataImpl, IAppData
    {
        User _user { get; set; }
        string _currentDepartment { get; set; }
        public string CurrentDepartment
        {
            get { return _currentDepartment; }
            set { _currentDepartment = value; }
        }
        string _fullName { get; set; }
        string _section { get; set; }

        List<int> _suppliers { get; set; }

        List<int> _gileadSuppliers { get; set; }

        List<int> _supplierIds { get; set; }
        IList<TargetedSupplier> _newSuppliers { get; set; }

        List<string> _ForecastSupplierNames { get; set; }
        List<string> _NewForecastSupplierNames { get; set; }

        string _currentSupplier { get; set; }
        public string CurrentSupplier
        {
            get { return _currentSupplier; }
            set { _currentSupplier = value; }
        }

        public bool _poIsRequired { get; set; }

        HttpClient _httpClient;
        protected readonly LEDbContext _db;

        string _naturalAccountLineItem;

        int _currentAddId = 0;

        Dictionary<string, int> _row_id_dictionary;
        public string NaturalAccountLineItem
        {
            get { return _naturalAccountLineItem; }
            set { _naturalAccountLineItem = value; }
        }

        protected HttpClient CreateHttpClient()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            return _httpClient;
        }
        public int GetDeleteId(string name)
        {
            return _row_id_dictionary.GetValueOrDefault(name);

        }
        public void SetCurrentAddId(int id)
        {
            _currentAddId = id;
        }
        public void SetDeleteKeyVal(string name, int id)
        {
            if (_row_id_dictionary == null)
                _row_id_dictionary = new Dictionary<string, int>();

            _row_id_dictionary.Add(name, id);
        }

        public int GetIdAtRow(string name)
        {
            if (_row_id_dictionary == null || _row_id_dictionary.Count == 0)
                return -1;

            return _row_id_dictionary.GetValueOrDefault(name);
        }

        public string GetNaturalAccountLineItem()
        {
            return _naturalAccountLineItem;
        }
        public void SetNaturalAccountLineItem(string account)
        {
            _naturalAccountLineItem = account;
        }

        public async Task<IEnumerable<int>> GetSupplierIds()
        {
            using (_httpClient = CreateHttpClient())
            {
                //TODO: get from config
                _httpClient.BaseAddress = new Uri("https://localhost:44328/");//baseUri
                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var timeSpan = timeoutInSeconds >= 1 ? new TimeSpan(0, 0, timeoutInSeconds) : TimeSpan.FromSeconds(DEFAULT_TIMEOUT);
                _httpClient.Timeout = timeSpan;

                var request = new HttpRequestMessage(HttpMethod.Get, "api/app/GetSupplierIds");

                var uri = _httpClient.BaseAddress.ToString() + request.RequestUri;

                try
                {
                    var regResponse = await _httpClient.GetAsync(uri);

                    if (regResponse.IsSuccessStatusCode)
                    {
                        var regResponseString = await regResponse.Content.ReadAsStringAsync();
                        var ids = JsonConvert.DeserializeObject<IEnumerable<int>>(regResponseString);

                        return ids;
                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

                return null;

            }
        }

        public User GetUser()
        {
            return _user; // != null ? _user : ;
        }

        public void SetUser(User user)
        {

            _user = user;

            //await  Task.Run(async () =>
            //{

            //});

            // if (_user != null)
            //     await SetApplicationData("api/app/SetUser",  _user);

        }

        public string GetName()
        {
            return _fullName;
        }

        public void SetName(string name)
        {
            _fullName = name;
        }

        public string GetSection()
        {
            return _section;
        }

        public void SetSection(string section)
        {
            _section = section;
        }
        public async Task<string> GetCurrentDepartment()
        {
            // string route = "api/app/GetCurrentDepartment";

            // if(string.IsNullOrEmpty(_currentDepartment))
            //    _currentDepartment = await GetApplicationData(route);

            return _currentDepartment;
        }

        public void SetDepartment(string department)
        {
            _currentDepartment = department;
        }

        public string GetCurrentSupplier()
        {
            return _currentSupplier;
        }

        public void SetSupplier(string supplier)
        {
            _currentSupplier = supplier;
        }

        public List<int> GetSuppliersKnown()
        {
            return _suppliers;
        }
        public List<int> GetSuppliersGileadWide()
        {
            return _gileadSuppliers;
        }

        public IEnumerable<TargetedSupplier> GetNewSupplier()
        {
            return _newSuppliers;
        }
        public void SetSuppliersKnown(List<int> supplierIds)
        {
            if (_suppliers == null)
                _suppliers = new List<int>();

            supplierIds.ForEach(s => { _suppliers.Add(s); });

        }

        public void SetSuppliersGilead(List<int> supplierIds)
        {
            if (_gileadSuppliers == null)
                _gileadSuppliers = new List<int>();

            supplierIds.ForEach(s => { _gileadSuppliers.Add(s); });

        }
        public List<string> GetSupplierNames()
        {
            return _ForecastSupplierNames;
        }
        public void SetSupplierNames(List<string> supplierNames)
        {
            if (_ForecastSupplierNames == null)
                _ForecastSupplierNames = new List<string>();
            else if (_ForecastSupplierNames.Count() > 0)
                _ForecastSupplierNames.Clear();

            supplierNames.ForEach(n => { if (!_ForecastSupplierNames.Contains(n)) _ForecastSupplierNames.Add(n); });

        }

        public List<string> GetNewSupplierNames()
        {
            return _NewForecastSupplierNames;
        }

        public void SetNewSupplierNames(List<string> supplierNames)
        {

            if (_NewForecastSupplierNames == null)
                _NewForecastSupplierNames = new List<string>();
            else if (_NewForecastSupplierNames.Count() > 0)
                _NewForecastSupplierNames.Clear();

            supplierNames.ForEach(n => { if (!_NewForecastSupplierNames.Contains(n)) _NewForecastSupplierNames.Add(n); });
        }

        public void SetNewSupplier(string supplierName, string supplierDescription)
        {
            if (_newSuppliers == null)
                _newSuppliers = new List<TargetedSupplier>();

            var newSupplier = new TargetedSupplier()
            {
                SupplierName = supplierName
            };
            _newSuppliers.Add(newSupplier);
        }



        public User GetUser(string username, string password)
        {
            if (_user == null)
            {
                var user = _db.Users
                    .SingleOrDefault(u => u.Email == username && u.Password == password);

                //HACK: fix later
                //..var departments = _context.DepartmentStrings;
                var departmentNameNums = _db.DepartmentStrings
                                        .Select(d => _db.DepartmentStrings.Where(n => n.UserId == user.Id));

                user.Departments = new List<DepartmentString>();

                foreach (var dpt in departmentNameNums)
                {
                    foreach (var dp in dpt)
                    {
                        user.Departments.Add(dp);
                    }
                    break;
                }
                _user = user;
            }
            //await SetUser(_user);

            return _user;
        }
        public ICollection<DepartmentString> GetDepartments(int userId)
        {

            var depts = new List<DepartmentString>();

            var departmentNameNums = _db.DepartmentStrings
                                        .Select(d => _db.DepartmentStrings.Where(n => n.UserId == (_user != null ? _user.Id : userId)));

            foreach (var dpt in departmentNameNums)
            {
                foreach (var dp in dpt)
                {
                    depts.Add(dp);
                }
                break;
            }
            return depts;

        }

        private async Task<string> GetApplicationData(string route)
        {
            using (_httpClient = CreateHttpClient())
            {
                //TODO: get from config
                _httpClient.BaseAddress = new Uri("https://localhost:44328/");//baseUri
                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var timeSpan = timeoutInSeconds >= 1 ? new TimeSpan(0, 0, timeoutInSeconds) : TimeSpan.FromSeconds(DEFAULT_TIMEOUT);
                _httpClient.Timeout = timeSpan;

                var request = new HttpRequestMessage(HttpMethod.Get, route);

                var uri = _httpClient.BaseAddress.ToString() + request.RequestUri;

                try
                {
                    var regResponse = await _httpClient.GetAsync(uri);

                    if (regResponse.IsSuccessStatusCode)
                    {
                        var regResponseString = await regResponse.Content.ReadAsStringAsync();
                        var currDepartment = JsonConvert.DeserializeObject<string>(regResponseString);

                        return currDepartment;
                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

                return null;

            }
        }
        public bool GetPORequired()
        {
            return _poIsRequired;
        }

        public void SetPORequired(bool isRequired)
        {
            _poIsRequired = isRequired;
        }
        public async Task<object> SetApplicationData(string route, object postObj)
        {

            using (_httpClient = CreateHttpClient())
            {
                _httpClient.BaseAddress = new Uri("https://localhost:44328/"); //BaseUri

                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var rqst = new HttpRequestMessage(HttpMethod.Post, route);

                var uri = _httpClient.BaseAddress.ToString() + rqst.RequestUri;


                var content = new StringContent(JsonConvert.SerializeObject(postObj), Encoding.UTF8, "application/json");

                try
                {
                    return await PostAsync(_httpClient, uri, content);

                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Failed: " + ex.Message);
                }

                return null;
            }

        }


        private async Task<object> PostAsync(HttpClient client, string uri, StringContent content)
        {
            try
            {
                HttpResponseMessage response = await client.PostAsync(uri, content);

                if (response.IsSuccessStatusCode)
                {
                    var responseString = await response.Content.ReadAsStringAsync();
                    return responseString;
                }
                else
                {
                    Debug.WriteLine("Response Failed -- " + response.ReasonPhrase.ToString() + " :: " + response.StatusCode.ToString());
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            return null;
        }
    }
}

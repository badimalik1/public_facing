﻿using LE.Core;
using LE.Data;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class DropDownListController : Controller
    {
        private readonly IAppData _appData;
        private readonly ITargetedSupplierData _targetedData;
        private readonly IGileadWideSupplierData _gileadWideData;
        public List<TargetedSupplier> TargetedSuppliers { get; set; }
        public List<GileadWideSupplier> GileadWideSuppliers { get; set; }

        public DropDownListController(IAppData appData, ITargetedSupplierData targetedData, IGileadWideSupplierData gileadWideData)
        {
            _appData = appData;
            _targetedData = targetedData;
            _gileadWideData = gileadWideData;

            TargetedSuppliers = new List<TargetedSupplier>();
            GileadWideSuppliers = new List<GileadWideSupplier>();
        }
        public IActionResult Index()
        {
            return View();
        }

        public async Task<JsonResult> RemoteDataSource_GetSuppliers(string text)
        {

            var supplierids = _appData.GetSuppliersKnown();
            var gileadWideSupplierids = _appData.GetSuppliersGileadWide();

            if (supplierids != null)
            {
                foreach (var id in supplierids)
                {
                    var supplier = await _targetedData.GetById(id);
                    TargetedSuppliers.Add(supplier);
                }
            }

            if (gileadWideSupplierids != null)
            {
                foreach (var id in gileadWideSupplierids)
                {
                    var supplier = await _gileadWideData.GetById(id);
                    GileadWideSuppliers.Add(supplier);
                }
            }
            //map to suppliers view model

            var supplierList = TargetedSuppliers.Select(supplier => new SupplierViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                FiscalYear1 = 0,
                FiscalYear2 = 0,
                FiscalYear3 = 0,
                FiscalYear4 = 0
            });


            var gSupplierList = GileadWideSuppliers.Select(supplier => new SupplierViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                FiscalYear1 = 0,
                FiscalYear2 = 0,
                FiscalYear3 = 0,
                FiscalYear4 = 0
            });

            if (supplierList.Count() > 0)
            {
                List<string> newSupplierList = new List<string>();
                supplierList.ToList().ForEach(n => { newSupplierList.Add(n.SupplierName); });

                if (newSupplierList.Count > 0)
                    _appData.SetNewSupplierNames(newSupplierList);
            }

            if (gSupplierList.Count() > 0)
            {
                List<string> newSupplierList = new List<string>();
                gSupplierList.ToList().ForEach(n => { newSupplierList.Add(n.SupplierName); });

                if (newSupplierList.Count > 0)
                    _appData.SetNewSupplierNames(newSupplierList);
            }


            var finalSupplierList = supplierList.Union(gSupplierList).ToList();

            return new JsonResult(finalSupplierList);

            //return Json(TargetedSuppliers.ToList());
        }

    }
}

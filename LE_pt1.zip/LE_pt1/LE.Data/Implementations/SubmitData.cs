﻿using LE.Core;
using LE.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LE.Data.Implementations
{
    public class SubmitData : ISubmitData
    {
        private readonly LEDbContext _db;

        public SubmitData(LEDbContext db)
        {
            _db = db;
        }
        public IEnumerable<CurrentStart> GetCurrentStarts(string dept)
        {
            var currentStarts = _db.CurrentStarts
                .Where(a => a.DepartmentNameNum == dept)
                .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits" && a.AccountGroup != "AC_72000-Deprecation & Amortization" &&
                            a.AccountGroup != "AC_73000-Other General Expense" && a.AccountGroup != "AC_68000-Promotional Programs" &&
                            a.AccountGroup != "AC_63000-Training & Education" && a.AccountGroup != "AC_67000-Grants & Medical Education" &&
                            a.AccountGroup != "AC_66000-Insurance")
                .Where(n => n.NaturalAccountName != "Airfare" && !n.NaturalAccountName.StartsWith("Meals & Entertainment") && !n.NaturalAccountName.StartsWith("Other Travel & Lodging") &&
                            n.NaturalAccountName != "Business Gifts" && n.NaturalAccountName != "Employee Relations 1")
                .Where(s => s.SupplierName != "No Supplier Name" && s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                .Where(r => r.AccountNumber != 70015 && r.AccountNumber != 70020 &&
                           r.AccountNumber != 70025 && r.AccountNumber != 70205 &&
                           r.AccountNumber != 70065 && r.AccountNumber != 70070)
                .OrderBy(a => a.SupplierName)
                .Skip(5000 * 0)
                .Take(5000)
                .ToList();

            return currentStarts;
        }

        public IEnumerable<PriorForecast> ReadPriorForecastRents(string dept)
        {
            var priorForcasts = _db.PriorForecasts
                .Where(a => a.DepartmentNameNum == dept)
                .Where(n => n.NaturalAccountName == "Building Lease Expense" || n.NaturalAccountName.Contains("Short-Term Lease") || n.NaturalAccountName.Contains("Lease Expense") &&
                            n.NaturalAccountName == "Variable Lease Cost for Building" || n.NaturalAccountName == "Lease Expense" || n.NaturalAccountName == "Immaterial Lease" &&
                            n.NaturalAccountName.Contains("Operating Lease Expense") || n.POLineDescription.Contains("Lease") || n.NaturalAccountName.Contains("Lease"))
                .Where(r => r.AccountNumber != 70205)
                .Where(s => s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                .Where(t => !t.POLineDescription.Contains("Tax") && !t.AccountGroup.Contains("Tax"))
                .OrderBy(a => a.SupplierName)
                .Skip(5000 * (0))
                .Take(5000)
                .ToList();

            return priorForcasts;
        }
    }
}

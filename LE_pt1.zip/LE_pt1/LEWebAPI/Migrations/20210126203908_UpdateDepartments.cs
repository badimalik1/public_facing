﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace LEWebAPI.Migrations
{
    public partial class UpdateDepartments : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Accounts",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccountName = table.Column<string>(nullable: true),
                    AccountGroup = table.Column<string>(nullable: true),
                    AccountNum = table.Column<int>(nullable: false),
                    NaturalAccountName = table.Column<string>(nullable: true),
                    Controllable = table.Column<string>(nullable: true),
                    Discretionary = table.Column<string>(nullable: true),
                    ForecastScheme_1 = table.Column<string>(nullable: true),
                    ForecastScheme_2 = table.Column<string>(nullable: true),
                    ForecastScheme_3 = table.Column<string>(nullable: true),
                    ForecastScheme_4 = table.Column<string>(nullable: true),
                    ForecastScheme_5 = table.Column<string>(nullable: true),
                    ForecastScheme_6 = table.Column<string>(nullable: true),
                    ForecastScheme_7 = table.Column<string>(nullable: true),
                    ForecastScheme_8 = table.Column<string>(nullable: true),
                    ForecastScheme_9 = table.Column<string>(nullable: true),
                    ForecastScheme_10 = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Accounts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CurrentStarts",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ProjectName = table.Column<string>(nullable: true),
                    Scenario = table.Column<string>(nullable: true),
                    POLineDescriipiion = table.Column<string>(nullable: true),
                    DepartmentNameNum = table.Column<string>(nullable: true),
                    BudgetUSD_1 = table.Column<decimal>(nullable: false),
                    BudgetLC_1 = table.Column<decimal>(nullable: false),
                    Comments = table.Column<string>(nullable: true),
                    FiscalPeriod = table.Column<string>(nullable: true),
                    DepartmentName = table.Column<string>(nullable: true),
                    DepartmentNumber = table.Column<string>(nullable: true),
                    DepartmentGroup = table.Column<string>(nullable: true),
                    DepartmentSubGroup = table.Column<string>(nullable: true),
                    CostCenterNumber = table.Column<string>(nullable: true),
                    FiscalYear = table.Column<string>(nullable: true),
                    FiscalQuarter = table.Column<string>(nullable: true),
                    AccountGroup = table.Column<string>(nullable: true),
                    NaturalAccountName = table.Column<string>(nullable: true),
                    ProjectTaskNumber = table.Column<string>(nullable: true),
                    PONumber = table.Column<string>(nullable: true),
                    SupplierName = table.Column<string>(nullable: true),
                    SupplierNumber = table.Column<string>(nullable: true),
                    PurchaseInvoiceNumber = table.Column<string>(nullable: true),
                    ActualUSD = table.Column<decimal>(nullable: false),
                    ActualLC = table.Column<decimal>(nullable: false),
                    CountryCity = table.Column<string>(nullable: true),
                    Region = table.Column<string>(nullable: true),
                    Region_Rpt = table.Column<string>(nullable: true),
                    FPAAccrualsReclasses = table.Column<string>(nullable: true),
                    SupplierType = table.Column<string>(nullable: true),
                    FiscalDate = table.Column<string>(nullable: true),
                    LocalCurrency = table.Column<string>(nullable: true),
                    BudgetUSD = table.Column<decimal>(nullable: false),
                    BudgetLC = table.Column<decimal>(nullable: false),
                    OriginalSupplierName = table.Column<string>(nullable: true),
                    DepartmentRollOut = table.Column<string>(nullable: true),
                    UniqueListACC = table.Column<string>(nullable: true),
                    UniqueListDEPT = table.Column<string>(nullable: true),
                    TotalUSD = table.Column<decimal>(nullable: false),
                    TotalLC = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CurrentStarts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DepartmentNameNum = table.Column<string>(nullable: true),
                    CostCenter = table.Column<string>(nullable: true),
                    CostCenterName = table.Column<string>(nullable: true),
                    LE = table.Column<string>(nullable: true),
                    DP_Department = table.Column<string>(nullable: true),
                    DepartmentRollOut = table.Column<string>(nullable: true),
                    DepartmentGroup = table.Column<string>(nullable: true),
                    DepartmentName = table.Column<string>(nullable: true),
                    DepartmentSubGroup = table.Column<string>(nullable: true),
                    SupplierIDBudgetLogic = table.Column<string>(nullable: true),
                    Region = table.Column<string>(nullable: true),
                    Region_Rpt = table.Column<string>(nullable: true),
                    LocalCurrency = table.Column<string>(nullable: true),
                    LegalEntity = table.Column<string>(nullable: true),
                    LocationNumber = table.Column<string>(nullable: true),
                    CountryGEO = table.Column<string>(nullable: true),
                    CityGEO = table.Column<string>(nullable: true),
                    LatitudeGEO = table.Column<string>(nullable: true),
                    Longitude = table.Column<string>(nullable: true),
                    FMOpsSubGroup = table.Column<string>(nullable: true),
                    ForecastTE = table.Column<string>(nullable: true),
                    ForecastMS = table.Column<string>(nullable: true),
                    ForecastScheme = table.Column<string>(nullable: true),
                    FreeFormSupplier = table.Column<string>(nullable: true),
                    ForecastOwner = table.Column<string>(nullable: true),
                    ForecastOwnerSecondary = table.Column<string>(nullable: true),
                    ForecastReviewer = table.Column<string>(nullable: true),
                    ForecastReviewerFinal = table.Column<string>(nullable: true),
                    FPA_One = table.Column<string>(nullable: true),
                    FPA_Two = table.Column<string>(nullable: true),
                    FPA_Three = table.Column<string>(nullable: true),
                    FPA_Four = table.Column<string>(nullable: true),
                    FPA_Five = table.Column<string>(nullable: true),
                    DepartmentNumber_Num = table.Column<long>(nullable: false),
                    DepartmentNumber_Str = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "GileadWideSuppliers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SupplierNumber = table.Column<int>(nullable: false),
                    SupplierName = table.Column<string>(nullable: true),
                    SupplierCreationDate = table.Column<DateTime>(nullable: false),
                    SupplierParentName = table.Column<string>(nullable: true),
                    OperatingUnit = table.Column<string>(nullable: true),
                    OperatingUnitCountry = table.Column<string>(nullable: true),
                    SupplierCountry = table.Column<string>(nullable: true),
                    SupplierCountryName = table.Column<string>(nullable: true),
                    SupplierRegInitiatorDeptID = table.Column<int>(nullable: false),
                    SupplierRegApproverDeptID = table.Column<int>(nullable: false),
                    SupplierType = table.Column<string>(nullable: true),
                    SupplierInvoiceCurrency = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GileadWideSuppliers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "POs",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DepartmentID = table.Column<string>(nullable: true),
                    DepartmentLevel4Name = table.Column<string>(nullable: true),
                    DepartmentLevel8Name = table.Column<string>(nullable: true),
                    NaturalAccount = table.Column<int>(nullable: false),
                    NaturalAccountName = table.Column<string>(nullable: true),
                    POLineDescription = table.Column<string>(nullable: true),
                    PONumber = table.Column<string>(nullable: true),
                    SupplierName = table.Column<string>(nullable: true),
                    POApprovedDateYR = table.Column<int>(nullable: false),
                    POApprovedDateMN = table.Column<int>(nullable: false),
                    POLastUpdateDateYR = table.Column<int>(nullable: false),
                    POLastUpdateDateMN = table.Column<int>(nullable: false),
                    POAmountBilled = table.Column<decimal>(nullable: false),
                    POAmountCancelled = table.Column<decimal>(nullable: false),
                    POAmountOpen = table.Column<decimal>(nullable: false),
                    POAmountOrdered = table.Column<decimal>(nullable: false),
                    POAmountReceived = table.Column<decimal>(nullable: false),
                    PONetAmountOrdered = table.Column<decimal>(nullable: false),
                    Remaining = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_POs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PriorForecasts",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ProjectName = table.Column<string>(nullable: true),
                    Scenario = table.Column<string>(nullable: true),
                    POLineDescriipiion = table.Column<string>(nullable: true),
                    DepartmentNameNum = table.Column<string>(nullable: true),
                    BudgetUSD_1 = table.Column<decimal>(nullable: false),
                    BudgetLC_1 = table.Column<decimal>(nullable: false),
                    Comments = table.Column<string>(nullable: true),
                    FiscalPeriod = table.Column<string>(nullable: true),
                    DepartmentName = table.Column<string>(nullable: true),
                    DepartmentNumber = table.Column<string>(nullable: true),
                    DepartmentGroup = table.Column<string>(nullable: true),
                    DepartmentSubGroup = table.Column<string>(nullable: true),
                    CostCenterNumber = table.Column<string>(nullable: true),
                    FiscalYear = table.Column<string>(nullable: true),
                    FiscalQuarter = table.Column<string>(nullable: true),
                    AccountGroup = table.Column<string>(nullable: true),
                    NaturalAccountName = table.Column<string>(nullable: true),
                    ProjectTaskNumber = table.Column<string>(nullable: true),
                    PONumber = table.Column<string>(nullable: true),
                    SupplierName = table.Column<string>(nullable: true),
                    SupplierNumber = table.Column<string>(nullable: true),
                    PurchaseInvoiceNumber = table.Column<string>(nullable: true),
                    ActualUSD = table.Column<decimal>(nullable: false),
                    ActualLC = table.Column<decimal>(nullable: false),
                    CountryCity = table.Column<string>(nullable: true),
                    Region = table.Column<string>(nullable: true),
                    Region_Rpt = table.Column<string>(nullable: true),
                    FPAAccrualsReclasses = table.Column<string>(nullable: true),
                    SupplierType = table.Column<string>(nullable: true),
                    FiscalDate = table.Column<string>(nullable: true),
                    LocalCurrency = table.Column<string>(nullable: true),
                    BudgetUSD = table.Column<decimal>(nullable: false),
                    BudgetLC = table.Column<decimal>(nullable: false),
                    OriginalSupplierName = table.Column<string>(nullable: true),
                    DepartmentRollOut = table.Column<string>(nullable: true),
                    UniqueListACC = table.Column<string>(nullable: true),
                    UniqueListDEPT = table.Column<string>(nullable: true),
                    TotalUSD = table.Column<decimal>(nullable: false),
                    TotalLC = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PriorForecasts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TargetedSuppliers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SupplierNumber = table.Column<int>(nullable: false),
                    SupplierName = table.Column<string>(nullable: true),
                    SupplierParentName = table.Column<string>(nullable: true),
                    DepartmentID = table.Column<string>(nullable: true),
                    SupplierInactiveDate = table.Column<string>(nullable: true),
                    DepartmentOwner = table.Column<string>(nullable: true),
                    DepartmentLevel2Name = table.Column<string>(nullable: true),
                    DepartmentLevel3Name = table.Column<string>(nullable: true),
                    DepartmentLevel4Name = table.Column<string>(nullable: true),
                    DepartmentLevel5Name = table.Column<string>(nullable: true),
                    DepartmentLevel6Name = table.Column<string>(nullable: true),
                    DepartmentLevel7Name = table.Column<string>(nullable: true),
                    DepartmentLevel8Name = table.Column<string>(nullable: true),
                    FPAOwner = table.Column<string>(nullable: true),
                    EVPOwner = table.Column<string>(nullable: true),
                    SVPOwner = table.Column<string>(nullable: true),
                    VPOwner = table.Column<string>(nullable: true),
                    ExecutiveDirectorOwner = table.Column<string>(nullable: true),
                    SeniorDirectorOwner = table.Column<string>(nullable: true),
                    OperatingUnit = table.Column<string>(nullable: true),
                    OperatingUnitCountry = table.Column<string>(nullable: true),
                    Location = table.Column<string>(nullable: true),
                    LegalEntity = table.Column<int>(nullable: false),
                    LegalEntityName = table.Column<string>(nullable: true),
                    CostCenter = table.Column<int>(nullable: false),
                    CostCenterName = table.Column<string>(nullable: true),
                    Spend = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TargetedSuppliers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Email = table.Column<string>(nullable: true),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    Departments = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Accounts");

            migrationBuilder.DropTable(
                name: "CurrentStarts");

            migrationBuilder.DropTable(
                name: "Departments");

            migrationBuilder.DropTable(
                name: "GileadWideSuppliers");

            migrationBuilder.DropTable(
                name: "POs");

            migrationBuilder.DropTable(
                name: "PriorForecasts");

            migrationBuilder.DropTable(
                name: "TargetedSuppliers");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}

﻿using LEWebAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Services
{
    public interface IApplicationDataRepository
    {
        User GetUser();
        void SetUser(User user);

        string GetName();
        void SetName(string name);

        string GetSection();
        void SetSection(string section);

        string GetCurrentDepartment();
        void SetDepartment(string department);

        List<int> GetSuppliersKnown();
        void SetSuppliersKnown(List<int> supplierIds);
        IEnumerable<TargetedSupplier> GetNewSupplier();
        void SetNewSupplier(string supplierName, string supplierDescription);

    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LEWebApp.Pages.LE
{
    public class SupplierDetailsModel : PageModel
    {
        private readonly IConfiguration _config;
        private readonly ILogger<SupplierDetailsModel> _logger;
        private readonly ICurrentStartData _currentStartData;
        private readonly IPreferencesData _prefsData;
        private readonly IAppData _appData;

        public IEnumerable<CurrentStart> CurrentStarts { get; set; }
        public string FullName { get; set; }
        public User UserData { get; set; }
        public ICollection<DepartmentString> Departments { get; set; }
        public string CurrentDepartment { get; set; }
        public int Year { get; set; }
        public string ForcastFiscalPeriod { get; set; }

        [FromQuery(Name = "supplierName")]
        public string SupplierName { get; set; }

        private string _currentSupplierName;
        public string CurrentSupplierName { get; set; }

        public List<string> SupplierNames { get; set; }
        public List<string> NewSupplierNames { get; set; }

        public SupplierDetailsModel(IConfiguration config, ICurrentStartData currentStartData,
                                    IAppData appData, ILogger<SupplierDetailsModel> logger, IPreferencesData prefsData)
        {
            _config = config;
            _logger = logger;
            _appData = appData;
            _prefsData = prefsData;
            _currentStartData = currentStartData;
        }

        public async Task OnGet()
        {
            var year = DateTime.Now.Year;
            Year = int.Parse(_prefsData.GetStartYear());
            ForcastFiscalPeriod = _prefsData.GetForecastPeriod();

            try
            {
                CurrentDepartment = await _appData.GetCurrentDepartment();
                CurrentSupplierName = SupplierName;

                _appData.SetSupplier(SupplierName);

                var supplierNamesList = _appData.GetSupplierNames();

                if (supplierNamesList.Contains(CurrentSupplierName))
                    SupplierNames = _appData.GetSupplierNames();
                else
                    SupplierNames = _appData.GetNewSupplierNames();

            }
            catch (Exception ex)
            {
                _logger.LogError("SupplierDetail Error: " + ex.Message);
            }



        }
    }
}

﻿using LE.Core;
using LE.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Implementations
{
    public class GileadWideSupplierData : BaseDataImpl, IGileadWideSupplierData
    {
        private readonly LEDbContext _db;
        public GileadWideSupplierData(LEDbContext db)
        {
            _db = db;
        }
        public async Task<GileadWideSupplier> GetById(int id)
        {
            return _db.GileadWideSuppliers.SingleOrDefault(t => t.Id == id);
        }

        public IEnumerable<GileadWideSupplier> GetBySuplierNumber(int supplierNumber)
        {
            return _db.GileadWideSuppliers.Where(t => t.SupplierNumber == supplierNumber);
        }


    }
}

﻿using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class ReviewController : Controller
    {
        IReviewData _reviewData;
        private readonly IPreferencesData _prefsData;
        public ReviewController(IReviewData reviewData, IPreferencesData prefsData)
        {
            _reviewData = reviewData;
            _prefsData = prefsData;

        }

        [HttpGet()]
        public IActionResult GetCurrentStartReview(string departmentId)
        {
            var currentStarts = _reviewData.ReadRentForecast(departmentId);

            var startYear = int.Parse(_prefsData.GetStartYear());

            var lastYear = (startYear - 1);
            var thisYear = (startYear);
            var nextYear = (startYear + 1);
            var yearAfterNext = (startYear + 2);

            var supplierList = currentStarts.Select(supplier => new ReviewViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                AccountGroup = supplier.AccountGroup,
                NaturalAccountName = supplier.NaturalAccountName,

                ///////////////////////last year///////////////////////////////////////
                LastFiscalYear = supplier.FiscalYear,
                LastFiscalQuarter = supplier.FiscalQuarter,
                LastFiscalPeriod = supplier.FiscalPeriod,
                LastFiscalDate = supplier.FiscalDate,
                LastFiscalMonthJan = (supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthFeb = (supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMar = (supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthApr = (supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMay = (supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJun = (supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJul = (supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthAug = (supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthSep = (supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthOct = (supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthNov = (supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthDec = (supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ///////////////////////this year/////////////////////////////////////////////
                ThisFiscalYear = supplier.FiscalYear,
                ThisFiscalQuarter = supplier.FiscalQuarter,
                ThisFiscalPeriod = supplier.FiscalPeriod,
                ThisFiscalDate = supplier.FiscalDate,
                ThisFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                /////////////////////////////////////next year///////////////////////////////////////////
                NextFiscalYear = supplier.FiscalYear,
                NextFiscalQuarter = supplier.FiscalQuarter,
                NextFiscalPeriod = supplier.FiscalPeriod,
                NextFiscalDate = supplier.FiscalDate,
                NextFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                //////////////////////////////////YAN////////////////////////////////////////////////////////////////////

            }).GroupBy(s => new { s.AccountGroup, s.SupplierName, s.NaturalAccountName })
            .Select(g =>
                new ReviewViewModel
                {
                    AccountGroup = g.Key.AccountGroup,
                    SupplierName = g.Key.SupplierName,
                    NaturalAccountName = g.Key.NaturalAccountName,

                    //LastFiscalYear = g.Key.LastFiscalYear,
                    //LastFiscalQuarter = g.FiscalQuarter,
                    //LastFiscalPeriod = g.FiscalPeriod,
                    //LastFiscalDate = g.FiscalDate,


                    LastFiscalMonthJan = g.Sum(b => b.LastFiscalMonthJan),
                    LastFiscalMonthFeb = g.Sum(b => b.LastFiscalMonthFeb),
                    LastFiscalMonthMar = g.Sum(b => b.LastFiscalMonthMar),
                    LastFiscalMonthApr = g.Sum(b => b.LastFiscalMonthApr),
                    LastFiscalMonthMay = g.Sum(b => b.LastFiscalMonthMay),
                    LastFiscalMonthJun = g.Sum(b => b.LastFiscalMonthJun),
                    LastFiscalMonthJul = g.Sum(b => b.LastFiscalMonthJul),
                    LastFiscalMonthAug = g.Sum(b => b.LastFiscalMonthAug),
                    LastFiscalMonthSep = g.Sum(b => b.LastFiscalMonthSep),
                    LastFiscalMonthOct = g.Sum(b => b.LastFiscalMonthOct),
                    LastFiscalMonthNov = g.Sum(b => b.LastFiscalMonthNov),
                    LastFiscalMonthDec = g.Sum(b => b.LastFiscalMonthDec),
                    ////////////////////////////////////////////////////////////////////////////////////



                    ThisFiscalMonthJan = g.Sum(b => b.ThisFiscalMonthJan),
                    ThisFiscalMonthFeb = g.Sum(b => b.ThisFiscalMonthFeb),
                    ThisFiscalMonthMar = g.Sum(b => b.ThisFiscalMonthMar),
                    ThisFiscalMonthApr = g.Sum(b => b.ThisFiscalMonthApr),
                    ThisFiscalMonthMay = g.Sum(b => b.ThisFiscalMonthMay),
                    ThisFiscalMonthJun = g.Sum(b => b.ThisFiscalMonthJun),
                    ThisFiscalMonthJul = g.Sum(b => b.ThisFiscalMonthJul),
                    ThisFiscalMonthAug = g.Sum(b => b.ThisFiscalMonthAug),
                    ThisFiscalMonthSep = g.Sum(b => b.ThisFiscalMonthSep),
                    ThisFiscalMonthOct = g.Sum(b => b.ThisFiscalMonthOct),
                    ThisFiscalMonthNov = g.Sum(b => b.ThisFiscalMonthNov),
                    ThisFiscalMonthDec = g.Sum(b => b.ThisFiscalMonthDec),

                    /////////////////////////////////////////////////////////////////////////////////////

                    NextFiscalMonthJan = g.Sum(b => b.NextFiscalMonthJan),
                    NextFiscalMonthFeb = g.Sum(b => b.NextFiscalMonthFeb),
                    NextFiscalMonthMar = g.Sum(b => b.NextFiscalMonthMar),
                    NextFiscalMonthApr = g.Sum(b => b.NextFiscalMonthApr),
                    NextFiscalMonthMay = g.Sum(b => b.NextFiscalMonthMay),
                    NextFiscalMonthJun = g.Sum(b => b.NextFiscalMonthJun),
                    NextFiscalMonthJul = g.Sum(b => b.NextFiscalMonthJul),
                    NextFiscalMonthAug = g.Sum(b => b.NextFiscalMonthAug),
                    NextFiscalMonthSep = g.Sum(b => b.NextFiscalMonthSep),
                    NextFiscalMonthOct = g.Sum(b => b.NextFiscalMonthOct),
                    NextFiscalMonthNov = g.Sum(b => b.NextFiscalMonthNov),
                    NextFiscalMonthDec = g.Sum(b => b.NextFiscalMonthDec),

                    /////////////////////////////////////////////////////////////////////////////////////////////////////
                    ///



                }
            );


            return new JsonResult(supplierList);
        }
    }
}

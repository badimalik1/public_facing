﻿using LE.Core;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data
{
    public interface ITargetedSupplierData
    {
        bool Save();
        bool SupplierExists(string supplierName);
        void AddTargetedSupplier(TargetedSupplier result);
        Task<IEnumerable<TargetedSupplier>> GetAll();
        Task<TargetedSupplier> AddSupplierAPI(TargetedSupplier supplier);
        Task<IEnumerable<TargetedSupplier>> GetSuppliersByName(string name);
        Task<TargetedSupplier> GetById(int id);
        IEnumerable<TargetedSupplier> GetBySuplierNumber(int supplierNumber);
        TargetedSupplier Update(TargetedSupplier updatedSupplier);
        TargetedSupplier AddSupplier(TargetedSupplier newSupplier);
        //TargetedSupplier Delete(int id);
        int GetCountOfSuppliers();
        int Commit();

    }
}

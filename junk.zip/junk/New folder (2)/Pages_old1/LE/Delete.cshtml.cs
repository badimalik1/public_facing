﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using LE.Core;
using LE.Data;

namespace LEWebApp.Pages.LE
{
    public class DeleteModel : PageModel
    {
        private readonly LEDbContext _context;

        public DeleteModel(LEDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public TargetedSupplier TargetedSupplier { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            TargetedSupplier = await _context.TargetedSuppliers.FirstOrDefaultAsync(m => m.Id == id);

            if (TargetedSupplier == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            TargetedSupplier = await _context.TargetedSuppliers.FindAsync(id);

            if (TargetedSupplier != null)
            {
                _context.TargetedSuppliers.Remove(TargetedSupplier);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}

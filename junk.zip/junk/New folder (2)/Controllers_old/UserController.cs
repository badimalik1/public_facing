﻿using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class UserController : Controller
    {

        public User UserData { get; set; }
        private readonly IAppData _appData;
        private readonly IUserData _userData;

        public string CurrentDepartment { get; set; }


        public ICollection<DepartmentString> Departments { get; set; }
        public UserController(IAppData appData, IUserData userData)
        {
            _appData = appData;
            _userData = userData;

        }

        public IActionResult GetUser(string username, string password)
        {
            var user = _appData.GetUser(username, password);
            return new JsonResult(user);
        }

        public IActionResult GetDepartments(int Id)
        {
            var departments = _userData.GetDepartments(Id);
            return new JsonResult(departments);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LE.Core
{
    public class PO
    {
        public int Id { get; set; }
        public string DepartmentID { get; set; }
        public string DepartmentLevel4Name { get; set; }
        public string DepartmentLevel8Name { get; set; }
        public int NaturalAccount { get; set; }
        public string NaturalAccountName { get; set; }
        public string POLineDescription { get; set; }
        public string PONumber { get; set; }
        public string SupplierName { get; set; }
        public int POApprovedDateYR { get; set; }
        public int POApprovedDateMN { get; set; }
        public int POLastUpdateDateYR { get; set; }
        public int POLastUpdateDateMN { get; set; }
        public decimal POAmountBilled { get; set; }
        public decimal POAmountCancelled { get; set; }
        public decimal POAmountOpen { get; set; }
        public decimal POAmountOrdered { get; set; }
        public decimal POAmountReceived { get; set; }
        public decimal PONetAmountOrdered { get; set; }

    }
}

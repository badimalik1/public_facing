﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Helpers
{
    public class ResourceParameters
    {
        const int maxPageSize = 20;
        public int PageNumber { get; set; } = 1;

        private int _pageSize = 10;
        public int PageSize
        {
            get { return _pageSize; }
            set { _pageSize = (value > maxPageSize) ? maxPageSize : value; }
        }

        //**************filter for now
        public string Tag { get; set; }
        public string Name { get; set; }
        public string Label { get; set; }
        public string Description { get; set; }

        public  string SearchQuery { get; set; }
        public string OrderBy { get; set; } = "Name";
    }
}

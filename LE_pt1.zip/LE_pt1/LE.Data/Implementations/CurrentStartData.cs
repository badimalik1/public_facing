﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace LE.Data.Implementations
{
    public class CurrentStartData : BaseDataImpl, ICurrentStartData
    {
        private readonly LEDbContext _db;
        private readonly ILogger<CurrentStartData> _logger;

        public CurrentStartData(LEDbContext db, ILogger<CurrentStartData> logger)
        {
            _db = db;
            _logger = logger;
        }

        protected HttpClient CreateHttpClient()
        {
            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return httpClient;
        }

        public int AddForecast(CurrentStart currentStart)
        {
           _db.CurrentStarts.Add(currentStart);
           var saved = Commit();

            if (!saved)
                return 0;

            return currentStart.Id;

        }

        public void DeleteForecast(int currentStartID)
        {
            //TODO: get currentstart we added
            var currentStart = _db.CurrentStarts.Where(c => c.Id == currentStartID).FirstOrDefault();

            _db.CurrentStarts.Remove(currentStart);
        }

        public bool Commit()
        {
            return (_db.SaveChanges() >= 0);
        }

        public void Delete(int id)
        {
            var currentStart = _db.CurrentStarts.Where(c => c.Id == id).FirstOrDefault();

            _db.CurrentStarts.Remove(currentStart);
            Commit();
        }

        public Task<IEnumerable<CurrentStart>> GetAll()
        {
            throw new NotImplementedException();
        }

        public CurrentStart GetById(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<CurrentStart>> GetByDepartment(string dept)
        {
            return _db.CurrentStarts
                      .Where(d => d.DepartmentNameNum == dept)
                      .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits")
                      .Where(n => n.NaturalAccountName != "Airfare")
                      .Where(s => s.SupplierName != "No Supplier Name")
                      .OrderBy(a => a.SupplierName)
                      .Skip(1000 * (0))
                      .Take(1000)
                      .ToList();
        }

        public IEnumerable<CurrentStart> GetByFiscalPeriod(string fiscalPeriod, string supplierName, string poNum, string poLineDescription)
        {
            var cs = _db.CurrentStarts
                      .Where(f => f.FiscalPeriod == fiscalPeriod)
                      .Where(p => p.PONumber == poNum)
                      .Where(p => p.POLineDescription == poLineDescription)
                      .Where(s => s.SupplierName == supplierName).ToList();

            if (cs.Count() == 0)
                return null;

            return cs;


        }

        public int GetCountOfForcasts()
        {
            throw new NotImplementedException();
        }
        public CurrentStart Update(CurrentStart updatedForcast)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CurrentStart> GetForcastsByName(string name, string dept)
        {

            return _db.CurrentStarts
                  .Where(d => d.SupplierName == name && d.DepartmentNameNum == dept)
                  .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits")
                  .Where(n => n.NaturalAccountName != "Airfare")
                  .Where(s => s.SupplierName != "No Supplier Name")                  
                  .OrderBy(a => a.NaturalAccountName)
                  .Skip(1000 * (0))
                  .Take(1000)
                  .ToList();

        }

        public IEnumerable<CurrentStart> ReadSupplierForecast(string dept)
        {
            //var currentStarts = _db.CurrentStarts
            //          .Where(d => d.DepartmentNameNum == dept)
            //          .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits")
            //          .Where(n => n.NaturalAccountName != "Airfare")
            //          .Where(s => s.SupplierName != "No Supplier Name")
            //          .OrderBy(a => a.NaturalAccountName)
            //          .Skip(5000 * (0))
            //          .Take(5000)
            //          .ToList();

            _logger.Log(LogLevel.Information, "dept: " + dept);

            var currentStarts = _db.CurrentStarts
                .Where(a => a.DepartmentNameNum == dept)
                .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits" && a.AccountGroup != "AC_72000-Deprecation & Amortization" &&
                            a.AccountGroup != "AC_73000-Other General Expense" && a.AccountGroup != "AC_68000-Promotional Programs" &&
                            a.AccountGroup != "AC_63000-Training & Education" && a.AccountGroup != "AC_67000-Grants & Medical Education" &&
                            a.AccountGroup != "AC_66000-Insurance")
                .Where(n => n.NaturalAccountName != "Airfare" && n.NaturalAccountName !="Meals & Entertainment" && n.NaturalAccountName != "Other Travel & Lodging" &&
                            n.NaturalAccountName != "Business Gifts" && !n.NaturalAccountName.StartsWith("Employee Relations 1"))
                .Where(s => s.SupplierName != "No Supplier Name" && s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                .Where(r => r.AccountNumber != 70015 && r.AccountNumber != 70020 &&
                           r.AccountNumber != 70025 && r.AccountNumber != 70205 &&
                           r.AccountNumber != 70065 && r.AccountNumber != 70070)
                .OrderBy(a => a.SupplierName)
                .ToList();

           
            return currentStarts;
        }
        public async Task<IEnumerable<CurrentStart>> GetCurrentStartByIdAPI(string deptId)
        {
            using (httpClient = CreateHttpClient())
            {
                //TODO: get from config
                httpClient.BaseAddress = new Uri("https://localhost:44328/");//baseUri
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var timeSpan = timeoutInSeconds >= 1 ? new TimeSpan(0, 0, timeoutInSeconds) : TimeSpan.FromSeconds(DEFAULT_TIMEOUT);
                httpClient.Timeout = timeSpan;

                var request = new HttpRequestMessage(HttpMethod.Get, "api/currentstart/" + deptId);

                var uri = httpClient.BaseAddress.ToString() + request.RequestUri;

                try
                {
                    var regResponse = await httpClient.GetAsync(uri);

                    if (regResponse.IsSuccessStatusCode)
                    {
                        var regResponseString = await regResponse.Content.ReadAsStringAsync();
                        var currentStart = JsonConvert.DeserializeObject<IEnumerable<CurrentStart>>(regResponseString);

                        return currentStart;
                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

                return null;

            }
        }



    }
}

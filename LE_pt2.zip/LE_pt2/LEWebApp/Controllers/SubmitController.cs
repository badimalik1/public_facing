﻿using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class SubmitController : Controller
    {
        ISubmitData _submitData;
        private readonly IPreferencesData _prefsData;

        public SubmitController(ISubmitData submitData, IPreferencesData prefsData)
        {
            _submitData = submitData;
            _prefsData = prefsData;

        }


        [HttpGet(Name = "GetVariance")]
        public IActionResult GetCurrentStartsVariance(string departmentId)
        {
            var currentStarts = _submitData.GetCurrentStarts(departmentId);
            var priorFcsts = _submitData.ReadPriorForecastRents(departmentId);

            var startYear = int.Parse(_prefsData.GetStartYear());

            var lastYear = (startYear - 1);
            var thisYear = (startYear);
            var nextYear = (startYear + 1);
            var yearAfterNext = (startYear + 2);


            var currentStartYear = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());

            var highestActualsBy = currentStartYear
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();


            var thisYearCurrentLE = currentStarts
                .Where(t => t.FiscalYear == thisYear.ToString())
                .GroupBy(g => g.AccountGroup)
                .Select(t => t.Sum(b => b.BudgetLC));

            var thisYearPriorLE = priorFcsts
                .Where(t => t.FiscalYear == (thisYear - 1).ToString())
                .GroupBy(g => g.AccountGroup)
                .Select(t => t.Sum(b => b.BudgetLC));

            var supplierList = currentStarts.Select(supplier => new FinalReviewViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                AccountGroup = supplier.AccountGroup,
                ThisYearCurrentLE = currentStarts.Where(t => t.FiscalYear == thisYear.ToString() && t.AccountGroup == supplier.AccountGroup).GroupBy(g => g.AccountGroup).Select(t => t.Sum(b => b.BudgetLC)).FirstOrDefault(),
                ThisYearPriorLE = priorFcsts.Where(t => t.FiscalYear == (thisYear - 1).ToString() && t.AccountGroup == supplier.AccountGroup).GroupBy(g => g.AccountGroup).Select(t => t.Sum(b => b.BudgetLC)).FirstOrDefault(),
                ThisYearVariance = 0,
                NextYearCurrentLE = currentStarts.Where(p => p.FiscalYear == nextYear.ToString() && p.AccountGroup == supplier.AccountGroup).Sum(g => g.BudgetLC),
                NextYearPriorLE = priorFcsts.Where(p => p.FiscalYear == nextYear.ToString() && p.AccountGroup == supplier.AccountGroup).Sum(g => g.BudgetLC),
                NextYearVariance = 0,
                YANCurrentLE = currentStarts.Where(p => p.FiscalYear == yearAfterNext.ToString() && p.AccountGroup == supplier.AccountGroup).Sum(g => g.BudgetLC),
                ThisYearCommentary = supplier.FiscalYear == thisYear.ToString() ? supplier.FiscalCommentary : "",
                NextYearCommentary = supplier.FiscalYear == nextYear.ToString() ? supplier.FiscalCommentary : "",
                YANCommentary = supplier.FiscalYear == yearAfterNext.ToString() ? supplier.FiscalCommentary : ""
            });


            return new JsonResult(supplierList);
        }

        [HttpGet(Name = "GetYoY")]
        public IActionResult GetCurrentStartsYoy(string departmentId)
        {
            var currentStarts = _submitData.GetCurrentStarts(departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);


            var lastYearCurrentStart = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());
            var thisYearCurrentStart = currentStarts.Where(r => r.FiscalYear == thisYear.ToString());
            var nextYearCurrentStart = currentStarts.Where(r => r.FiscalYear == nextYear.ToString());
            var YANCurrentStart = currentStarts.Where(r => r.FiscalYear == yearAfterNext.ToString());

            var highestActualsBy = lastYearCurrentStart
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();



            var supplierList = highestActualsBy.Select(supplier => new FinalReviewYOYViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                AccountGroup = supplier.AccountGroup,
                //ThisYearVariance =
                //NextYearVariance =
                //ThisVSNextYearVariance =
                //NextYearVSYANVariance =
                ThisYearVSNextYearCommentary = supplier.FiscalYear == thisYear.ToString() ? supplier.FiscalCommentary : "",
                NextYearVSYanCommentary = supplier.FiscalYear == nextYear.ToString() ? supplier.FiscalCommentary : ""
            });


            return new JsonResult(supplierList);
        }

        [HttpGet(Name = "GetTopTen")]
        public IActionResult GetCurrentStartsTopTen(string departmentId)
        {
            var currentStarts = _submitData.GetCurrentStarts(departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            var fiscalYearExtracts = currentStarts
                                    .Where(c => c.FiscalYear != lastYear.ToString() && c.Scenario != "Actual");


            var currentStartActuals = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());

            var highestActualsBy = currentStartActuals
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First()).Take(10)
                .ToList();



            var supplierList = highestActualsBy.Select(supplier => new FinalReviewTopTenViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                //ThisYearCurrentLE =
                //NextYearCurrentLE =
                //YANCurrentLE =
                //TotalSpend =
                Commentary = supplier.FiscalCommentary

            });


            return new JsonResult(supplierList);
        }



    }
}

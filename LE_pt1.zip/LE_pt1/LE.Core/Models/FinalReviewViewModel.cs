﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LE.Core
{
    public class FinalReviewViewModel
    {
        public int SupplierId { get; set; }
        public string SupplierName { get; set; }
        public string AccountGroup { get; set; }
        public decimal ThisYearCurrentLE { get; set; }
        public decimal ThisYearPriorLE { get; set; }
        public decimal ThisYearVariance { get; set; }
        public decimal NextYearCurrentLE { get; set; }
        public decimal NextYearPriorLE { get; set; }
        public decimal NextYearVariance { get; set; }
        public decimal YANCurrentLE { get; set; }
        public string ThisYearCommentary { get; set; }
        public string NextYearCommentary { get; set; }
        public string YANCommentary { get; set; }
    }

    public class FinalReviewYOYViewModel
    {
        public int SupplierId { get; set; }
        public string SupplierName { get; set; }
        public string AccountGroup { get; set; }
        public decimal ThisYearVariance { get; set; }
        public decimal NextYearVariance { get; set; }
        public decimal ThisVSNextYearVariance {get; set; }
        public decimal NextYearVSYANVariance { get; set; }
        public string ThisYearVSNextYearCommentary { get; set; }
        public string NextYearVSYanCommentary { get; set; }

    }


    public class FinalReviewTopTenViewModel
    {
        public int SupplierId { get; set; }
        public string SupplierName { get; set; }
        public decimal ThisYearCurrentLE { get; set; }

        public decimal NextYearCurrentLE { get; set; }

        public decimal YANCurrentLE { get; set; }

        public decimal TotalSpend { get; set; }

        public string Commentary { get; set; }
    }
}

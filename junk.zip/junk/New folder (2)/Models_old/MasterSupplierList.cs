﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LE.Core.Models
{
   public class MasterSupplierList
    {
        public int Id { get; set; }
        public string SupplierName { get; set; }
        public string SupplierName_1 { get; set; }
        public string SupplierNameReplacement { get; set; }
        public int SupplierId { get; set; }
        public string SupplierTypeDescription { get; set; }
        public string SupplierType { get; set; }
        public string ExceptionsPO { get; set; }
        public string ExceptionSupplierType { get; set; }
    }
}

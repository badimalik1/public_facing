﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LE.Core;
using LE.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LEWebApp.Pages.LE
{
    public class OrgEditModel : PageModel
    {
        private readonly ITargetedSupplierData _supplierData;
        private readonly IHtmlHelper htmlHelper;

        public IEnumerable<SelectListItem> OpUnits { get; set; }
        public TargetedSupplier TargetedSupplier { get; set; }
        public IEnumerable<TargetedSupplier> TargetedSuppliers { get; set; }
        public OrgEditModel(ITargetedSupplierData supplierData, IHtmlHelper htmlHelper)
        {
            _supplierData = supplierData;
            this.htmlHelper = htmlHelper;
        }


        public IActionResult OnGet(int supplierNumber)
        {
            OpUnits = htmlHelper.GetEnumSelectList<OperatingUnitTypes>();
            TargetedSuppliers = _supplierData.GetBySuplierNumber(supplierNumber);

            if(TargetedSuppliers == null)
            {
                return RedirectToPage("./NotFound");
            }
            return Page();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace LEWebAPI.Helpers
{
    public static class PatchHelper
    {
        public static StringContent ToPatchJsonContent(this object node, Encoding enc = null)
        {
            List<PatchObject> patchObjectsCollection = new List<PatchObject>();

            foreach (var prop in node.GetType().GetProperties())
            {
                var patch = new PatchObject { Op = "replace", Path = prop.Name, Value = prop.GetValue(node) };
                patchObjectsCollection.Add(patch);
            }

            MemoryStream payloadStream = new MemoryStream();
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(patchObjectsCollection.GetType());
            serializer.WriteObject(payloadStream, patchObjectsCollection);
            Encoding encoding = enc ?? Encoding.UTF8;
            var content = new StringContent(Encoding.UTF8.GetString(payloadStream.ToArray()), encoding, "application/json");

            return content;
        }


    }

    [DataContract(Name = "PatchObject")]
    class PatchObject
    {
        [DataMember(Name = "op")]
        public string Op { get; set; }
        [DataMember(Name = "path")]
        public string Path { get; set; }
        [DataMember(Name = "value")]
        public object Value { get; set; }
    }


}

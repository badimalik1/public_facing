﻿using LEWebAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Services
{
    public class ApplicationDataRepository : IApplicationDataRepository
    {
        User _user { get; set; }
        string _currentDepartment { get; set; }
        string _fullName { get; set; }
        string _section { get; set; }

        List<int> _suppliers { get; set; }
        IList<TargetedSupplier> _newSuppliers { get; set; }

        public User GetUser()
        {
            return _user;
        }

        public void SetUser(User user)
        {
            _user = user;
        }


        public string GetCurrentDepartment()
        {
            return _currentDepartment;
        }

        public void SetDepartment(string department)
        {
            _currentDepartment = department;
        }


        public string GetName()
        {
            return _fullName;
        }

        public void SetName(string name)
        {
            _fullName = name;
        }

        public string GetSection()
        {
            return _section;
        }

        public void SetSection(string section)
        {
            _section = section;
        }

        public void SetSuppliersKnown(List<int> supplierIds)
        {
            if (_suppliers == null)
                _suppliers = new List<int>();

            supplierIds.ForEach(s => { _suppliers.Add(s); });

        }

        public void SetNewSupplier(string supplierName, string supplierDescription)
        {
            if (_newSuppliers == null)
                _newSuppliers = new List<TargetedSupplier>();

            var newSupplier = new TargetedSupplier()
            {
                SupplierName = supplierName
            };
            _newSuppliers.Add(newSupplier);
        }

        public List<int> GetSuppliersKnown()
        {
            return _suppliers;
        }

        public IEnumerable<TargetedSupplier> GetNewSupplier()
        {
            return _newSuppliers;
        }

    }
}

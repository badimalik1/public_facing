﻿using System;
using System.Collections.Generic;
using System.Text;
using LE.Core;

namespace LE.Data.Interfaces
{
    public interface ITaxData
    {
        IEnumerable<CurrentStart> ReadTaxForecast(string dept);
    }
}

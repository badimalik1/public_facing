﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Data.Interfaces
{
    public interface ISubmitData
    {
        IEnumerable<CurrentStart> GetCurrentStarts(string dept);
        IEnumerable<PriorForecast> ReadPriorForecastRents(string dept);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace LE.Data
{
    public class BaseDataImpl
    {
        protected int timeoutInSeconds;
        protected HttpClient httpClient;
        protected const int DEFAULT_TIMEOUT = 600;


        public int Timeout
        {
            get
            {
                return (int)httpClient.Timeout.TotalSeconds;
            }
            set
            {
                timeoutInSeconds = value;
            }
        }


    }
}

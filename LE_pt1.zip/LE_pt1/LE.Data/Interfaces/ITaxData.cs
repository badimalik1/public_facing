﻿using System;
using System.Collections.Generic;
using System.Text;
using LE.Core;

namespace LE.Data.Interfaces
{
    public interface ITaxData
    {
        bool Save();
        CurrentStart GetCurrentStart(int id);
        void AddCurrentStart(CurrentStart result);
        IEnumerable<CurrentStart> ReadTaxForecast(string dept);
    }
}

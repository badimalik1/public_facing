﻿using LE.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Data
{
    public class LEDbContext : DbContext
    {
        public DbSet<PO> POes { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Account> Accounts { get; set; }
        public DbSet<Pending> Pending { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Preferences> Preferences { get; set; }
        public DbSet<CurrentStart> CurrentStarts { get; set; }
        public DbSet<PriorForecast> PriorForecasts { get; set; }
        public DbSet<TargetedSupplier> TargetedSuppliers { get; set; }
        public DbSet<DepartmentString> DepartmentStrings { get; set; }
        public DbSet<GileadWideSupplier> GileadWideSuppliers { get; set; }

        public LEDbContext(DbContextOptions<LEDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            //var splitStringConverter = new ValueConverter<IEnumerable<string>, string>(v => string.Join(";", v), v => v.Split(new[] { ';' }));
            // builder.Entity<User>().Property(nameof(User.Departments)).HasConversion(splitStringConverter);
        }
    }
}

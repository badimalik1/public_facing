﻿using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class TaxController : Controller
    {
        public User UserData { get; set; }
        private readonly IAppData _appData;
        public string CurrentDepartment { get; set; }
        private readonly ITaxData _taxData;

        public ICollection<DepartmentString> Departments { get; set; }

        public IEnumerable<CurrentStart> CurrentStarts { get; set; }

        public TaxController(ITaxData taxData, IAppData appData)
        {

            _appData = appData;
            _taxData = taxData;
            UserData = _appData.GetUser();

        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public RedirectResult Data_Source_Spreadsheet_Submit()
        {
            var testdata = HttpContext.Request.ContentLength;

            //var result = new List<SupplierSubmitViewModel>();
            // return Json(result);

            // return View();
            //return RedirectToPage("Review");
            return Redirect("https://localhost:44308/LE/Review");

        }

        [HttpGet()]
        public IActionResult GetCurrentStartTaxes(string departmentId)
        {
            Task.Run(async () =>
            {
                CurrentDepartment = await _appData.GetCurrentDepartment();
            });

            Departments = new Collection<DepartmentString>();
            foreach (var dp in UserData.Departments)
            {
                Departments.Add(dp);
            }
            var dept = CurrentDepartment = CurrentDepartment != null ? CurrentDepartment : departmentId;


            var currentStarts = _taxData.ReadTaxForecast(dept);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            var fiscalYearExtracts = currentStarts
                                    .Where(c => c.FiscalYear != lastYear.ToString() && c.Scenario != "Actual");


            var currentStartActuals = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());

            var highestActualsBy = currentStartActuals
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();



            var supplierList = currentStarts.Select(supplier => new RentsViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                POLineDescription = supplier.POLineDescription,
                LEComments = supplier.Comments,
                Scenario = supplier.Scenario,
                VarianceComments = supplier.VarianceComments,

                ///////////////////////last year///////////////////////////////////////
                LastFiscalYear = supplier.FiscalYear,
                LastFiscalQuarter = supplier.FiscalQuarter,
                LastFiscalPeriod = supplier.FiscalPeriod,
                LastFiscalDate = int.Parse(supplier.FiscalDate),
                LastFiscalMonthJan = (supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthFeb = (supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMar = (supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthApr = (supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMay = (supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJun = (supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJul = (supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthAug = (supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthSep = (supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthOct = (supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthNov = (supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthDec = (supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ///////////////////////this year/////////////////////////////////////////////
                ThisFiscalYear = supplier.FiscalYear,
                ThisFiscalQuarter = supplier.FiscalQuarter,
                ThisFiscalPeriod = supplier.FiscalPeriod,
                ThisFiscalDate = int.Parse(supplier.FiscalDate),
                ThisFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                /////////////////////////////////////next year///////////////////////////////////////////
                NextFiscalYear = supplier.FiscalYear,
                NextFiscalQuarter = supplier.FiscalQuarter,
                NextFiscalPeriod = supplier.FiscalPeriod,
                NextFiscalDate = int.Parse(supplier.FiscalDate),
                NextFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                //////////////////////////////////YAN////////////////////////////////////////////////////////////////////
                YANFiscalYear = supplier.FiscalYear,
                YANFiscalQuarter = supplier.FiscalQuarter,
                YANFiscalPeriod = supplier.FiscalPeriod,
                YANFiscalDate = int.Parse(supplier.FiscalDate),
                YANFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0



            });


            return new JsonResult(supplierList);
        }
    }
}

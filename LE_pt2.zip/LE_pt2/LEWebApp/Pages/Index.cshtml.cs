﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LEWebApp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IConfiguration _config;
        private readonly ILogger<IndexModel> _logger;
        private readonly IUserData _userData;
        private readonly IAppData _appData;
        public User UserInfo { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Display(Name = "Remember me")]
        public bool RememberMe { get; set; }

        public IndexModel(IConfiguration config, IUserData userData, IAppData appData, ILogger<IndexModel> logger)
        {
            _config = config;
            _logger = logger;
            _userData = userData;
            _appData = appData;

        }


        public IActionResult OnPost(string email, string password)
        {
            UserInfo = _userData.GetUser(email, password);

            if (UserInfo == null)
            {
                ModelState.AddModelError("", "The username or password is incorrect.");
            }
            else
            {
                _appData.SetUser(UserInfo);
                return RedirectToPage("LE/SupplierForecast");
            }


            return RedirectToPage("Index"); ;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LE.Core
{
    public class SupplierViewModel
    {
        public int SupplierId { get; set; }
        [Required]
        [Display(Name = "Supplier Name")]
        public string SupplierName
        {
            get;
            set;
        }

        public decimal FiscalYear1 { get; set; }
        public decimal FiscalYear2 { get; set; }
        public decimal FiscalYear3 { get; set; }
        public decimal FiscalYear4 { get; set; }



    }
}

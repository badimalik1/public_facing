﻿using LEWebAPI.Entities;
using LEWebAPI.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Services
{
    public interface ICurrentStartRepository
    {
        bool Save();
        bool SupplierExists(string supplierName);
        bool CurrentStartExists(int id);
        void AddCurrentStart(CurrentStart result);
        CurrentStart GetCurrentStart(int id);
        void UpdateCurrentStart(CurrentStart currentStart);
        IEnumerable<CurrentStart> GetFormattedCurrentStarts();
        IEnumerable<CurrentStart> GetCurrentStarts(SupplierResourceParameters supplierResourceParameters);
        IEnumerable<CurrentStart> GetCurrentStarts(SupplierResourceParameters supplierResourceParameters, string departmentNumber); 
        IEnumerable<CurrentStart> GetCurrentStartTaxes(SupplierResourceParameters supplierResourceParameters, string departmentNumber);
        IEnumerable<CurrentStart> GetCurrentStartRents(SupplierResourceParameters supplierResourceParameters, string departmentNumber);
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using LE.Data;
using LE.Core;
using LEWebApp.Models;
using System.Diagnostics;
using LE.Data.Interfaces;

namespace LEWebApp.Controllers
{
    [Route("api/multiselect")]
    [ApiController]
    public class MultiSelectController : Controller
    {
        private readonly LEDbContext _db;
        private readonly IAppData _appData;

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }


        public MultiSelectController(LEDbContext db, IAppData appData)
        {
            _db = db;
            _appData = appData;
        }

        private string StripZeroes(string str)
        {
            string parseString = "";
            var frst = str.Substring(0, 1);

            if (frst.Equals("0"))
                parseString = str.Remove(str.Length - 1).Substring(2);
            else
                return str;

            var scnd = parseString.Substring(0, 1);

            if (scnd.Equals("0"))
                parseString = str.Remove(str.Length - 1).Substring(2);
            else
                return parseString;


            return parseString;
        }


        [HttpGet()]
        public JsonResult ServerFiltering_GetTargetedSuppliers(string text)
        {
            var department = _appData.GetCurrentDepartment().Result;
            var departmentID = department.Split('_')[1];

            var departmentNum = StripZeroes(departmentID);

            var suppliers = _db.TargetedSuppliers
                .Where(t => t.DepartmentID == departmentNum)
                .OrderBy(a => a.SupplierName)
               .Skip(10 * (0))
                 .Take(80000)
               .ToList();

            var supplierList = suppliers.Select(supplier => new LE.Core.SupplierViewModel { SupplierId = supplier.Id, SupplierName = supplier.SupplierName });

            if (!string.IsNullOrEmpty(text))
            {
                SearchTerm = text.ToUpper(); ;

                try
                {
                    var suppList = supplierList.Where(s => s.SupplierName != null && s.SupplierName.Contains(SearchTerm));
                    return Json(suppList.ToList());

                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

            }

            return Json(supplierList.ToList());
        }
    }
}

﻿using LEWebAPI.DTOs;
using LEWebAPI.Helpers;
using LEWebAPI.Services;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Linq;
using LEWebAPI.Entities;
using System.Collections.Generic;
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using Microsoft.AspNetCore.JsonPatch;
using System.Net.Http;


//TODO: update to use guids 
//TODO: add versioning

namespace LEWebAPI.Controllers
{
    [EnableCors("_myAllowSpecificOrigins")]
    [Route("api/currentStart")]
    public class CurrentStartController : Controller
    {
        private readonly IMapper _mapper;
        private ILERepository _leRepository;
        private IPriorForecastRepository _priorFcstRepository;
        private ICurrentStartRepository _currentstartRepository;

        public CurrentStartController(ILERepository leRepository, ICurrentStartRepository currentStartRepository,
                                      IPriorForecastRepository priorFcstRepository, IMapper mapper)
        {
            _mapper = mapper;
            _leRepository = leRepository;
            _currentstartRepository = currentStartRepository;
            _priorFcstRepository = priorFcstRepository;
        }


        [HttpGet("{departmentId}")]
        public IActionResult GetCurrentStarts(SupplierResourceParameters supplierResourceParameters, string departmentId)
        {
            var currentStarts = _currentstartRepository.GetCurrentStarts(supplierResourceParameters, departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            var fiscalYearExtracts = currentStarts
                                    .Where(c => c.FiscalYear != lastYear.ToString() && c.Scenario != "Actual");


            var currentStartActuals = currentStarts.Where(r =>  r.FiscalYear == lastYear.ToString());

            var highestActualsBy = currentStartActuals
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();



            var supplierList = highestActualsBy.Select(supplier => new SupplierViewModel
            {
                                                SupplierId = supplier.Id, SupplierName = supplier.SupplierName, 
                                                FiscalYear1 = supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC,
                                                FiscalYear2 = fiscalYearExtracts.Where(f => f.FiscalYear == thisYear.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.BudgetLC ?? default(decimal),
                                                FiscalYear3 = fiscalYearExtracts.Where(f => f.FiscalYear == nextYear.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.BudgetLC ?? default(decimal),
                                                FiscalYear4 = fiscalYearExtracts.Where(f => f.FiscalYear == yearAfterNext.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.BudgetLC ?? default(decimal)
            });


            return new JsonResult(supplierList);
        }

        [HttpGet("{name}/{departmentId}")]
        [Route("details/{name}/{departmentId}")]
        public IActionResult GetCurrentStartSupplierDetails(SupplierResourceParameters supplierResourceParameters, string name, string departmentId)
        {
            var currentStarts = _currentstartRepository.GetCurrentStarts(supplierResourceParameters, departmentId);

            var details = currentStarts
                      .Where(d => d.SupplierName == name && d.DepartmentNameNum == departmentId)
                      .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits")
                      .Where(n => n.NaturalAccountName != "Airfare")
                      .Where(s => s.SupplierName != "No Supplier Name")
                      .OrderBy(a => a.NaturalAccountName)
                      .Skip(1000 * (0))
                      .Take(1000)
                      .ToList();


            return new JsonResult(details);
        }
        public IActionResult GetCurrentStarts(SupplierResourceParameters supplierResourceParameters)
        {
            var currentStarts = _currentstartRepository.GetCurrentStarts(supplierResourceParameters);
            return new JsonResult(currentStarts);
        }

        [Route("rents/{departmentId}")]
        public IActionResult GetCurrentStartRents(SupplierResourceParameters supplierResourceParameters, string departmentId)
        {
            var currentStarts = _currentstartRepository.GetCurrentStartRents(supplierResourceParameters, departmentId);
            var priorFcsts = _priorFcstRepository.GetPriorForecastRents(supplierResourceParameters, departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            //var lastPFTotals = priorFcsts
            //    .Where(p => p.FiscalYear == lastYear.ToString())
            //    .Select(g => g.TotalLC);

            //var thisPFTotals = priorFcsts
            //    .Where(p => p.FiscalYear == thisYear.ToString() )
            //    .Select(g => g.TotalLC); //.Sum(g => g.TotalLC);

            //var nextPFTotals = priorFcsts
            //        .Where(p => p.FiscalYear == nextYear.ToString())
            //        .Select(g => g.TotalLC);


            //var yanPFTotals = priorFcsts
            //        .Where(p => p.FiscalYear == yearAfterNext.ToString())
            //        .Select(g => g.TotalLC);

            var supplierList = currentStarts.Select(supplier => new RentsViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                POLineDescription = supplier.POLineDescription,
                LEComments = supplier.Comments,
                Scenario = supplier.Scenario,

                ///////////////////////last year///////////////////////////////////////
                LastFiscalYear = supplier.FiscalYear,
                LastFiscalQuarter = supplier.FiscalQuarter,
                LastFiscalPeriod = supplier.FiscalPeriod,
                LastFiscalDate = Convert.ToInt32(Double.Parse(supplier.FiscalDate)),
                LastPriorFcst = priorFcsts.Where(p => p.FiscalYear == lastYear.ToString() && p.ProjectTaskNumber == supplier.ProjectTaskNumber).Select(g => g.TotalLC).FirstOrDefault(),
                LastFiscalMonthJan = (supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthFeb = (supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMar = (supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthApr = (supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMay = (supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJun = (supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJul = (supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthAug = (supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthSep = (supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthOct = (supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthNov = (supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthDec = (supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ///////////////////////this year/////////////////////////////////////////////
                ThisFiscalYear = supplier.FiscalYear,
                ThisFiscalQuarter = supplier.FiscalQuarter,
                ThisFiscalPeriod = supplier.FiscalPeriod,
                ThisFiscalDate = Convert.ToInt32(Double.Parse(supplier.FiscalDate)),
                ThisPriorFcst = priorFcsts.Where(p => p.FiscalYear == thisYear.ToString() && p.ProjectTaskNumber == supplier.ProjectTaskNumber).Select(g => g.TotalLC).FirstOrDefault(),
                ThisFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                /////////////////////////////////////next year///////////////////////////////////////////
                NextFiscalYear = supplier.FiscalYear,
                NextFiscalQuarter = supplier.FiscalQuarter,
                NextFiscalPeriod = supplier.FiscalPeriod,
                NextFiscalDate = Convert.ToInt32(Double.Parse(supplier.FiscalDate)),
                NextPriorFcst = priorFcsts .Where(p => p.FiscalYear == nextYear.ToString() && p.ProjectTaskNumber == supplier.ProjectTaskNumber).Select(g => g.TotalLC).FirstOrDefault(),
                NextFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                //////////////////////////////////YAN////////////////////////////////////////////////////////////////////
                YANFiscalYear = supplier.FiscalYear,
                YANFiscalQuarter = supplier.FiscalQuarter,
                YANFiscalPeriod = supplier.FiscalPeriod,
                YANFiscalDate = Convert.ToInt32(Double.Parse(supplier.FiscalDate)),
                YANPriorFcst = priorFcsts.Where(p => p.FiscalYear == yearAfterNext.ToString() && p.ProjectTaskNumber == supplier.ProjectTaskNumber).Select(g => g.TotalLC).FirstOrDefault(),
                YANFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0

            });

            var highestBy = currentStarts
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();

            //TODO: get priorforecast and cache it
            //var groupList = supplierList
            //    .GroupBy(s => s.SupplierName)
            //    .ToList();


            //var groupList =
            //    from supplier in supplierList
            //    group supplier by supplier.SupplierName into newGroup
            //    orderby newGroup.Key
            //    select newGroup;

            return new JsonResult(supplierList);
        }

        [Route("taxes/{departmentId}")]
        public IActionResult GetCurrentStartTaxes(SupplierResourceParameters supplierResourceParameters, string departmentId)
        {
            var currentStarts = _currentstartRepository.GetCurrentStartTaxes(supplierResourceParameters, departmentId);

            var highestBy = currentStarts 
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();

            return new JsonResult(highestBy);
        }


        [Route("submit/variance/{departmentId}")]
        [HttpGet(Name="GetVariance")]
        public IActionResult GetCurrentStartsVariance(SupplierResourceParameters supplierResourceParameters, string departmentId)
        {
            var currentStarts = _currentstartRepository.GetCurrentStarts(supplierResourceParameters, departmentId);
            var priorFcsts = _priorFcstRepository.GetPriorForecastRents(supplierResourceParameters, departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);


            var currentStartYear = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());

            var highestActualsBy = currentStartYear
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();

            
            var thisYearCurrentLE = currentStarts
                .Where(t => t.FiscalYear == thisYear.ToString())
                .GroupBy(g => g.AccountGroup)
                .Select(t=> t.Sum(b=> b.BudgetLC));

            var thisYearPriorLE = priorFcsts
                .Where(t => t.FiscalYear == (thisYear-1).ToString())
                .GroupBy(g => g.AccountGroup)
                .Select(t =>  t.Sum(b => b.BudgetLC));

            var supplierList = currentStarts.Select(supplier => new FinalReviewViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                AccountGroup = supplier.AccountGroup,
                ThisYearCurrentLE = currentStarts.Where(t => t.FiscalYear == thisYear.ToString() && t.AccountGroup == supplier.AccountGroup).GroupBy(g => g.AccountGroup).Select(t => t.Sum(b => b.BudgetLC)).FirstOrDefault(),
                ThisYearPriorLE = priorFcsts.Where(t => t.FiscalYear == (thisYear - 1).ToString() && t.AccountGroup == supplier.AccountGroup).GroupBy(g => g.AccountGroup).Select(t => t.Sum(b => b.BudgetLC)).FirstOrDefault(),
                ThisYearVariance = 0,
                NextYearCurrentLE = currentStarts.Where(p => p.FiscalYear == nextYear.ToString() && p.AccountGroup == supplier.AccountGroup).Sum(g => g.BudgetLC),
                NextYearPriorLE = priorFcsts.Where(p => p.FiscalYear == nextYear.ToString() && p.AccountGroup == supplier.AccountGroup).Sum(g => g.BudgetLC),
                NextYearVariance = 0,
                YANCurrentLE = currentStarts.Where(p => p.FiscalYear == yearAfterNext.ToString() && p.AccountGroup == supplier.AccountGroup).Sum(g => g.BudgetLC),
                ThisYearCommentary = supplier.FiscalYear == thisYear.ToString() ? supplier.FiscalCommentary: "" ,
                NextYearCommentary = supplier.FiscalYear == nextYear.ToString() ? supplier.FiscalCommentary : "",
                YANCommentary = supplier.FiscalYear == yearAfterNext.ToString() ? supplier.FiscalCommentary : ""
            });


            return new JsonResult(supplierList);
        }

        [Route("submit/yoy/{departmentId}")]
        [HttpGet(Name="GetYoY")]
        public IActionResult GetCurrentStartsYoy(SupplierResourceParameters supplierResourceParameters, string departmentId)
        {
            var currentStarts = _currentstartRepository.GetCurrentStarts(supplierResourceParameters, departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);


            var lastYearCurrentStart = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());
            var thisYearCurrentStart = currentStarts.Where(r => r.FiscalYear == thisYear.ToString());
            var nextYearCurrentStart = currentStarts.Where(r => r.FiscalYear == nextYear.ToString());
            var YANCurrentStart = currentStarts.Where(r => r.FiscalYear == yearAfterNext.ToString());

            var highestActualsBy = lastYearCurrentStart
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();



            var supplierList = highestActualsBy.Select(supplier => new FinalReviewYOYViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                AccountGroup = supplier.AccountGroup,
                //ThisYearVariance =
                //NextYearVariance =
                //ThisVSNextYearVariance =
                //NextYearVSYANVariance =
                ThisYearVSNextYearCommentary = supplier.FiscalYear == thisYear.ToString() ? supplier.FiscalCommentary : "",
                NextYearVSYanCommentary = supplier.FiscalYear == nextYear.ToString() ? supplier.FiscalCommentary : ""
            });


            return new JsonResult(supplierList);
        }

        [Route("submit/topten/{departmentId}")]
        [HttpGet(Name="GetTopTen")]
        public IActionResult GetCurrentStartsTopTen(SupplierResourceParameters supplierResourceParameters,  string departmentId)
        {
            var currentStarts = _currentstartRepository.GetCurrentStarts(supplierResourceParameters, departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            var fiscalYearExtracts = currentStarts
                                    .Where(c => c.FiscalYear != lastYear.ToString() && c.Scenario != "Actual");


            var currentStartActuals = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());

            var highestActualsBy = currentStartActuals
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();



            var supplierList = highestActualsBy.Select(supplier => new FinalReviewTopTenViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                //ThisYearCurrentLE =
                //NextYearCurrentLE =
                //YANCurrentLE =
                //TotalSpend =
                Commentary = supplier.FiscalCommentary

            });


            return new JsonResult(supplierList);
        }
        private IActionResult UpdateRentCurrentStartInternal( int id, JsonPatchDocument<CurrentStartDTO> currentStartDoc)
        {
            if (currentStartDoc == null)
            {
                return BadRequest("No Current Start to Update!");
            }

            if(!_currentstartRepository.CurrentStartExists(id)) // change to id
            {
                return NotFound();
            }
            var currentStartFromRepo = _currentstartRepository.GetCurrentStart(id);
            if(currentStartFromRepo == null)
            {
                return NotFound();
            }

            var currentStartToPatch = _mapper.Map<Entities.CurrentStart, DTOs.CurrentStartDTO>(currentStartFromRepo);

            //Add mapping
            currentStartDoc.ApplyTo(currentStartToPatch);

            _mapper.Map (currentStartToPatch, currentStartFromRepo);

            _currentstartRepository.UpdateCurrentStart(currentStartFromRepo);

            if (!_currentstartRepository.Save())
            {
                return StatusCode(500, "Problem updating Current Start Record.");
            }

            return NoContent();
        }

        [Route("update/{suppliername}")]
        [HttpPut("/currentStart/{supplierName}")]
        public IActionResult UpdateCurrentStart(string supplierName, [FromBody] CurrentStartDTO currentStart)
        {

            if (currentStart == null)
            {
                return BadRequest("No Current Start to Create!");
            }

            if (currentStart.SupplierName  == "" || currentStart.SupplierName == null)
            {
                ModelState.AddModelError("Name", "The Supplier should have a name");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest("Model State");

            }

            var currentStartToAdd = _mapper.Map<DTOs.CurrentStartDTO, Entities.CurrentStart>(currentStart);

            _currentstartRepository.AddCurrentStart(currentStartToAdd);

            if (!_currentstartRepository.Save())
            {
                return StatusCode(500, "Error updating Current Start.");
            }

            var createdCurrentStart = _mapper.Map<Entities.CurrentStart, Models.CurrentStartDTO>(currentStartToAdd);

            return CreatedAtRoute("GetCurrentStarts", new { createdCurrentStart.DepartmentNameNum }, createdCurrentStart);
        }

        [Route("addCurrentStart")]
        [HttpPost("addCurrentStart")]
        public IActionResult CreateCurrentStartSupplier(string[] currentStart)
        {
            if (currentStart == null)
            {
                return BadRequest();
            }

            var supplierData = JsonConvert.DeserializeObject<SupplierViewModel[]>(currentStart[0]);

            var supplierDataList = supplierData.ToList();
            CurrentStart currStartAdd = null;
            foreach (var item in supplierDataList)
            {
                var currStart = _currentstartRepository.GetCurrentStart(item.SupplierId);
                //TODO: use automapper

                currStartAdd = new CurrentStart()
                {
                    ProjectName = currStart.ProjectName,
                    Scenario = "SEPLE",
                    POLineDescription = currStart.POLineDescription,
                    DepartmentNameNum = currStart.DepartmentNameNum,
                    BudgetUSD_1 = currStart.BudgetUSD_1,
                    BudgetLC_1 = currStart.BudgetLC_1,
                    Comments = currStart.Comments,
                    
                    DepartmentName = currStart.DepartmentName,
                    DepartmentNumber = currStart.DepartmentNumber,
                    DepartmentGroup = currStart.DepartmentGroup,
                    DepartmentSubGroup = currStart.DepartmentSubGroup,
                    CostCenterNumber = currStart.CostCenterNumber,

                    AccountGroup = currStart.AccountGroup,
                    AccountNumber = currStart.AccountNumber,
                    NaturalAccountName = currStart.NaturalAccountName,
                    ProjectTaskNumber = currStart.ProjectTaskNumber,
                    PONumber = currStart.PONumber,
                    SupplierName = item.SupplierName,
                    SupplierNumber = currStart.SupplierNumber,
                    PurchaseInvoiceNumber = currStart.PurchaseInvoiceNumber,
                    ActualUSD = 0,
                    CountryCity = currStart.CountryCity,
                    Region = currStart.Region,
                    Region_Rpt = currStart.Region_Rpt,
                    FPAAccrualsReclasses = currStart.FPAAccrualsReclasses,
                    SupplierType = currStart.SupplierType,
                    FiscalDate =  DateTime.Now.ToOADate().ToString(),
                    LocalCurrency = currStart.LocalCurrency,
                    OriginalSupplierName = currStart.OriginalSupplierName,
                    DepartmentRollOut = currStart.DepartmentRollOut,
                    UniqueListACC = currStart.UniqueListACC,
                    UniqueListDEPT = currStart.UniqueListDEPT,

                };

                //TODO: Apply DRY

                if (item.FiscalYear2 != 0)
                {
                    currStartAdd.FiscalYear = DateTime.Now.Year.ToString();
                    currStartAdd.BudgetLC = item.FiscalYear2;
                    currStartAdd.BudgetUSD = item.FiscalYear2;
                    //currStartAdd.FiscalPeriod = DateHelpers.GetFiscalPeriod(),
                    // currStartAdd.FiscalQuarter = DateHelpers.GetFiscalQuarter(),
                    _currentstartRepository.AddCurrentStart(currStartAdd);
                }

                if (item.FiscalYear3 != 0)
                {
                    currStartAdd.FiscalYear = (DateTime.Now.Year + 1).ToString();
                    currStartAdd.BudgetLC = item.FiscalYear3;
                    currStartAdd.BudgetUSD = item.FiscalYear3;
                    //currStartAdd.FiscalPeriod = DateHelpers.GetFiscalPeriod(),
                    //currStartAdd.FiscalQuarter = DateHelpers.GetFiscalQuarter(),
                    _currentstartRepository.AddCurrentStart(currStartAdd);
                }

                if (item.FiscalYear4 != 0)
                {
                    currStartAdd.FiscalYear = (DateTime.Now.Year + 2).ToString();
                    currStartAdd.BudgetLC = item.FiscalYear4;
                    currStartAdd.BudgetUSD = item.FiscalYear4;
                    //currStartAdd.FiscalPeriod = DateHelpers.GetFiscalPeriod(),
                    //currStartAdd.FiscalQuarter = DateHelpers.GetFiscalQuarter(),
                    _currentstartRepository.AddCurrentStart(currStartAdd);
                }

                if (!_currentstartRepository.Save())
                {
                    return StatusCode(500, "Problem creating Current Start Record.");
                }
                
            }


            return new JsonResult(currStartAdd);
        }


        [Route("addRentSupplier")]
        [HttpPost("addRentSupplier")]
        public IActionResult CreateRentSupplier(string[] currentStart)
        {
            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            if (currentStart == null)
            {
                return BadRequest();
            }

            try
            {
                var supplierData = JsonConvert.DeserializeObject<RentsViewModel[]>(currentStart[0]);

                var supplierDataList = supplierData.ToList();

                CurrentStart currStartAdd = null;
                var fiscalDate = DateTime.Now.ToOADate();

                foreach (var item in supplierDataList)
                {
                    var currStart = _currentstartRepository.GetCurrentStart(item.SupplierId);

                    currStartAdd = new CurrentStart()
                    {
                        ProjectName = currStart.ProjectName,
                        Scenario = "SEPLE",
                        POLineDescription = currStart.POLineDescription,
                        DepartmentNameNum = currStart.DepartmentNameNum,
                        BudgetUSD_1 = currStart.BudgetUSD_1,
                        BudgetLC_1 = currStart.BudgetLC_1,
                        Comments = currStart.Comments,

                        DepartmentName = currStart.DepartmentName,
                        DepartmentNumber = currStart.DepartmentNumber,
                        DepartmentGroup = currStart.DepartmentGroup,
                        DepartmentSubGroup = currStart.DepartmentSubGroup,
                        CostCenterNumber = currStart.CostCenterNumber,

                        AccountGroup = currStart.AccountGroup,
                        AccountNumber = currStart.AccountNumber,
                        NaturalAccountName = currStart.NaturalAccountName,
                        ProjectTaskNumber = currStart.ProjectTaskNumber,
                        PONumber = currStart.PONumber,
                        SupplierName = item.SupplierName,
                        SupplierNumber = currStart.SupplierNumber,
                        PurchaseInvoiceNumber = currStart.PurchaseInvoiceNumber,
                        ActualUSD = 0,
                        CountryCity = currStart.CountryCity,
                        Region = currStart.Region,
                        Region_Rpt = currStart.Region_Rpt,
                        FPAAccrualsReclasses = currStart.FPAAccrualsReclasses,
                        SupplierType = currStart.SupplierType,
                        FiscalDate = DateTime.Now.ToOADate().ToString(),
                        LocalCurrency = currStart.LocalCurrency,
                        OriginalSupplierName = currStart.OriginalSupplierName,
                        DepartmentRollOut = currStart.DepartmentRollOut,
                        UniqueListACC = currStart.UniqueListACC,
                        UniqueListDEPT = currStart.UniqueListDEPT,

                    };

                    if (item.VarianceComments != null &&  item.VarianceComments != " ")
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.VarianceComments = item.VarianceComments;
                        currStartAdd.FiscalPeriod = DateHelpers.GetFiscalPeriod();
                        currStartAdd.FiscalQuarter = DateHelpers.GetFiscalQuarter();

                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                        

                    if (item.ThisFiscalMonthApr != 0)
                    {
                        currStartAdd.FiscalYear =thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthApr;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthApr;
                        currStartAdd.FiscalPeriod = "Apr-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthAug != 0) {
                        currStartAdd.FiscalYear =thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthAug;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthAug;
                        currStartAdd.FiscalPeriod = "Aug-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthDec != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthDec;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthDec;
                        currStartAdd.FiscalPeriod = "Dec-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthFeb != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthFeb;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthFeb;
                        currStartAdd.FiscalPeriod = "Feb-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthJan != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthJan;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthJan;
                        currStartAdd.FiscalPeriod = "Jan-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthJul != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthJul;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthJul;
                        currStartAdd.FiscalPeriod = "Jul-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthJun != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthJun;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthJun;
                        currStartAdd.FiscalPeriod = "Jun-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthMar != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthMar;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthMar;
                        currStartAdd.FiscalPeriod = "Mar-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthMay != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthMay;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthMay;
                        currStartAdd.FiscalPeriod = "May-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthNov != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthNov;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthNov;
                        currStartAdd.FiscalPeriod = "Nov-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.ThisFiscalMonthOct != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthOct;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthOct;
                        currStartAdd.FiscalPeriod = "Oct-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();

                    }
                    if (item.ThisFiscalMonthSep != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = item.ThisFiscalMonthSep;
                        currStartAdd.BudgetUSD = item.ThisFiscalMonthSep;
                        currStartAdd.FiscalPeriod = "Sep-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    if (item.NextFiscalMonthApr != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthApr;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthApr;
                        currStartAdd.FiscalPeriod = "Apr-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthAug != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthAug;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthAug;
                        currStartAdd.FiscalPeriod = "Aug-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthDec != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthDec;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthDec;
                        currStartAdd.FiscalPeriod = "Dec-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthFeb != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthFeb;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthFeb;
                        currStartAdd.FiscalPeriod = "Feb-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthJan != 0)
                    {
                        currStartAdd.FiscalYear = DateTime.Now.Year.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthJan;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthJan;
                        currStartAdd.FiscalPeriod = "Jan-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthJul != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthJul;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthJul;
                        currStartAdd.FiscalPeriod = "Jul-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthJun != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthJun;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthJun;
                        currStartAdd.FiscalPeriod = "Jun-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthMar != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthMar;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthMar;
                        currStartAdd.FiscalPeriod = "Mar-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthMay != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthMay;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthMay;
                        currStartAdd.FiscalPeriod = "May-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthNov != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthNov;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthNov;
                        currStartAdd.FiscalPeriod = "Nov-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthOct != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthOct;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthOct;
                        currStartAdd.FiscalPeriod = "Oct-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.NextFiscalMonthSep != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthSep;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthSep;
                        currStartAdd.FiscalPeriod = "Sep-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    if (item.YANFiscalMonthApr != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthApr;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthApr;
                        currStartAdd.FiscalPeriod = "Apr-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthAug != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthAug;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthAug;
                        currStartAdd.FiscalPeriod = "Aug-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthDec != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthDec;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthDec;
                        currStartAdd.FiscalPeriod = "Dec-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthFeb != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthFeb;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthFeb;
                        currStartAdd.FiscalPeriod = "Feb-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthJan != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.NextFiscalMonthSep;
                        currStartAdd.BudgetUSD = item.NextFiscalMonthSep;
                        currStartAdd.FiscalPeriod = "Jan-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthJul != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthJan;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthJan;
                        currStartAdd.FiscalPeriod = "Jul-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthJun != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthJun;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthJun;
                        currStartAdd.FiscalPeriod = "Jun-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthMar != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthMar;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthMar;
                        currStartAdd.FiscalPeriod = "Mar-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthMay != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthMay;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthMay;
                        currStartAdd.FiscalPeriod = "May-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthNov != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthNov;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthNov;
                        currStartAdd.FiscalPeriod = "Nov-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthOct != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthOct;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthOct;
                        currStartAdd.FiscalPeriod = "Oct-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.YANFiscalMonthSep != 0)
                    {
                        currStartAdd.FiscalYear = yearAfterNext.ToString();
                        currStartAdd.BudgetLC = item.YANFiscalMonthSep;
                        currStartAdd.BudgetUSD = item.YANFiscalMonthSep;
                        currStartAdd.FiscalPeriod = "Sep-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    //if (item.LastFiscalMonthApr != 0) { }
                    //if (item.LastFiscalMonthAug != 0) { }                    
                    //if (item.LastFiscalMonthFeb != 0) { }
                    //if (item.LastFiscalMonthJan != 0) { }
                    //if (item.LastFiscalMonthJul != 0) { }
                    //if (item.LastFiscalMonthJun != 0) { }
                    //if (item.LastFiscalMonthMar != 0) { }
                    //if (item.LastFiscalMonthMay != 0) { }
                    //if (item.LastFiscalMonthSep != 0) { }

                    if (item.LastFiscalMonthOct != 0)
                    {
                        currStartAdd.FiscalYear = lastYear.ToString();
                        currStartAdd.BudgetLC = item.LastFiscalMonthOct;
                        currStartAdd.BudgetUSD = item.LastFiscalMonthOct;
                        currStartAdd.FiscalPeriod = "Oct-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4" + "-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);

                        //if(item.LastFiscalMonthDec != currStart.BudgetLC && item.SupplierId == currStart.Id) _currentstartRepository.UpdateCurrentStart(currStart)) else
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    }
                    if (item.LastFiscalMonthNov != 0)
                    {
                        currStartAdd.FiscalYear = lastYear.ToString();
                        currStartAdd.BudgetLC = item.LastFiscalMonthNov;
                        currStartAdd.BudgetUSD = item.LastFiscalMonthNov;
                        currStartAdd.FiscalPeriod = "Nov-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4" + "-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);

                        //if(item.LastFiscalMonthDec != currStart.BudgetLC && item.SupplierId == currStart.Id) _currentstartRepository.UpdateCurrentStart(currStart)) else
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                    } 
                    if (item.LastFiscalMonthDec != 0)
                    {
                        currStartAdd.FiscalYear =lastYear.ToString();
                        currStartAdd.BudgetLC = item.LastFiscalMonthDec;
                        currStartAdd.BudgetUSD = item.LastFiscalMonthDec;
                        currStartAdd.FiscalPeriod = "Dec-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4" + "-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);

                        //if (item.LastFiscalMonthDec != currStart.BudgetLC  && item.SupplierId == currStart.Id)
                        //{

                        //    var content = currStart.ToPatchJsonContent();//Invoke the extension method to serialize the object
                        //    //UpdateRentCurrentStartInternal(currStart.Id, patchDoc);
                        //}
                        //else { 
                        _currentstartRepository.AddCurrentStart(currStartAdd);
                        SaveData();
                        //}
                    }



                }

                return new JsonResult(currStartAdd);

            }
            catch(Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            return Ok();

        }


        private IActionResult SaveData()
        {
            if (!_currentstartRepository.Save())
            {
                return StatusCode(500, "Problem creating Current Start Record.");
            }

            return Ok();
        }

        [HttpGet]
        [Route("taxSheet")]
        public IActionResult GetTaxSheetData()
        {
            var taxData =  _currentstartRepository.GetFormattedCurrentStarts();



            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            var fiscalYearExtracts = taxData
                                    .Where(c => c.FiscalYear != lastYear.ToString() && c.Scenario != "Actual");


            var currentStartActuals = taxData.Where(r => r.FiscalYear == lastYear.ToString());

            var highestActualsBy = currentStartActuals
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();



            var supplierList = taxData.Select(supplier => new RentsViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                POLineDescription = supplier.POLineDescription,
                LEComments = supplier.Comments,
                Scenario = supplier.Scenario,

                ///////////////////////last year///////////////////////////////////////
                LastFiscalYear = supplier.FiscalYear,
                LastFiscalQuarter = supplier.FiscalQuarter,
                LastFiscalPeriod = supplier.FiscalPeriod,
                LastFiscalDate = int.Parse(supplier.FiscalDate),
                LastFiscalMonthJan = (supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthFeb = (supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMar = (supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthApr = (supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMay = (supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJun = (supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJul = (supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthAug = (supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthSep = (supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthOct = (supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthNov = (supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthDec = (supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ///////////////////////this year/////////////////////////////////////////////
                ThisFiscalYear = supplier.FiscalYear,
                ThisFiscalQuarter = supplier.FiscalQuarter,
                ThisFiscalPeriod = supplier.FiscalPeriod,
                ThisFiscalDate = int.Parse(supplier.FiscalDate),
                ThisFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                /////////////////////////////////////next year///////////////////////////////////////////
                NextFiscalYear = supplier.FiscalYear,
                NextFiscalQuarter = supplier.FiscalQuarter,
                NextFiscalPeriod = supplier.FiscalPeriod,
                NextFiscalDate = int.Parse(supplier.FiscalDate),
                NextFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                //////////////////////////////////YAN////////////////////////////////////////////////////////////////////
                YANFiscalYear = supplier.FiscalYear,
                YANFiscalQuarter = supplier.FiscalQuarter,
                YANFiscalPeriod = supplier.FiscalPeriod,
                YANFiscalDate = int.Parse(supplier.FiscalDate),
                YANFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0



            });


            return new JsonResult(supplierList);
        }


        [Route("addTaxSupplier")]
        [HttpPost("addTSupplier")]
        public IActionResult CreateTaxSupplier(string[] currentStart)
        {

            if (currentStart == null)
            {
                return BadRequest();
            }

            try
            {
                var supplierData = JsonConvert.DeserializeObject<RentsViewModel[]>(currentStart[0]);

                var supplierDataList = supplierData.ToList();

                CurrentStart currStartAdd = null;
                foreach (var item in supplierDataList)
                {
                    var currStart = _currentstartRepository.GetCurrentStart(item.SupplierId);

                    currStartAdd = new CurrentStart()
                    {
                        ProjectName = currStart.ProjectName,
                        Scenario = "SEPLE",
                        POLineDescription = currStart.POLineDescription,
                        DepartmentNameNum = currStart.DepartmentNameNum,
                        BudgetUSD_1 = currStart.BudgetUSD_1,
                        BudgetLC_1 = currStart.BudgetLC_1,
                        Comments = currStart.Comments,

                        DepartmentName = currStart.DepartmentName,
                        DepartmentNumber = currStart.DepartmentNumber,
                        DepartmentGroup = currStart.DepartmentGroup,
                        DepartmentSubGroup = currStart.DepartmentSubGroup,
                        CostCenterNumber = currStart.CostCenterNumber,

                        AccountGroup = currStart.AccountGroup,
                        AccountNumber = currStart.AccountNumber,
                        NaturalAccountName = currStart.NaturalAccountName,
                        ProjectTaskNumber = currStart.ProjectTaskNumber,
                        PONumber = currStart.PONumber,
                        SupplierName = item.SupplierName,
                        SupplierNumber = currStart.SupplierNumber,
                        PurchaseInvoiceNumber = currStart.PurchaseInvoiceNumber,
                        ActualUSD = 0,
                        CountryCity = currStart.CountryCity,
                        Region = currStart.Region,
                        Region_Rpt = currStart.Region_Rpt,
                        FPAAccrualsReclasses = currStart.FPAAccrualsReclasses,
                        SupplierType = currStart.SupplierType,
                        FiscalDate = DateTime.Now.ToOADate().ToString(),
                        LocalCurrency = currStart.LocalCurrency,
                        OriginalSupplierName = currStart.OriginalSupplierName,
                        DepartmentRollOut = currStart.DepartmentRollOut,
                        UniqueListACC = currStart.UniqueListACC,
                        UniqueListDEPT = currStart.UniqueListDEPT,

                    };

                    if (item.ThisFiscalMonthApr != 0) { }
                    if (item.ThisFiscalMonthAug != 0) { }
                    if (item.ThisFiscalMonthDec != 0) { }
                    if (item.ThisFiscalMonthFeb != 0) { }
                    if (item.ThisFiscalMonthJan != 0) { }
                    if (item.ThisFiscalMonthJul != 0) { }
                    if (item.ThisFiscalMonthJun != 0) { }
                    if (item.ThisFiscalMonthMar != 0) { }
                    if (item.ThisFiscalMonthMay != 0) { }
                    if (item.ThisFiscalMonthNov != 0) { }
                    if (item.ThisFiscalMonthOct != 0) { }
                    if (item.ThisFiscalMonthSep != 0) { }

                    if (item.NextFiscalMonthApr != 0) { }
                    if (item.NextFiscalMonthAug != 0) { }
                    if (item.NextFiscalMonthDec != 0) { }
                    if (item.NextFiscalMonthFeb != 0) { }
                    if (item.NextFiscalMonthJan != 0) { }
                    if (item.NextFiscalMonthJul != 0) { }
                    if (item.NextFiscalMonthJun != 0) { }
                    if (item.NextFiscalMonthMar != 0) { }
                    if (item.NextFiscalMonthMay != 0) { }
                    if (item.NextFiscalMonthNov != 0) { }
                    if (item.NextFiscalMonthOct != 0) { }
                    if (item.NextFiscalMonthSep != 0) { }

                    if (item.YANFiscalMonthApr != 0) { }
                    if (item.YANFiscalMonthAug != 0) { }
                    if (item.YANFiscalMonthDec != 0) { }
                    if (item.YANFiscalMonthFeb != 0) { }
                    if (item.YANFiscalMonthJan != 0) { }
                    if (item.YANFiscalMonthJul != 0) { }
                    if (item.YANFiscalMonthJun != 0) { }
                    if (item.YANFiscalMonthMar != 0) { }
                    if (item.YANFiscalMonthMay != 0) { }
                    if (item.YANFiscalMonthNov != 0) { }
                    if (item.YANFiscalMonthOct != 0) { }
                    if (item.YANFiscalMonthSep != 0) { }


                }

                return new JsonResult(currStartAdd);

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            return Ok();

        }
        [Route("review/{departmentId}")]
        public IActionResult GetCurrentStartReview(SupplierResourceParameters supplierResourceParameters, string departmentId)
        {
            var currentStarts = _currentstartRepository.GetCurrentStartRents(supplierResourceParameters, departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            var supplierList = currentStarts.Select(supplier => new ReviewViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                AccountGroup = supplier.AccountGroup,
                NaturalAccountName = supplier.NaturalAccountName,

                ///////////////////////last year///////////////////////////////////////
                LastFiscalYear = supplier.FiscalYear,
                LastFiscalQuarter = supplier.FiscalQuarter,
                LastFiscalPeriod = supplier.FiscalPeriod,
                LastFiscalDate = Convert.ToInt32(Double.Parse(supplier.FiscalDate)),
                LastFiscalMonthJan = (supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthFeb = (supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMar = (supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthApr = (supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMay = (supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJun = (supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJul = (supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthAug = (supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthSep = (supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthOct = (supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthNov = (supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthDec = (supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ///////////////////////this year/////////////////////////////////////////////
                ThisFiscalYear = supplier.FiscalYear,
                ThisFiscalQuarter = supplier.FiscalQuarter,
                ThisFiscalPeriod = supplier.FiscalPeriod,
                ThisFiscalDate = Convert.ToInt32(Double.Parse(supplier.FiscalDate)),
                ThisFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                /////////////////////////////////////next year///////////////////////////////////////////
                NextFiscalYear = supplier.FiscalYear,
                NextFiscalQuarter = supplier.FiscalQuarter,
                NextFiscalPeriod = supplier.FiscalPeriod,
                NextFiscalDate = Convert.ToInt32(Double.Parse(supplier.FiscalDate)),
                NextFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                //////////////////////////////////YAN////////////////////////////////////////////////////////////////////
 
            });


            return new JsonResult(supplierList);
        }



        [Route("hyperion/{departmentId}")]
        public IActionResult GetCurrentStartHyperion(SupplierResourceParameters supplierResourceParameters, string departmentId)
        {
            var currentStarts = _currentstartRepository.GetCurrentStartRents(supplierResourceParameters, departmentId);
            var priorFcsts = _priorFcstRepository.GetPriorForecastRents(supplierResourceParameters, departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            //var lastPFTotals = priorFcsts
            //    .Where(p => p.FiscalYear == lastYear.ToString())
            //    .Select(g => g.TotalLC);

            //var thisPFTotals = priorFcsts
            //    .Where(p => p.FiscalYear == thisYear.ToString() )
            //    .Select(g => g.TotalLC); //.Sum(g => g.TotalLC);

            //var nextPFTotals = priorFcsts
            //        .Where(p => p.FiscalYear == nextYear.ToString())
            //        .Select(g => g.TotalLC);


            //var yanPFTotals = priorFcsts
            //        .Where(p => p.FiscalYear == yearAfterNext.ToString())
            //        .Select(g => g.TotalLC);

            var supplierList = currentStarts.Select(supplier => new ExportTableViewModel
            {
                AccountGroup = supplier.AccountGroup.Split("-")[0],
                DepartmentNameNum = supplier.DepartmentNameNum,

                    ///////////////////////this year/////////////////////////////////////////////
                ThisFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                /////////////////////////////////////next year///////////////////////////////////////////
                NextFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                //////////////////////////////////YAN////////////////////////////////////////////////////////////////////
                YANFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,

                YANYFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0


            });

            var highestBy = currentStarts
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();

            //TODO: get priorforecast and cache it
            //var groupList = supplierList
            //    .GroupBy(s => s.SupplierName)
            //    .ToList();


            //var groupList =
            //    from supplier in supplierList
            //    group supplier by supplier.SupplierName into newGroup
            //    orderby newGroup.Key
            //    select newGroup;

            return new JsonResult(supplierList);
        }
    }
}

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using LE.Core;
using LE.Data;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LEWebApp.Pages.LE
{
    public class FinalReviewModel : PageModel
    {
        private readonly IConfiguration _config;
        private readonly ILogger<FinalReviewModel> _logger;
        private readonly ICurrentStartData _currentStartData;
        private readonly ITargetedSupplierData _targetedSupplierData;
        private readonly IAppData _appData;
        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }
        public IEnumerable<CurrentStart> CurrentStarts { get; set; }
        public IEnumerable<TargetedSupplier> TargetedSuppliers { get; set; }

        public object[] Categories { get; set; }
        public List<decimal> Depreciation { get; set; }
        public List<decimal> Materials { get; set; }
        public List<decimal> Facilities { get; set; }
        public List<decimal> OustsideServices { get; set; }
        public List<decimal> Training { get; set; }
        public List<decimal> Travel { get; set; }
        public List<decimal> RentTax { get; set; }

        public Dictionary<string, List<decimal>> Series { get; set; }

        public string FullName { get; set; }
        public User UserData { get; set; }
        public ICollection<DepartmentString> Departments { get; set; }
        public string CurrentDepartment { get; set; }
        public int Year { get; set; }

        public FinalReviewModel(IConfiguration config, ICurrentStartData currentStartData, ITargetedSupplierData targetedSupplierData, IAppData appData, ILogger<FinalReviewModel> logger)
        {

            _config = config;
            _logger = logger;
            _appData = appData;
            _currentStartData = currentStartData;
            _targetedSupplierData = targetedSupplierData;
        }
        public async Task OnGetAsync()
        {
            CurrentDepartment = await _appData.GetCurrentDepartment();
            CurrentStarts = await _currentStartData.GetByDepartment(CurrentDepartment);


            //chart related
            var year = DateTime.Now.Year;
            var yearsList = new List<int>();
            //HACK for now
            yearsList.Add((year - 2));
            yearsList.Add((year - 1));
            yearsList.Add((year));
            yearsList.Add((year + 1));
            yearsList.Add((year + 2));
            // yearsList.Add((year + 3));

            Categories = yearsList.Select(i => (object)i).ToArray();
            // var filtered
            Depreciation = new List<decimal>();
            Materials = new List<decimal>();
            Facilities = new List<decimal>();
            OustsideServices = new List<decimal>();
            Training = new List<decimal>();
            Travel = new List<decimal>();
            RentTax = new List<decimal>();

            //series =  account groups
            /*    
             * Depreciation 
             * Materials & Suppliers 71000
             * Facilities and Equipment
             * Outside Services 65000
             * Training & Education 63000
             * Travel & Entertainment 62000
             * Rent & Property Tax 70205
             *  
             */

            UserData = _appData.GetUser();
            FullName = UserData.FirstName + " " + UserData.LastName;

            Departments = new Collection<DepartmentString>();
            foreach (var dp in UserData.Departments)
            {
                Departments.Add(dp);
            }

            Year = DateTime.Now.Year;

            try
            {

                foreach (var yr in yearsList)
                {
                    foreach (var item in CurrentStarts)
                    {
                        if (yr.ToString() == item.FiscalYear)
                        {
                            var depreciation = CurrentStarts.ToList<CurrentStart>().Where(c => c.AccountGroup != null && c.AccountGroup.StartsWith("AC_72000-Depreciation & Amortiztion")).ToList();
                            var materials = CurrentStarts.ToList<CurrentStart>().Where(c => c.AccountGroup != null && c.AccountGroup.StartsWith("AC_71000-Materials & Supplies")).ToList();
                            var facilities = CurrentStarts.ToList<CurrentStart>().Where(c => c.AccountGroup != null && c.AccountGroup.StartsWith("AC_70000-Facilities & Equipment")).ToList();
                            var outside = CurrentStarts.ToList<CurrentStart>().Where(c => c.AccountGroup != null && c.AccountGroup.StartsWith("AC_65000-Outside Services")).ToList();
                            var training = CurrentStarts.ToList<CurrentStart>().Where(c => c.AccountGroup != null && c.AccountGroup.StartsWith("AC_63000-Training & Education")).ToList();
                            var travel = CurrentStarts.ToList<CurrentStart>().Where(c => c.AccountGroup != null && c.AccountGroup.StartsWith("AC_62000-Employee Travel & Entertainment")).ToList();
                            var rent = CurrentStarts.ToList<CurrentStart>().Where(c => c.AccountGroup != null && c.AccountGroup.Contains("Lease") || c.AccountGroup.Contains("Tax")).ToList();

                            depreciation.ForEach(c => { Depreciation.Add(c.ActualUSD); });
                            materials.ForEach(c => { Materials.Add(c.ActualUSD); });
                            facilities.ForEach(c => { Facilities.Add(c.ActualUSD); });
                            outside.ForEach(c => { OustsideServices.Add(c.ActualUSD); });
                            training.ForEach(c => { Training.Add(c.ActualUSD); });
                            travel.ForEach(c => { Travel.Add(c.ActualUSD); });
                            rent.ForEach(c => { RentTax.Add(c.ActualUSD); });
                        }


                    }

                }

            }
            catch (Exception ex)
            {
                _logger.LogError("Final Review Exception: " + ex.Message);
            }

            _logger.LogInformation("Final Review: ");
        }
    }
}

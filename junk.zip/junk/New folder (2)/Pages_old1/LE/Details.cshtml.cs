﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using LE.Core;
using LE.Data;

namespace LEWebApp.Pages.LE
{
    public class DetailsModel : PageModel
    {
        private readonly LEDbContext _context;

        public DetailsModel(LEDbContext context)
        {
            _context = context;
        }

        public TargetedSupplier TargetedSupplier { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            TargetedSupplier = await _context.TargetedSuppliers.FirstOrDefaultAsync(m => m.Id == id);

            if (TargetedSupplier == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}

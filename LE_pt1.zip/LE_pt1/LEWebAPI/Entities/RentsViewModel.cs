﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LE.Core
{
    public class RentsViewModel
    {

        public int SupplierId { get; set; }
        [Required]
        [Display(Name = "Supplier Name")]
        public string SupplierName { get; set; }

        [Display(Name = "PO Line Description")]
        public string POLineDescription { get; set; }  //TODO: make this a list

        [Display(Name = "LE Comment")]
        public string LEComments { get; set; } //TODO: make this a list

        //variance increase priorforecast
        public decimal Variance { get; set; }
        public decimal Increase { get; set; }
        public decimal NextYearIncrease { get; set; }
        public decimal YANIncrease { get; set; }
        public string Scenario { get; set; }

        public string Blank { get; set; }
        public string VarianceComments { get; set; }

        public decimal LastPriorFcst { get; set; }
        public decimal ThisPriorFcst { get; set; }
        public decimal NextPriorFcst { get; set; }
        public decimal YANPriorFcst { get; set; }
        public decimal LastYearVariance { get; set; }
        public decimal ThisYearVariance { get; set; }
        public decimal NextYearVariance { get; set; }
        public decimal YANVariance { get; set; }
        public decimal LastYearTotal { get; set; }
        public decimal ThisYearTotal { get; set; }
        public decimal NextYearTotal { get; set; }
        public decimal YANYearTotal { get; set; }
        public string LastFiscalYear { get; set; }
        public string LastFiscalQuarter { get; set; }
        public string LastFiscalPeriod { get; set; }
        public int LastFiscalDate { get; set; }
        public decimal LastFiscalMonthJan { get; set; }
        public decimal LastFiscalMonthFeb { get; set; }
        public decimal LastFiscalMonthMar { get; set; }
        public decimal LastFiscalMonthApr { get; set; }
        public decimal LastFiscalMonthMay { get; set; }
        public decimal LastFiscalMonthJun { get; set; }
        public decimal LastFiscalMonthJul { get; set; }
        public decimal LastFiscalMonthAug { get; set; }
        public decimal LastFiscalMonthSep { get; set; }
        public decimal LastFiscalMonthOct { get; set; }
        public decimal LastFiscalMonthNov { get; set; }
        public decimal LastFiscalMonthDec { get; set; }
        /// <summary>
        /// ////////////////////////////////////////////////////////////////
        /// </summary>
        //******************************this year********************************//
        public string ThisFiscalYear { get; set; }
        public string ThisFiscalQuarter { get; set; }
        public string ThisFiscalPeriod { get; set; }
        public int ThisFiscalDate { get; set; }
        public decimal ThisFiscalMonthJan { get; set; }
        public decimal ThisFiscalMonthFeb { get; set; }
        public decimal ThisFiscalMonthMar { get; set; }
        public decimal ThisFiscalMonthApr { get; set; }
        public decimal ThisFiscalMonthMay { get; set; }
        public decimal ThisFiscalMonthJun { get; set; }
        public decimal ThisFiscalMonthJul { get; set; }
        public decimal ThisFiscalMonthAug { get; set; }
        public decimal ThisFiscalMonthSep { get; set; }
        public decimal ThisFiscalMonthOct { get; set; }
        public decimal ThisFiscalMonthNov { get; set; }
        public decimal ThisFiscalMonthDec { get; set; }

        /// <summary>
        /// ////////////////////////////////////////////////////////////////
        /// </summary>
        //******************************next year********************************//

        public string NextFiscalYear { get; set; }
        public string NextFiscalQuarter { get; set; }
        public string NextFiscalPeriod { get; set; }
        public int NextFiscalDate { get; set; }
        public decimal NextFiscalMonthJan { get; set; }
        public decimal NextFiscalMonthFeb { get; set; }
        public decimal NextFiscalMonthMar { get; set; }
        public decimal NextFiscalMonthApr { get; set; }
        public decimal NextFiscalMonthMay { get; set; }
        public decimal NextFiscalMonthJun { get; set; }
        public decimal NextFiscalMonthJul { get; set; }
        public decimal NextFiscalMonthAug { get; set; }
        public decimal NextFiscalMonthSep { get; set; }
        public decimal NextFiscalMonthOct { get; set; }
        public decimal NextFiscalMonthNov { get; set; }
        public decimal NextFiscalMonthDec { get; set; }

        /// <summary>
        /// ////////////////////////////////////////////////////////////////
        /// </summary>
        //******************************year after next year********************************//
        public string YANFiscalYear { get; set; }
        public string YANFiscalQuarter { get; set; }
        public string YANFiscalPeriod { get; set; }
        public int YANFiscalDate { get; set; }
        public decimal YANFiscalMonthJan { get; set; }
        public decimal YANFiscalMonthFeb { get; set; }
        public decimal YANFiscalMonthMar { get; set; }
        public decimal YANFiscalMonthApr { get; set; }
        public decimal YANFiscalMonthMay { get; set; }
        public decimal YANFiscalMonthJun { get; set; }
        public decimal YANFiscalMonthJul { get; set; }
        public decimal YANFiscalMonthAug { get; set; }
        public decimal YANFiscalMonthSep { get; set; }
        public decimal YANFiscalMonthOct { get; set; }
        public decimal YANFiscalMonthNov { get; set; }
        public decimal YANFiscalMonthDec { get; set; }
    }

    public class FiscalInfoViewModel
    {
        public string FiscalYear { get; set; }
        public string FiscalQuarter { get; set; }
        public string FiscalPeriod { get; set; }
        public string FiscalDate { get; set; }
        public decimal FiscalMonthJan { get; set; }
        public decimal FiscalMonthFeb { get; set; }
        public decimal FiscalMonthMar { get; set; }
        public decimal FiscalMonthApr { get; set; }
        public decimal FiscalMonthMay { get; set; }
        public decimal FiscalMonthJun { get; set; }
        public decimal FiscalMonthJul { get; set; }
        public decimal FiscalMonthAug { get; set; }
        public decimal FiscalMonthSep { get; set; }
        public decimal FiscalMonthOct { get; set; }
        public decimal FiscalMonthNov { get; set; }
        public decimal FiscalMonthDec { get; set; }

    }
}

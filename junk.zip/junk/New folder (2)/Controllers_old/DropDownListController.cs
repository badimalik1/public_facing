﻿using LE.Core;
using LE.Data;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class DropDownListController : Controller
    {
        private readonly IAppData _appData;
        private readonly ITargetedSupplierData _targetedData;
        public List<TargetedSupplier> TargetedSuppliers { get; set; }

        public DropDownListController(IAppData appData, ITargetedSupplierData targetedData)
        {
            _appData = appData;
            _targetedData = targetedData;

            TargetedSuppliers = new List<TargetedSupplier>();
        }
        public IActionResult Index()
        {
            return View();
        }

        public async Task<JsonResult> RemoteDataSource_GetSuppliers(string text)
        {

            var supplierids = await  _appData.GetSupplierIds();

            if (supplierids != null)
            {
                foreach (var id in supplierids)
                {
                    var supplier = await _targetedData.GetById(id);
                    TargetedSuppliers.Add(supplier);
                }                          
            }

            return Json(TargetedSuppliers.ToList());
        }

    }
}

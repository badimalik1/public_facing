﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using LEWebAPI.Services;
using LEWebAPI.Entities;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Serialization;
using AutoMapper;
using LEWebAPI.MappingProfiles;
using Microsoft.AspNetCore.Http.Features;

namespace LEWebAPI
{
    public class Startup
    {
        public static IConfiguration Configuration;
        readonly string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            Configuration = configuration;

            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appSettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appSettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();

            Configuration = builder.Build();
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().AddJsonOptions(o => {
                if (o.SerializerSettings.ContractResolver != null)
                {
                    var castedResolver = o.SerializerSettings.ContractResolver as DefaultContractResolver;
                    castedResolver.NamingStrategy = null;
                }
            });

            services.AddMvc().AddJsonOptions(
            options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);

            var connectionString = Configuration["connectionStrings:leDBConnectionString"];
            services.AddDbContext<LEDbContext>(o => o.UseSqlServer(Microsoft.Extensions.Configuration.ConfigurationExtensions.GetConnectionString(Configuration, "leDBConnectionString")));
            // register the DbContext on the container, getting the connection string from
            // appSettings (note: use this during development; in a production environment,
            // it's better to store the connection string in an environment variable)

            // services.AddDbContext<LEDbContext>(o => o.UseSqlServer(connectionString));

            services.AddCors(options =>
            {
                options.AddPolicy(name: MyAllowSpecificOrigins,
                                  builder =>
                                  {
                                      builder.WithOrigins("https://localhost:44308",
                                                          "https://localhost:44328",
                                                          "https://localhost:44328/api/currentstart/",
                                                          "https://localhost:44308/*",
                                                          "https://dev-operationslepilot.gilead.com:443",
                                                          "https://dev-operationslepilot.gilead.com:443/LE/SupplierForecast",
                                                          "https://dev-operationslepilot.gilead.com/LE/SupplierForecast",
                                                          "https://localhost:44328/api/targetedsuppliers/",
                                                          "https://localhost:44328/api/targetedsuppliers/*",
                                                          "https://localhost:44328/api/targetedsuppliers/getSuppliersByName/*",
                                                          "https://localhost:44328/api/app/SetAddedSuppliers",
                                                          "https://localhost:44328/api/app/addCurrentStart",
                                                          "https://localhost:44308/api/app/addCurrentStart",
                                                          "https://dev-operationslepilot.gilead.com/api/app/addCurrentStart",
                                                          "https://localhost:44328/api/currentstart/rents",
                                                          "https://localhost:44308/api/currentstart/rents/",
                                                          "https://dev-operationslepilot.gilead.com/api/currentstart/rents/",
                                                          "https://localhost:44328/api/currentstart/review",
                                                          "https://localhost:44308/api/currentstart/review/",
                                                          "https://dev-operationslepilot.gilead.com/api/currentstart/review/",
                                                          "https://localhost:44328/api/currentstart/submit/variance",
                                                          "https://localhost:44308/api/currentstart/submit/variance",
                                                          "https://dev-operationslepilot.gilead.com/api/currentstart/submit/variance",
                                                          "https://localhost:44328/api/user/")
                                              .AllowAnyHeader()
                                              .AllowAnyMethod();
                                  });
            });

            services.Configure<FormOptions>(options =>
            {
                options.ValueCountLimit = 1024 * 1024; // 200 items max
                options.ValueLengthLimit = 1024 * 1024 * 100; // 100MB max len form data
            });

            // register the repository
            services.AddScoped<ILERepository, LERepository>();
            services.AddScoped<IUserRepository, UserRepository>(); //
            services.AddScoped<ICurrentStartRepository, CurrentStartRepository>();
            services.AddScoped<IPriorForecastRepository, PriorForecastRepository>();
            services.AddScoped<ITargetedSupplierRepository, TargetedSupplierRepository>();
            services.AddSingleton<IApplicationDataRepository, ApplicationDataRepository>();
            services.AddAutoMapper(typeof(Startup), typeof(EntityToDTOProfile));
            //services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            //services.AddScoped<IUrlHelper, UrlHelper>(impFactory =>
            //{
            //    var actionContext = impFactory.GetService<IActionContextAccessor>().ActionContext;
            //    return new UrlHelper(actionContext);
            //});

            //services.AddTransient<IPropertyMappingService, PropertyMappingService>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, LEDbContext lEDbContext)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }
           // lEDbContext.EnsureSeedDataForContext();

            app.UseStatusCodePages();
            app.UseMvc();
        }
    }
}

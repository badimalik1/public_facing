using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using LE.Core;
using LE.Data;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LEWebApp.Pages.LE
{
    public class HyperionExtractModel : PageModel
    {
        private readonly IAppData _appData;
        private readonly IConfiguration _config;
        private readonly ILogger<HyperionExtractModel> _logger;
        private readonly ICurrentStartData _currentStartData;
        private readonly ITargetedSupplierData _targetedSupplierData;

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }
        public string FullName { get; set; }
        public ICollection<DepartmentString> Departments { get; set; }
        public IEnumerable<CurrentStart> CurrentStarts { get; set; }
        public IEnumerable<TargetedSupplier> TargetedSuppliers { get; set; }

        public User UserData { get; set; }
        public string CurrentDepartment { get; set; }
        public int Year { get; set; }

        HttpClient _httpClient;

        protected int timeoutInSeconds;
        protected const int DEFAULT_TIMEOUT = 600;


        public int Timeout
        {
            get
            {
                return (int)_httpClient.Timeout.TotalSeconds;
            }
            set
            {
                timeoutInSeconds = value;
            }
        }

        public HyperionExtractModel(IConfiguration config, ICurrentStartData currentStartData, ITargetedSupplierData targetedSupplierData, IAppData appData, ILogger<HyperionExtractModel> logger)
        {
            _config = config;
            _logger = logger;
            _currentStartData = currentStartData;
            _targetedSupplierData = targetedSupplierData;
            _appData = appData;
        }
        public async Task OnGetAsync()
        {
            UserData = _appData.GetUser();
            FullName = UserData.FirstName + " " + UserData.LastName;

            Departments = new Collection<DepartmentString>();
            foreach (var dp in UserData.Departments)
            {
                Departments.Add(dp);
            }

            Year = DateTime.Now.Year;

            _logger.LogInformation("Rent Forecast OnGetAsync");

            CurrentDepartment = await _appData.GetCurrentDepartment();

        }
    }
}

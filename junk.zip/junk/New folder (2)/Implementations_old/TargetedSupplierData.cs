﻿using LE.Core;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data
{
    public class TargetedSupplierData : BaseDataImpl, ITargetedSupplierData
    {

        private readonly LEDbContext _db;
        HttpClient _httpClient;

        protected HttpClient CreateHttpClient()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            return _httpClient;
        }

        public TargetedSupplierData(LEDbContext db) 
        {
            _db = db;
        }

        public TargetedSupplier AddSupplier(TargetedSupplier newTargetedSupplier)
        {
            _db.Add(newTargetedSupplier);

            return newTargetedSupplier;
        }

        public int Commit()
        {
            return _db.SaveChanges();
        }

        //public TargetedSupplier Delete(int id)
        //{
        //    var supplier = GetById(id);
        //    if (supplier != null)
        //    {
        //        _db.TargetedSuppliers.Remove(supplier);
        //    }
        //    return supplier;
        //}

        public async Task<IEnumerable<TargetedSupplier>> GetAll()
        {
            return _db.TargetedSuppliers
               .OrderBy(a => a.SupplierName)
               .ThenBy(a => a.Id)
               .Skip(10 * (0))
               .Take(10)
               .ToList();
        }



        public async Task<TargetedSupplier> GetById(int id)
        {
            return _db.TargetedSuppliers.SingleOrDefault(t =>  t.Id == id);
        }

        public IEnumerable<TargetedSupplier> GetBySuplierNumber(int supplierNumber)
        {
            return _db.TargetedSuppliers.Where (t => t.SupplierNumber == supplierNumber);
        }

        public IEnumerable<TargetedSupplier> GetByDepartmentId(string departmentId)
        {
            return _db.TargetedSuppliers.Where(t => t.DepartmentID == departmentId);
        }

        public int GetCountOfSuppliers()
        {
            return _db.TargetedSuppliers.Count();
        }

        public async Task<IEnumerable<TargetedSupplier>> GetSuppliersByName(string name)
        {
            return from t in _db.TargetedSuppliers
                where string.IsNullOrEmpty(name) || t.SupplierName.StartsWith(name)
                orderby t.SupplierName
                select t;
        }

        public async Task<IEnumerable<TargetedSupplier>> GetSuppliersByNameAPI(string name)
        {
            using (httpClient = CreateHttpClient())
            {
                //TODO: get from config
                httpClient.BaseAddress = new Uri("https://localhost:44328/");//baseUri
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var timeSpan = timeoutInSeconds >= 1 ? new TimeSpan(0, 0, timeoutInSeconds) : TimeSpan.FromSeconds(DEFAULT_TIMEOUT);
                httpClient.Timeout = timeSpan;

                var request = new HttpRequestMessage(HttpMethod.Get, "api/targetedsuppliers");

                var uri = httpClient.BaseAddress.ToString() + request.RequestUri;

                try
                {
                    var regResponse = await httpClient.GetAsync(uri);

                    if (regResponse.IsSuccessStatusCode)
                    {
                        var regResponseString = await regResponse.Content.ReadAsStringAsync();
                        var supplier = JsonConvert.DeserializeObject<IEnumerable<TargetedSupplier>>(regResponseString);                      

                        return supplier;
                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

                return null;

            }
        }

        public async  Task<TargetedSupplier> AddSupplierAPI(TargetedSupplier supplier)
        {
            using (_httpClient = CreateHttpClient())
            {
                _httpClient.BaseAddress = new Uri("https://localhost:44328/"); //BaseUri

                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var rqst = new HttpRequestMessage(HttpMethod.Post, "api/targetedsuppliers/createTargetdSupplier");

                var uri = _httpClient.BaseAddress.ToString() + rqst.RequestUri;


                var content = new StringContent(JsonConvert.SerializeObject(supplier), Encoding.UTF8, "application/json");

                try
                {
                    HttpResponseMessage response = await _httpClient.PostAsync(uri, content);

                    if (response.IsSuccessStatusCode)
                    {
                        var responseString = await response.Content.ReadAsStringAsync();
                        var targetedsupplier = JsonConvert.DeserializeObject<TargetedSupplier>(responseString);
                        return targetedsupplier;
                    }
                    else
                    {
                        Debug.WriteLine("Response Failed -- " + response.ReasonPhrase.ToString() + " :: " + response.StatusCode.ToString());
                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Failed: " + ex.Message);
                }

                return null;
            }
        }

        public TargetedSupplier Update(TargetedSupplier updatedTargetedSupplier)
        {
            var entity = _db.TargetedSuppliers.Attach(updatedTargetedSupplier);
            entity.State = EntityState.Modified;

            return updatedTargetedSupplier;
        }
    }
}

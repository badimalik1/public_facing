﻿using LE.Core;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Interfaces
{
    public interface ICurrentStartData
    {
        bool Commit();
        int GetCountOfForcasts();
        void Delete(int id);
        CurrentStart GetById(int id);
        void DeleteForecast(int currentStartID);
        //CurrentStart GetCurrentStart(int id);
        Task<IEnumerable<CurrentStart>> GetAll();
        CurrentStart Update(CurrentStart updatedForcast);
        int AddForecast(CurrentStart currentStart);
        Task<IEnumerable<CurrentStart>> GetByDepartment(string dept);
        Task<IEnumerable<CurrentStart>> GetCurrentStartByIdAPI(string deptId);
        IEnumerable<CurrentStart> GetForcastsByName(string name, string dept);

        IEnumerable<CurrentStart> ReadSupplierForecast(string dept);
        IEnumerable<CurrentStart> GetByFiscalPeriod(string fiscalPeriod, string supplierName,
                                       string poNum, string poLineDescription);

    }
}

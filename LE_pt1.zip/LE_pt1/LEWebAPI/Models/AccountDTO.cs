﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LEWebAPI.Models
{
    public class AccountDTO
    {

        public int Id { get; set; }
        public string AccountName { get; set; }
        public string AccountGroup { get; set; }
        public int AccountNum { get; set; }

        public string NaturalAccountName { get; set; }
        public string Controllable { get; set; }
        public string Discretionary { get; set; }
        public string ForecastScheme_1 { get; set; }
        public string ForecastScheme_2 { get; set; }
        public string ForecastScheme_3 { get; set; }
        public string ForecastScheme_4 { get; set; }
        public string ForecastScheme_5 { get; set; }
        public string ForecastScheme_6 { get; set; }
        public string ForecastScheme_7 { get; set; }
        public string ForecastScheme_8 { get; set; }
        public string ForecastScheme_9 { get; set; }
        public string ForecastScheme_10 { get; set; }



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LE.Core
{
    public class GileadWideSupplier
    {
        public int Id { get; set; }
        public int SupplierNumber { get; set; }
        public string SupplierName { get; set; }
        public DateTime SupplierCreationDate { get; set; }
        public string SupplierParentName { get; set; }
        public string OperatingUnit { get; set; }
        public string OperatingUnitCountry { get; set; }
        public string SupplierCountry { get; set; }
        public string SupplierCountryName { get; set; }
        public int SupplierRegInitiatorDeptID { get; set; }
        public int SupplierRegApproverDeptID { get; set; }
        public string SupplierType { get; set; }
        public string SupplierInvoiceCurrency { get; set; }
        public string Description { get; set; }

    }
}

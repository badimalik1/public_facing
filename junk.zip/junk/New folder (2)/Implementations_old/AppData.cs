﻿using LE.Core;
using LE.Data.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Implementations
{
    public class AppData : BaseDataImpl, IAppData
    {
        User _user { get; set; }
        string _currentDepartment { get; set; }
        string _fullName { get; set; }
        string _section { get; set; }

        List<int> _supplierIds { get; set; }

        HttpClient _httpClient;
        protected readonly LEDbContext _db;

        protected HttpClient CreateHttpClient()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            return _httpClient;
        }

       public async  Task<IEnumerable<int>> GetSupplierIds()
        {
            using (_httpClient = CreateHttpClient())
            {
                //TODO: get from config
                _httpClient.BaseAddress = new Uri("https://localhost:44328/");//baseUri
                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var timeSpan = timeoutInSeconds >= 1 ? new TimeSpan(0, 0, timeoutInSeconds) : TimeSpan.FromSeconds(DEFAULT_TIMEOUT);
                _httpClient.Timeout = timeSpan;

                var request = new HttpRequestMessage(HttpMethod.Get, "api/app/GetSupplierIds");

                var uri = _httpClient.BaseAddress.ToString() + request.RequestUri;

                try
                {
                    var regResponse = await _httpClient.GetAsync(uri);

                    if (regResponse.IsSuccessStatusCode)
                    {
                        var regResponseString = await regResponse.Content.ReadAsStringAsync();
                        var ids = JsonConvert.DeserializeObject<IEnumerable<int>>(regResponseString);

                        return ids;
                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

                return null;

            }
        }

        public User GetUser()
        {
            return _user;
        }

        public async Task SetUser(User user)
        {
            _user = user;

            if (_user != null)
                await SetApplicationData("api/app/SetUser",  _user);

        }

        public string GetName()
        {
            return _fullName;
        }

        public void SetName(string name)
        {
            _fullName = name;
        }

        public string GetSection()
        {
            return _section;
        }

        public void SetSection(string section)
        {
            _section = section;
        }
        public async Task<string> GetCurrentDepartment()
        {
            string route = "api/app/GetCurrentDepartment";

            if(string.IsNullOrEmpty(_currentDepartment))
                _currentDepartment = await GetApplicationData(route);

            return _currentDepartment;
        }

        public void SetDepartment(string department)
        {
            _currentDepartment = department;
        }


        public User GetUser(string username, string password)
        {
            if (_user == null)
            {
                var user = _db.Users
                    .SingleOrDefault(u => u.Email == username && u.Password == password);

                //HACK: fix later
                //..var departments = _context.DepartmentStrings;
                var departmentNameNums = _db.DepartmentStrings
                                        .Select(d => _db.DepartmentStrings.Where(n => n.UserId == user.Id));

                user.Departments = new List<DepartmentString>();

                foreach (var dpt in departmentNameNums)
                {
                    foreach (var dp in dpt)
                    {
                        user.Departments.Add(dp);
                    }
                    break;
                }
                _user = user;
            }
            //await SetUser(_user);

            return _user;
        }
        public ICollection<DepartmentString> GetDepartments(int userId)
        {

            var depts = new List<DepartmentString>();

            var departmentNameNums = _db.DepartmentStrings
                                        .Select(d => _db.DepartmentStrings.Where(n => n.UserId == (_user != null ? _user.Id : userId)));


            foreach (var dpt in departmentNameNums)
            {
                foreach (var dp in dpt)
                {
                    depts.Add(dp);
                }
                break;
            }
            return depts;


        }


        private async Task<string> GetApplicationData(string route)
        {
            using (_httpClient = CreateHttpClient())
            {
                //TODO: get from config
                _httpClient.BaseAddress = new Uri("https://localhost:44328/");//baseUri
                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var timeSpan = timeoutInSeconds >= 1 ? new TimeSpan(0, 0, timeoutInSeconds) : TimeSpan.FromSeconds(DEFAULT_TIMEOUT);
                _httpClient.Timeout = timeSpan;

                var request = new HttpRequestMessage(HttpMethod.Get, route);

                var uri = _httpClient.BaseAddress.ToString() + request.RequestUri;

                try
                {
                    var regResponse = await _httpClient.GetAsync(uri);

                    if (regResponse.IsSuccessStatusCode)
                    {
                        var regResponseString = await regResponse.Content.ReadAsStringAsync();
                        var currDepartment = JsonConvert.DeserializeObject<string>(regResponseString);

                        return currDepartment;
                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

                return null;

            }
        }

        public async Task<object> SetApplicationData(string route, object postObj)
        {

            using (_httpClient = CreateHttpClient())
            {
                _httpClient.BaseAddress = new Uri("https://localhost:44328/"); //BaseUri

                _httpClient.DefaultRequestHeaders.Accept.Clear();
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var rqst = new HttpRequestMessage(HttpMethod.Post, route);

                var uri = _httpClient.BaseAddress.ToString() + rqst.RequestUri;


                var content = new StringContent(JsonConvert.SerializeObject(postObj), Encoding.UTF8, "application/json");

                try
                {
                    return await PostAsync(_httpClient, uri, content);

                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Failed: " + ex.Message);
                }

                return null;
            }

        }


        private async Task<object> PostAsync(HttpClient client, string uri, StringContent content)
        {
            try
            {
                HttpResponseMessage response = await client.PostAsync(uri, content);

                if (response.IsSuccessStatusCode)
                {
                    var responseString = await response.Content.ReadAsStringAsync();
                    return responseString;
                }
                else
                {
                    Debug.WriteLine("Response Failed -- " + response.ReasonPhrase.ToString() + " :: " + response.StatusCode.ToString());
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            return null;
        }
    }
}

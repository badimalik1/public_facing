﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LEWebAPI.Entities;
using LEWebAPI.Helpers;

namespace LEWebAPI.Services
{
    public class PriorForecastRepository : IPriorForecastRepository
    {

        LEDbContext _context;
        IApplicationDataRepository _appData;

        public PriorForecastRepository(LEDbContext context, IApplicationDataRepository appData)
        {
            _appData = appData;
            _context = context;
        }

        public IEnumerable<PriorForecast> GetPriorForecasts(SupplierResourceParameters supplierResourceParameters)
        {
            return _context.PriorForecasts
                .OrderBy(a => a.DepartmentNameNum)
                .ThenBy(a => a.Id)
                .Skip(supplierResourceParameters.PageSize * (supplierResourceParameters.PageNumber - 1))
                .Take(supplierResourceParameters.PageSize)
                .ToList();
        }

        public IEnumerable<PriorForecast> GetPriorForecastRaw(SupplierResourceParameters supplierResourceParameters, string departmentNumber)
        {
            return _context.PriorForecasts
                .Where(a => a.DepartmentNumber == departmentNumber)
                .OrderBy(a => a.DepartmentNameNum)
                .ThenBy(a => a.Id)
                .Skip(supplierResourceParameters.PageSize * (supplierResourceParameters.PageNumber - 1))
                .Take(supplierResourceParameters.PageSize)
                .ToList();
        }

        public bool SupplierExists(string supplierName)
        {
            //TODO: search gileadwide suppliers as well
            return _context.TargetedSuppliers.Any(t => t.SupplierName == supplierName);
        }

        public IEnumerable<PriorForecast> GetPriorForecast(SupplierResourceParameters supplierResourceParameters, string departmentNumber)
        {

            _appData.SetDepartment(departmentNumber);

            var forecasts = _context.PriorForecasts
                .Where(a => a.DepartmentNameNum == (_appData.GetCurrentDepartment()))
                .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits" && a.AccountGroup != "AC_72000-Deprecation & Amortization" &&
                            a.AccountGroup != "AC_73000-Other General Expense" && a.AccountGroup != "AC_68000-Promotional Programs" &&
                            a.AccountGroup != "AC_63000-Training & Education" && a.AccountGroup != "AC_67000-Grants & Medical Education" &&
                            a.AccountGroup != "AC_66000-Insurance")
                .Where(n => n.NaturalAccountName != "Airfare" && !n.NaturalAccountName.StartsWith("Meals & Entertainment") && !n.NaturalAccountName.StartsWith("Other Travel & Lodging") &&
                            n.NaturalAccountName != "Business Gifts" && n.NaturalAccountName != "Employee Relations 1")
                .Where(s => s.SupplierName != "No Supplier Name" && s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                .Where(r => r.AccountNumber != 70015 && r.AccountNumber != 70020 &&
                           r.AccountNumber != 70025 && r.AccountNumber != 70205 &&
                           r.AccountNumber != 70065 && r.AccountNumber != 70070)
                .OrderBy(a => a.SupplierName)
                .Skip(5000 * (supplierResourceParameters.PageNumber - 1))
                .Take(5000)
                .ToList();

            return forecasts;
        }
        public IEnumerable<PriorForecast> GetPriorForecastRents(SupplierResourceParameters supplierResourceParameters, string departmentNumber)
        {
            return _context.PriorForecasts
                .Where(a => a.DepartmentNameNum == _appData.GetCurrentDepartment())
                .Where(n => n.NaturalAccountName == "Building Lease Expense" || n.NaturalAccountName.Contains("Short-Term Lease") || n.NaturalAccountName.Contains("Lease Expense") &&
                            n.NaturalAccountName == "Variable Lease Cost for Building" || n.NaturalAccountName == "Lease Expense" || n.NaturalAccountName == "Immaterial Lease" &&
                            n.NaturalAccountName.Contains("Operating Lease Expense") || n.POLineDescription.Contains("Lease") || n.NaturalAccountName.Contains("Lease"))
                .Where(r => r.AccountNumber != 70205)
                .Where(s => s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                .Where(t => !t.POLineDescription.Contains("Tax") && !t.AccountGroup.Contains("Tax"))
                .OrderBy(a => a.SupplierName)
                .Skip(5000 * (supplierResourceParameters.PageNumber - 1))
                .Take(5000)
                .ToList();
        }

        public IEnumerable<PriorForecast> GetPriorForecastTaxes(SupplierResourceParameters supplierResourceParameters, string departmentNumber)
        {
            return _context.PriorForecasts
                .Where(a => a.DepartmentNameNum == _appData.GetCurrentDepartment())
                .Where(r => r.AccountNumber == 70205)
                .Where(s => s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                .OrderBy(a => a.SupplierName)
                .Skip(5000 * (supplierResourceParameters.PageNumber - 1))
                .Take(5000)
                .ToList();
        }


    }
}

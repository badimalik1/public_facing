﻿using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using LEWebApp.Helpers;
using System.Diagnostics;
using Microsoft.AspNetCore.JsonPatch;
using LEWebApp.DTOS;
using AutoMapper;

namespace LEWebApp.Controllers
{
    public class SupplierDetailController : Controller
    {
        private readonly IAppData _appData;
        private readonly IMapper _mapper;
        private readonly IPendingData _pendingData;
        private readonly IPreferencesData _prefsData;
        private readonly ICurrentStartData _currentStartData;
        private readonly IPriorForecastData _priorForecastData;
        
        public string CurrentDepartment { get; set; }
        public IEnumerable<CurrentStart> CurrentStarts { get; set; }

        //[FromQuery(Name = "supplierName")]
        public string SupplierName { get; set; }

        private CurrentStart CurrentStartAdd;


        public SupplierDetailController(IAppData appData, ICurrentStartData currentStartData,
                                        IPreferencesData prefsData, IPendingData pendingData, 
                                        IPriorForecastData priorForecastData, IMapper mapper)
        {
            _appData = appData;
            _mapper = mapper;
            _prefsData = prefsData;
            _pendingData = pendingData;
            _currentStartData = currentStartData;
            _priorForecastData = priorForecastData;
        }

        public async Task<IActionResult> GetSupplierDetailsAsync()
        {
            CurrentDepartment = await _appData.GetCurrentDepartment();
            CurrentStarts = _currentStartData.GetForcastsByName(SupplierName, CurrentDepartment);

            return Ok();
        }


        [HttpGet()]
        public IActionResult GetCurrentStartDetails(string departmentId, string supplierName)
        {

            var startYear = int.Parse(_prefsData.GetStartYear());
            var thisYear = (startYear - 1).ToString().Substring(2, 2);
            var nextYear = (startYear).ToString().Substring(2, 2);  //i know...i know...startyear==thisyear=the year in the db
            var yanYear = (startYear + 1).ToString().Substring(2, 2);
            var yearAfterYanYear = (startYear + 2).ToString().Substring(2, 2);

            var janNextYear = DateHelpers.ConvertFiscalPeriod(1, nextYear);
            var febNextYear = DateHelpers.ConvertFiscalPeriod(2, nextYear);
            var marNextYear = DateHelpers.ConvertFiscalPeriod(3, nextYear);
            var aprNextYear = DateHelpers.ConvertFiscalPeriod(4, nextYear);
            var mayNextYear = DateHelpers.ConvertFiscalPeriod(5, nextYear);
            var junNextYear = DateHelpers.ConvertFiscalPeriod(6, nextYear);
            var julNextYear = DateHelpers.ConvertFiscalPeriod(7, nextYear);
            var augNextYear = DateHelpers.ConvertFiscalPeriod(8, nextYear);
            var sepNextYear = DateHelpers.ConvertFiscalPeriod(9, nextYear);
            var octNextYear = DateHelpers.ConvertFiscalPeriod(10, nextYear);
            var novNextYear = DateHelpers.ConvertFiscalPeriod(11, nextYear);
            var decNextYear = DateHelpers.ConvertFiscalPeriod(12, nextYear);

            var janThisYear = DateHelpers.ConvertFiscalPeriod(1, thisYear);
            var febThisYear = DateHelpers.ConvertFiscalPeriod(2, thisYear);
            var marThisYear = DateHelpers.ConvertFiscalPeriod(3, thisYear);
            var aprThisYear = DateHelpers.ConvertFiscalPeriod(4, thisYear);
            var mayThisYear = DateHelpers.ConvertFiscalPeriod(5, thisYear);
            var junThisYear = DateHelpers.ConvertFiscalPeriod(6, thisYear);
            var julThisYear = DateHelpers.ConvertFiscalPeriod(7, thisYear);
            var augThisYear = DateHelpers.ConvertFiscalPeriod(8, thisYear);
            var sepThisYear = DateHelpers.ConvertFiscalPeriod(9, thisYear);
            var octThisYear = DateHelpers.ConvertFiscalPeriod(10, thisYear);
            var novThisYear = DateHelpers.ConvertFiscalPeriod(11, thisYear);
            var decThisYear = DateHelpers.ConvertFiscalPeriod(12, thisYear);

            var supplierList = _appData.GetSupplierNames();
            var priorFcsts = _priorForecastData.GetBySuplierName(supplierName,  departmentId);
 
            var currStartList = _currentStartData.GetForcastsByName(supplierName, departmentId);

            var lineItems = currStartList.Select(supplier => new SupplierDetailsViewModel
            {
                NaturalAccountName = supplier.NaturalAccountName,
                PONumber = supplier.PONumber,
                POLineDescription = supplier.POLineDescription,
                Scenario = supplier.Scenario,
                LEComments = supplier.Comments,
                CurrentStartId = supplier.Id,
                VarianceComments = supplier.VarianceComments,

                NextFiscalMonthJan = supplier.FiscalPeriod == janNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod == febNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod == marNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod == aprNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod == mayNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod == junNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod == julNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod == augNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod == sepNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod == octNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod == novNextYear ? supplier.TotalLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod == decNextYear ? supplier.TotalLC : 0,

                ThisFiscalMonthJan = supplier.FiscalPeriod == janThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod == febThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod == marThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod == aprThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod == mayThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod == junThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod == julThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod == augThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod == sepThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod == octThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod == novThisYear ? supplier.TotalLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod == decThisYear ? supplier.TotalLC : 0,
                
                ThisPriorFcst = priorFcsts.Where(p => p.FiscalYear == "20"+thisYear.ToString() && p.PONumber == supplier.PONumber).Sum(g => g.TotalLC),
                NextPriorFcst = priorFcsts.Where(p => p.FiscalYear == "20" + nextYear.ToString() && p.PONumber == supplier.PONumber).Sum(g => g.TotalLC),
                YANPriorFcst = priorFcsts.Where(p => p.FiscalYear == "20"+yanYear.ToString() && p.PONumber == supplier.PONumber).Sum(g => g.TotalLC),
                YearAfterYanPriorFcst = priorFcsts.Where(p => p.FiscalYear == "20"+yearAfterYanYear.ToString() && p.PONumber == supplier.PONumber).Sum(g => g.TotalLC)


            })
            .GroupBy(s => new { s.NaturalAccountName, s.PONumber, s.POLineDescription })
            .Select(g => new SupplierDetailsViewModel
            {

                PONumber = g.Key.PONumber,
                POLineDescription = g.Key.POLineDescription,
                NaturalAccountName = g.Key.NaturalAccountName,
                Scenario = g.Select(l => l.Scenario).FirstOrDefault(),
                LEComments = g.Select(l => l.LEComments).FirstOrDefault(),
                CurrentStartId = g.Select(l => l.CurrentStartId).FirstOrDefault(),
                VarianceComments = g.Select(l => l.VarianceComments).FirstOrDefault(),

                NextFiscalMonthJan = g.Sum(b => b.NextFiscalMonthJan),
                NextFiscalMonthFeb = g.Sum(b => b.NextFiscalMonthFeb),
                NextFiscalMonthMar = g.Sum(b => b.NextFiscalMonthMar),
                NextFiscalMonthApr = g.Sum(b => b.NextFiscalMonthApr),
                NextFiscalMonthMay = g.Sum(b => b.NextFiscalMonthMay),
                NextFiscalMonthJun = g.Sum(b => b.NextFiscalMonthJun),
                NextFiscalMonthJul = g.Sum(b => b.NextFiscalMonthJul),
                NextFiscalMonthAug = g.Sum(b => b.NextFiscalMonthAug),
                NextFiscalMonthSep = g.Sum(b => b.NextFiscalMonthSep),
                NextFiscalMonthOct = g.Sum(b => b.NextFiscalMonthOct),
                NextFiscalMonthNov = g.Sum(b => b.NextFiscalMonthNov),
                NextFiscalMonthDec = g.Sum(b => b.NextFiscalMonthDec),
                    ////////////////////////////////////////////////////////////////////////////////////

                ThisFiscalMonthJan = g.Sum(b => b.ThisFiscalMonthJan),
                ThisFiscalMonthFeb = g.Sum(b => b.ThisFiscalMonthFeb),
                ThisFiscalMonthMar = g.Sum(b => b.ThisFiscalMonthMar),
                ThisFiscalMonthApr = g.Sum(b => b.ThisFiscalMonthApr),
                ThisFiscalMonthMay = g.Sum(b => b.ThisFiscalMonthMay),
                ThisFiscalMonthJun = g.Sum(b => b.ThisFiscalMonthJun),
                ThisFiscalMonthJul = g.Sum(b => b.ThisFiscalMonthJul),
                ThisFiscalMonthAug = g.Sum(b => b.ThisFiscalMonthAug),
                ThisFiscalMonthSep = g.Sum(b => b.ThisFiscalMonthSep),
                ThisFiscalMonthOct = g.Sum(b => b.ThisFiscalMonthOct),
                ThisFiscalMonthNov = g.Sum(b => b.ThisFiscalMonthNov),
                ThisFiscalMonthDec = g.Sum(b => b.ThisFiscalMonthDec),

                YearAfterYanPriorFcst = g.Sum(l => l.YearAfterYanPriorFcst),
                ThisPriorFcst = g.Sum(l => l.ThisPriorFcst),
                NextPriorFcst = g.Sum(l => l.NextPriorFcst),
                YANPriorFcst = g.Sum(l => l.YANPriorFcst),

            });

            var filteredLineItems = FilterByPOLineDescription(lineItems);

            return new JsonResult(filteredLineItems);

        }

        private IEnumerable<SupplierDetailsViewModel> FilterByPOLineDescription(IEnumerable<SupplierDetailsViewModel> lineItems)
        {
            List<SupplierDetailsViewModel> filteredList = new List<SupplierDetailsViewModel>();
            foreach(var lineItem in lineItems)
            {
                if (!lineItem.POLineDescription.Contains("ORB ACC") && !lineItem.POLineDescription.Contains("ORBACC"))
                {
                    if (lineItem.POLineDescription == " " || lineItem.POLineDescription == "")
                        lineItem.POLineDescription = "No PO Line Description";

                    if (CheckLineItemSum(lineItem) > 0)
                    {
                        filteredList.Add(lineItem);
                    }
                }

            }
            if(filteredList.Count() == 0)
            {
                foreach (var lineItem in lineItems)
                {
                    if (lineItem.POLineDescription.Contains("ORB ACC") || lineItem.POLineDescription.Contains("ORBACC"))
                    {                        
                            filteredList.Add(lineItem);
                    }

                }
            }


            return filteredList;
        }

        private decimal CheckLineItemSum(SupplierDetailsViewModel lineItem)
        {
            var total = lineItem.ThisFiscalMonthJan + lineItem.ThisFiscalMonthFeb + lineItem.ThisFiscalMonthMar +
                        lineItem.ThisFiscalMonthApr + lineItem.ThisFiscalMonthMay + lineItem.ThisFiscalMonthJun +
                        lineItem.ThisFiscalMonthJul + lineItem.ThisFiscalMonthAug + lineItem.ThisFiscalMonthSep +
                        lineItem.ThisFiscalMonthOct + lineItem.ThisFiscalMonthNov + lineItem.ThisFiscalMonthDec;
            return total?? default(decimal);
        }
        private decimal CheckTotal(CurrentStart currentStart, string period)
        {
            if (currentStart.FiscalPeriod == period)
                return currentStart.TotalLC;

            return 0;

        }

        [HttpPost()]
        [AcceptVerbs("Post")]
        public IActionResult CreateCurrentStartSupplierDetail(string[] currentStart)
        {
            if (currentStart == null)
            {
                return BadRequest("Create Current Start Post Failed");
            }

            try
            {
                var supplierData = JsonConvert.DeserializeObject<SupplierDetailsViewModel[]>(currentStart[0]);

                var supplierDataList = supplierData.ToList();

                var startYear = int.Parse(_prefsData.GetStartYear());
                var thisYear = (startYear - 1).ToString();
                var nextYear = startYear.ToString();
                var supplier = _appData.GetCurrentSupplier();

                //create a new current start with the 
                foreach (var item in supplierDataList)
                {
                    var fiscalPeriod = "Jan-" + thisYear.ToString().Substring(2, 2);
                    var year = thisYear;
                    var budget = item.ThisFiscalMonthJan.GetValueOrDefault(0);
                    var quarter = "Q1-" + thisYear.Substring(thisYear.ToString().Length - 2);
                    var currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod,
                                                                        supplier, item.PONumber, item.POLineDescription);
                    if (item.ThisFiscalMonthJan == null)
                        item.ThisFiscalMonthJan = 0;

                    if (item.ThisFiscalMonthJan != 0)
                    {
                        if (currStart == null) {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthJan != csItem.BudgetLC || item.ThisFiscalMonthJan != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthJan != csItem.TotalLC || item.ThisFiscalMonthJan != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthJan;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJan;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthJan;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthJan;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthJan != csItem.BudgetLC || item.ThisFiscalMonthJan != csItem.BudgetUSD ||
                                         item.ThisFiscalMonthJan != csItem.TotalLC || item.ThisFiscalMonthJan != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthJan;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJan;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthJan;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthJan;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }
 
                        }
                    }

                    //////////FEB
                    fiscalPeriod = "Feb-" + thisYear.ToString().Substring(2, 2);
                    budget = item.ThisFiscalMonthFeb.GetValueOrDefault(0);
                    quarter = "Q1-" + thisYear.Substring(thisYear.ToString().Length - 2);
                    year = thisYear;
                    currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthFeb == null)
                        item.ThisFiscalMonthFeb = 0;

                    if (item.ThisFiscalMonthFeb != 0)
                    {

                        if (currStart == null) {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthFeb != csItem.BudgetLC || item.ThisFiscalMonthFeb != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthFeb != csItem.TotalLC || item.ThisFiscalMonthFeb != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthFeb;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthFeb;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthFeb;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthFeb;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }
                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthFeb != csItem.BudgetLC || item.ThisFiscalMonthFeb != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthFeb != csItem.TotalLC || item.ThisFiscalMonthFeb != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthFeb;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthFeb;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthFeb;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthFeb;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ////////////MAR
                    ///
                    fiscalPeriod = "Mar-" + thisYear.ToString().Substring(2, 2);
                    budget = item.ThisFiscalMonthMar.GetValueOrDefault(0);
                    quarter = "Q1-" + thisYear.Substring(thisYear.ToString().Length - 2);
                    year = thisYear;
                    currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthMar == null)
                        item.ThisFiscalMonthMar = 0;

                    if (item.ThisFiscalMonthMar != 0)
                    {

                        if (currStart == null) { 
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName ) && (c.PONumber == item.PONumber));

                            if(csItem != null)
                            {
                                if (item.ThisFiscalMonthMar != csItem.BudgetLC || item.ThisFiscalMonthMar != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthMar != csItem.TotalLC || item.ThisFiscalMonthMar != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthMar;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthMar;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthMar;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthMar;
                                    SaveData();

                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }
                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                   csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthMar != csItem.BudgetLC || item.ThisFiscalMonthMar != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthMar != csItem.TotalLC || item.ThisFiscalMonthMar != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthMar;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthMar;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthMar;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthMar;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ///////APR
                    ///
                     fiscalPeriod = "Apr-" + thisYear.ToString().Substring(2, 2);
                     budget = item.ThisFiscalMonthApr.GetValueOrDefault(0);
                     quarter = "Q2-" + thisYear.Substring(thisYear.ToString().Length - 2);
                     year = thisYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthApr == null)
                        item.ThisFiscalMonthApr = 0;

                    if (item.ThisFiscalMonthApr != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthApr != csItem.BudgetLC || item.ThisFiscalMonthApr != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthApr != csItem.TotalLC || item.ThisFiscalMonthApr != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthApr;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthApr;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthApr;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthApr;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthApr != csItem.BudgetLC || item.ThisFiscalMonthApr != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthApr != csItem.TotalLC || item.ThisFiscalMonthApr != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthApr;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthApr;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthApr;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthApr;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    //////MAY
                    ///
                     fiscalPeriod = "May-" + thisYear.ToString().Substring(2, 2);
                     budget = item.ThisFiscalMonthMay.GetValueOrDefault(0);
                     quarter = "Q2-" + thisYear.Substring(thisYear.ToString().Length - 2);
                     year = thisYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthMay == null)
                        item.ThisFiscalMonthMay = 0;

                    if (item.ThisFiscalMonthMay != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthMay != csItem.BudgetLC || item.ThisFiscalMonthMay != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthMay != csItem.TotalLC || item.ThisFiscalMonthMay != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthMay;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthMay;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthMay;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthMay;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthMay != csItem.BudgetLC || item.ThisFiscalMonthMay != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthMay != csItem.TotalLC || item.ThisFiscalMonthMay != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthMay;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthMay;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthMay;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthMay;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    //////JUN
                    ///
                     fiscalPeriod = "Jun-" + thisYear.ToString().Substring(2, 2);
                     budget = item.ThisFiscalMonthJun.GetValueOrDefault(0);
                     quarter = "Q2-" + thisYear.Substring(thisYear.ToString().Length - 2);
                     year = thisYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);


                    if (item.ThisFiscalMonthJun == null)
                        item.ThisFiscalMonthJun = 0;

                    if (item.ThisFiscalMonthJun != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthJun != csItem.BudgetLC || item.ThisFiscalMonthJun != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthJun != csItem.TotalLC || item.ThisFiscalMonthJun != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthJun;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJun;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthJun;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthJun;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthJun != csItem.BudgetLC || item.ThisFiscalMonthJun != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthJun != csItem.TotalLC || item.ThisFiscalMonthJun != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthJun;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJun;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthJun;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthJun;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ////////JUL
                    ///
                    fiscalPeriod = "Jul-" + thisYear.ToString().Substring(2, 2);
                    budget = item.ThisFiscalMonthJul.GetValueOrDefault(0);
                    quarter = "Q3-" + thisYear.Substring(thisYear.ToString().Length - 2);
                    year = thisYear;
                    currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthJul == null)
                        item.ThisFiscalMonthJul = 0;

                    if (item.ThisFiscalMonthJul != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthJul != csItem.BudgetLC || item.ThisFiscalMonthJul != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthJul != csItem.TotalLC || item.ThisFiscalMonthJul != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthJul;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJul;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthJul;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthJul;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthJul != csItem.BudgetLC || item.ThisFiscalMonthJul != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthJul != csItem.TotalLC || item.ThisFiscalMonthJul != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthJul;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJul;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthJul;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthJul;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ////AUG
                    ///
                     fiscalPeriod = "Aug-" + thisYear.ToString().Substring(2, 2);
                     budget = item.ThisFiscalMonthAug.GetValueOrDefault(0);
                     quarter = "Q3-" + thisYear.Substring(thisYear.ToString().Length - 2);
                     year = thisYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthAug == null)
                        item.ThisFiscalMonthAug = 0;

                    if (item.ThisFiscalMonthAug != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthAug != csItem.BudgetLC || item.ThisFiscalMonthAug != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthAug != csItem.TotalLC || item.ThisFiscalMonthAug != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthAug;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthAug;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthAug;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthAug;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }

                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthAug != csItem.BudgetLC || item.ThisFiscalMonthAug != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthAug != csItem.TotalLC || item.ThisFiscalMonthAug != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthAug;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthAug;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthAug;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthAug;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ////SEP
                    ///
                     fiscalPeriod = "Sep-" + thisYear.ToString().Substring(2, 2);
                     budget = item.ThisFiscalMonthSep.GetValueOrDefault(0);
                     quarter = "Q3-" + thisYear.Substring(thisYear.ToString().Length - 2);
                     year = thisYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthSep == null)
                        item.ThisFiscalMonthSep = 0;

                    if (item.ThisFiscalMonthSep != 0)
                    {

                        if (currStart == null) 
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthSep != csItem.BudgetLC || item.ThisFiscalMonthSep != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthSep != csItem.TotalLC || item.ThisFiscalMonthSep != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthSep;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthSep;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthSep;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthSep;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }

                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                   csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthSep != csItem.BudgetLC || item.ThisFiscalMonthSep != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthSep != csItem.TotalLC || item.ThisFiscalMonthSep != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthSep;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthSep;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthSep;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthSep;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }
                    ////OCT
                    ///
                     fiscalPeriod = "Oct-" + thisYear.ToString().Substring(2, 2);
                     budget = item.ThisFiscalMonthOct.GetValueOrDefault(0);
                     quarter = "Q4-" + thisYear.Substring(thisYear.ToString().Length - 2);
                     year = thisYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthOct == null)
                        item.ThisFiscalMonthOct = 0;

                    if (item.ThisFiscalMonthOct != 0)
                    {

                        if (currStart == null) 
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthOct != csItem.BudgetLC || item.ThisFiscalMonthOct != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthOct != csItem.TotalLC || item.ThisFiscalMonthOct != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthOct;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthOct;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthOct;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthOct;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }

                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthOct != csItem.BudgetLC || item.ThisFiscalMonthOct != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthOct != csItem.TotalLC || item.ThisFiscalMonthOct != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthOct;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthOct;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthOct;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthOct;
                                        SaveData();
                                    }
                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    ////NOV
                    ///
                     fiscalPeriod = "Nov-" + thisYear.ToString().Substring(2, 2);
                     budget = item.ThisFiscalMonthNov.GetValueOrDefault(0);
                     quarter = "Q4-" + thisYear.Substring(thisYear.ToString().Length - 2);
                     year = thisYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthNov == null)
                        item.ThisFiscalMonthNov = 0;

                    if (item.ThisFiscalMonthNov != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthNov != csItem.BudgetLC || item.ThisFiscalMonthNov != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthNov != csItem.TotalLC || item.ThisFiscalMonthNov != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthNov;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthNov;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthNov;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthNov;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }
                        }

                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                   csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthNov != csItem.BudgetLC || item.ThisFiscalMonthNov != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthNov != csItem.TotalLC || item.ThisFiscalMonthNov != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthNov;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthNov;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthNov;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthNov;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }


                    ////DEC
                    ///
                     fiscalPeriod = "Dec-" + thisYear.ToString().Substring(2, 2);
                     budget = item.ThisFiscalMonthDec.GetValueOrDefault(0);
                     quarter = "Q4-" + thisYear.Substring(thisYear.ToString().Length - 2);
                     year = thisYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.ThisFiscalMonthDec == null)
                        item.ThisFiscalMonthDec = 0;

                    if (item.ThisFiscalMonthDec != 0)
                    {

                        if (currStart == null) 
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.ThisFiscalMonthDec != csItem.BudgetLC || item.ThisFiscalMonthDec != csItem.BudgetUSD ||
                                    item.ThisFiscalMonthDec != csItem.TotalLC || item.ThisFiscalMonthDec != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.ThisFiscalMonthDec;
                                    csItem.BudgetUSD = (decimal)item.ThisFiscalMonthDec;
                                    csItem.TotalLC = (decimal)item.ThisFiscalMonthDec;
                                    csItem.TotalUSD = (decimal)item.ThisFiscalMonthDec;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }

                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.ThisFiscalMonthDec != csItem.BudgetLC || item.ThisFiscalMonthDec != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthDec != csItem.TotalLC || item.ThisFiscalMonthDec != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthDec;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthDec;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthDec;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthDec;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }
                    //TODO: NextYear
                    ///JAN
                    ///
                     fiscalPeriod = "Jan-" + nextYear.ToString().Substring(2, 2);
                     year = nextYear;
                     budget = item.NextFiscalMonthJan.GetValueOrDefault(0);
                     quarter = "Q1-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.NextFiscalMonthJan == null)
                        item.NextFiscalMonthJan = 0;

                    if (item.NextFiscalMonthJan != 0)
                    {
                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthJan != csItem.BudgetLC || item.NextFiscalMonthJan != csItem.BudgetUSD ||
                                    item.NextFiscalMonthJan != csItem.TotalLC || item.NextFiscalMonthJan != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthJan;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthJan;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthJan;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthJan;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }

                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthJan != csItem.BudgetLC || item.NextFiscalMonthJan != csItem.BudgetUSD ||
                                    item.NextFiscalMonthJan != csItem.TotalLC || item.NextFiscalMonthJan != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthJan;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthJan;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthJan;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthJan;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }


                            }

                        }
                    }
                    ///////FEB
                    ///

                     fiscalPeriod = "Feb-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthFeb.GetValueOrDefault(0);
                     quarter = "Q1-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);


                    if (item.NextFiscalMonthFeb == null)
                        item.NextFiscalMonthFeb = 0;

                    if (item.NextFiscalMonthFeb != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthFeb != csItem.BudgetLC || item.NextFiscalMonthFeb != csItem.BudgetUSD ||
                                    item.NextFiscalMonthFeb != csItem.TotalLC || item.NextFiscalMonthFeb != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthFeb;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthFeb;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthFeb;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthFeb;
                                    SaveData();
                                }
                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthFeb != csItem.BudgetLC || item.NextFiscalMonthFeb != csItem.BudgetUSD ||
                                    item.NextFiscalMonthFeb != csItem.TotalLC || item.NextFiscalMonthFeb != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthFeb;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthFeb;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthFeb;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthFeb;
                                        SaveData();
                                    }
                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }
                    ////MAR
                    /////
                    ///
                     fiscalPeriod = "Mar-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthMar.GetValueOrDefault(0);
                     quarter = "Q1-" + nextYear.Substring(thisYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.NextFiscalMonthMar == null)
                        item.NextFiscalMonthMar = 0;

                    if (item.NextFiscalMonthMar != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthMar != csItem.BudgetLC || item.NextFiscalMonthMar != csItem.BudgetUSD ||
                                    item.NextFiscalMonthMar != csItem.TotalLC || item.NextFiscalMonthMar != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthMar;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthMar;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthMar;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthMar;
                                    SaveData();
                                }
                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthMar != csItem.BudgetLC || item.NextFiscalMonthMar != csItem.BudgetUSD ||
                                    item.NextFiscalMonthMar != csItem.TotalLC || item.NextFiscalMonthMar != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthMar;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthMar;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthMar;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthMar;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }
                    ///APR
                    ///
                     fiscalPeriod = "Apr-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthApr.GetValueOrDefault(0);
                     quarter = "Q2-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.NextFiscalMonthApr == null)
                        item.NextFiscalMonthApr = 0;

                    if (item.NextFiscalMonthApr != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthApr != csItem.BudgetLC || item.NextFiscalMonthApr != csItem.BudgetUSD ||
                                    item.NextFiscalMonthApr != csItem.TotalLC || item.NextFiscalMonthApr != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthApr;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthApr;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthApr;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthApr;
                                    SaveData();
                                }
                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }
                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthApr != csItem.BudgetLC || item.NextFiscalMonthApr != csItem.BudgetUSD ||
                                        item.NextFiscalMonthApr != csItem.TotalLC || item.NextFiscalMonthApr != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthApr;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthApr;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthApr;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthApr;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ///MAY
                    ///
                     fiscalPeriod = "May-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthMay.GetValueOrDefault(0);
                     quarter = "Q2-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.NextFiscalMonthMay == null)
                        item.NextFiscalMonthMay = 0;

                    if (item.NextFiscalMonthMay != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthMay != csItem.BudgetLC || item.NextFiscalMonthMay != csItem.BudgetUSD ||
                                    item.NextFiscalMonthMay != csItem.TotalLC || item.NextFiscalMonthMay != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthMay;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthMay;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthMay;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthMay;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthMay != csItem.BudgetLC || item.NextFiscalMonthMay != csItem.BudgetUSD ||
                                        item.NextFiscalMonthMay != csItem.TotalLC || item.NextFiscalMonthMay != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthMay;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthMay;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthMay;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthMay;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ////JUN
                    ///
                     fiscalPeriod = "Jun-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthJun.GetValueOrDefault(0);
                     quarter = "Q2-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);


                    if (item.NextFiscalMonthJun == null)
                        item.NextFiscalMonthJun = 0;

                    if (item.NextFiscalMonthJun != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthJun != csItem.BudgetLC || item.NextFiscalMonthJun != csItem.BudgetUSD ||
                                    item.NextFiscalMonthJun != csItem.TotalLC || item.NextFiscalMonthJun != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthJun;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthJun;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthJun;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthJun;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthJun != csItem.BudgetLC || item.NextFiscalMonthJun != csItem.BudgetUSD ||
                                        item.NextFiscalMonthJun != csItem.TotalLC || item.NextFiscalMonthJun != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthJun;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthJun;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthJun;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthJun;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ////JUL
                    ///
                     fiscalPeriod = "Jul-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthJul.GetValueOrDefault(0);
                     quarter = "Q3-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.NextFiscalMonthJul == null)
                        item.NextFiscalMonthJul = 0;

                    if (item.NextFiscalMonthJul != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthJul != csItem.BudgetLC || item.NextFiscalMonthJul != csItem.BudgetUSD ||
                                    item.NextFiscalMonthJul != csItem.TotalLC || item.NextFiscalMonthJul != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthJul;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthJul;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthJul;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthJul;
                                    SaveData();
                                }
                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }
                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthJul != csItem.BudgetLC || item.NextFiscalMonthJul != csItem.BudgetUSD ||
                                        item.NextFiscalMonthJul != csItem.TotalLC || item.NextFiscalMonthJul != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthJul;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthJul;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthJul;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthJul;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }

                                }
                            }

                        }
                    }

                    ////AUG
                    ///
                     fiscalPeriod = "Aug-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthAug.GetValueOrDefault(0);
                     quarter = "Q3-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.NextFiscalMonthAug == null)
                        item.NextFiscalMonthAug = 0;

                    if (item.NextFiscalMonthAug != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthAug != csItem.BudgetLC || item.NextFiscalMonthAug != csItem.BudgetUSD ||
                                   item.NextFiscalMonthAug != csItem.TotalLC || item.NextFiscalMonthAug != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthAug;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthAug;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthAug;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthAug;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }

                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthAug != csItem.BudgetLC || item.NextFiscalMonthAug != csItem.BudgetUSD ||
                                        item.NextFiscalMonthAug != csItem.TotalLC || item.NextFiscalMonthAug != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthAug;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthAug;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthAug;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthAug;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    /////SEP
                    ///
                     fiscalPeriod = "Sep-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthSep.GetValueOrDefault(0);
                     quarter = "Q3-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);


                    if (item.NextFiscalMonthSep == null)
                        item.NextFiscalMonthSep = 0;

                    if (item.NextFiscalMonthSep != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthSep != csItem.BudgetLC || item.NextFiscalMonthSep != csItem.BudgetUSD ||
                                    item.NextFiscalMonthSep != csItem.TotalLC || item.NextFiscalMonthSep != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthSep;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthSep;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthSep;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthSep;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }

                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthSep != csItem.BudgetLC || item.NextFiscalMonthSep != csItem.BudgetUSD ||
                                        item.NextFiscalMonthSep != csItem.TotalLC || item.NextFiscalMonthSep != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthSep;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthSep;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthSep;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthSep;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    /////OCT
                    ///
                     fiscalPeriod = "Oct-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthOct.GetValueOrDefault(0);
                     quarter = "Q4-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.NextFiscalMonthOct == null)
                        item.NextFiscalMonthOct = 0;

                    if (item.NextFiscalMonthOct != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthOct != csItem.BudgetLC || item.NextFiscalMonthOct != csItem.BudgetUSD ||
                                    item.NextFiscalMonthOct != csItem.TotalLC || item.NextFiscalMonthOct != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthOct;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthOct;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthOct;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthOct;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }

                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthOct != csItem.BudgetLC || item.NextFiscalMonthOct != csItem.BudgetUSD ||
                                        item.NextFiscalMonthOct != csItem.TotalLC || item.NextFiscalMonthOct != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthOct;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthOct;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthOct;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthOct;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ////NOV
                    ///
                     fiscalPeriod = "Nov-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthNov.GetValueOrDefault(0);
                     quarter = "Q4-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);


                    if (item.NextFiscalMonthNov == null)
                        item.NextFiscalMonthNov = 0;

                    if (item.NextFiscalMonthNov != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthNov != csItem.BudgetLC || item.NextFiscalMonthNov != csItem.BudgetUSD ||
                                    item.NextFiscalMonthNov != csItem.TotalLC || item.NextFiscalMonthNov != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthNov;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthNov;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthNov;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthNov;
                                    SaveData();
                                }
                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }

                    }
                    else
                    {
                        if (currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthNov != csItem.BudgetLC || item.NextFiscalMonthNov != csItem.BudgetUSD ||
                                        item.NextFiscalMonthNov != csItem.TotalLC || item.NextFiscalMonthNov != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthNov;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthNov;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthNov;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthNov;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }
                            }

                        }
                    }

                    ////DEC
                    ///
                     fiscalPeriod = "Dec-" + nextYear.ToString().Substring(2, 2);
                     budget = item.NextFiscalMonthDec.GetValueOrDefault(0);
                     quarter = "Q4-" + nextYear.Substring(nextYear.ToString().Length - 2);
                     year = nextYear;
                     currStart = _currentStartData.GetByFiscalPeriod(fiscalPeriod, supplier, item.PONumber, item.POLineDescription);

                    if (item.NextFiscalMonthDec == null)
                        item.NextFiscalMonthDec = 0;

                    if (item.NextFiscalMonthDec != 0)
                    {

                        if (currStart == null)
                        {
                            AddNewCurrentStart(fiscalPeriod, quarter, year, supplier, budget, item);
                        }
                        else
                        {
                            var csItem = currStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) && (c.NaturalAccountName == item.NaturalAccountName) && (c.PONumber == item.PONumber));

                            if (csItem != null)
                            {
                                if (item.NextFiscalMonthDec != csItem.BudgetLC || item.NextFiscalMonthDec != csItem.BudgetUSD ||
                                    item.NextFiscalMonthDec != csItem.TotalLC || item.NextFiscalMonthDec != csItem.TotalUSD)
                                {
                                    csItem.BudgetLC = (decimal)item.NextFiscalMonthDec;
                                    csItem.BudgetUSD = (decimal)item.NextFiscalMonthDec;
                                    csItem.TotalLC = (decimal)item.NextFiscalMonthDec;
                                    csItem.TotalUSD = (decimal)item.NextFiscalMonthDec;
                                    SaveData();
                                }

                                if (item.VarianceComments != csItem.VarianceComments)
                                {
                                    csItem.VarianceComments = item.VarianceComments;
                                    SaveData();
                                }
                            }

                        }

                    }
                    else
                    {
                        if(currStart != null)
                        {
                            foreach (var csItem in currStart)
                            {
                                if(csItem.POLineDescription == item.POLineDescription && 
                                   csItem.PONumber == item.PONumber &&
                                    csItem.NaturalAccountName == item.NaturalAccountName)
                                {
                                    if (item.NextFiscalMonthDec != csItem.BudgetLC || item.NextFiscalMonthDec != csItem.BudgetUSD ||
                                        item.NextFiscalMonthDec != csItem.TotalLC || item.NextFiscalMonthDec != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthDec;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthDec;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthDec;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthDec;
                                        SaveData();
                                    }

                                    if (item.VarianceComments != csItem.VarianceComments)
                                    {
                                        csItem.VarianceComments = item.VarianceComments;
                                        SaveData();
                                    }
                                }                              
                            }


                        }
                    }
                    
                }

                return new JsonResult(CurrentStartAdd);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Create Current Start SupplierDetailController: " + ex);
                return BadRequest("Create Current Start Failed - SupplierDetailController: " + ex);
            }


        }

        private CurrentStart GetNewCurrentStart(CurrentStart currStart)
        {
            CurrentStartAdd = null;

            CurrentStartAdd = new CurrentStart()
            {
                ProjectName = currStart.ProjectName,
                Scenario = currStart.Scenario,
                POLineDescription = currStart.POLineDescription,
                DepartmentNameNum = currStart.DepartmentNameNum,
                BudgetUSD_1 = currStart.BudgetUSD_1,
                BudgetLC_1 = currStart.BudgetLC_1,
                Comments = currStart.Comments,
                VarianceComments = currStart.VarianceComments,

                DepartmentName = currStart.DepartmentName,
                DepartmentNumber = currStart.DepartmentNumber,
                DepartmentGroup = currStart.DepartmentGroup,
                DepartmentSubGroup = currStart.DepartmentSubGroup,
                CostCenterNumber = currStart.CostCenterNumber,

                AccountGroup = currStart.AccountGroup,
                AccountNumber = currStart.AccountNumber,
                NaturalAccountName = currStart.NaturalAccountName,
                ProjectTaskNumber = currStart.ProjectTaskNumber,
                PONumber = currStart.PONumber,

                SupplierNumber = currStart.SupplierNumber,
                PurchaseInvoiceNumber = currStart.PurchaseInvoiceNumber,
                ActualUSD = 0,
                CountryCity = currStart.CountryCity,
                Region = currStart.Region,
                Region_Rpt = currStart.Region_Rpt,
                FPAAccrualsReclasses = currStart.FPAAccrualsReclasses,
                SupplierType = currStart.SupplierType,
                FiscalDate = DateTime.Now.ToOADate().ToString(),
                LocalCurrency = currStart.LocalCurrency,
                OriginalSupplierName = currStart.OriginalSupplierName,
                DepartmentRollOut = currStart.DepartmentRollOut,
                UniqueListACC = currStart.UniqueListACC,
                UniqueListDEPT = currStart.UniqueListDEPT,
                TotalLC = currStart.TotalLC,
                TotalUSD = currStart.TotalUSD

            };

            return CurrentStartAdd;
        }

        [HttpGet()]
        [AcceptVerbs("Get")]
        public IActionResult GetNextSupplier(string departmentId, string supplierName)
        {
            var suppliers = _appData.GetSupplierNames().ToList();
            var currentSupplier = _appData.GetCurrentSupplier();

            var currentIndex = suppliers.IndexOf(currentSupplier);

            if (currentIndex == -1 && !suppliers.Contains(SupplierName))
                suppliers = _appData.GetNewSupplierNames().ToList();

            currentIndex = suppliers.IndexOf(currentSupplier);

            if (currentIndex < suppliers.Count())
            {
                var nextIndex = currentIndex + 1;

                if (nextIndex == (suppliers.Count()))
                    nextIndex = 0;

                var nextSupplier = suppliers.ElementAt(nextIndex);

                var nextSupplierLineItems = GetSupplierViewModel(nextSupplier, departmentId);

                _appData.SetSupplier(nextSupplier);

                var filteredLineItems = FilterByPOLineDescription(nextSupplierLineItems);
                return new JsonResult(filteredLineItems);
            }

            return LocalRedirect("/LE/SupplierForecast");
        }

        [HttpGet()]
        [AcceptVerbs("Get")]
        public IActionResult GetPreviousSupplier(string departmentId, string supplierName)
        {
            var suppliers = _appData.GetSupplierNames().ToList();
            var currentSupplier = _appData.GetCurrentSupplier(); ;

            var currentIndex = suppliers.IndexOf(currentSupplier);

            string prevSupplier = null;
            IEnumerable<SupplierDetailsViewModel> prevSupplierLineItems = null;

            if (currentIndex == -1 && !suppliers.Contains(SupplierName))
                suppliers = _appData.GetNewSupplierNames().ToList();

            currentIndex = suppliers.IndexOf(currentSupplier);

            if (currentIndex > 0)
            {

                prevSupplier = suppliers.ElementAt((currentIndex - 1));

                prevSupplierLineItems = GetSupplierViewModel(prevSupplier, departmentId);

                _appData.SetSupplier(prevSupplier);

                var fLineItems = FilterByPOLineDescription(prevSupplierLineItems);

                return new JsonResult(fLineItems);


            }
            prevSupplier = suppliers.ElementAt((suppliers.Count() - 1));

            prevSupplierLineItems = GetSupplierViewModel(prevSupplier, departmentId);

            _appData.SetSupplier(prevSupplier);

            var filteredLineItems = FilterByPOLineDescription(prevSupplierLineItems);

            return new JsonResult(filteredLineItems);
        }

        private IActionResult SaveData()
        {
            if (!_currentStartData.Commit())
            {
                return StatusCode(500, "Problem creating Current Start Record.");
            }

            return Ok();
        }

        private IEnumerable<SupplierDetailsViewModel> GetSupplierViewModel(string supplierName, string departmentId)
        {
            var startYear = int.Parse(_prefsData.GetStartYear());

            var thisYear = (startYear - 1).ToString().Substring(2, 2);
            var nextYear = (startYear).ToString().Substring(2, 2);
            var yanYear = (startYear + 1).ToString().Substring(2, 2);
            var yearAfterYanYear = (startYear + 2).ToString().Substring(2, 2);

            //var departmentId =  Task.Run(async () => await _appData.GetCurrentDepartment());
            var priorFcsts = _priorForecastData.GetBySuplierName(supplierName, departmentId);

            var currStartList = _currentStartData.GetForcastsByName(supplierName, departmentId);

            var lineItems = currStartList.Select(supplier => new SupplierDetailsViewModel
            {
                NaturalAccountName = supplier.NaturalAccountName,
                PONumber = supplier.PONumber,
                POLineDescription = supplier.POLineDescription,
                LEComments = supplier.Comments,
                VarianceComments = supplier.VarianceComments,
                Scenario = supplier.Scenario,

                NextFiscalMonthJan = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(1, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(2, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(3, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(4, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(5, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(6, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(7, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(8, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(9, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(10, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(11, nextYear) ? supplier.TotalLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(12, nextYear) ? supplier.TotalLC : 0,

                ThisFiscalMonthJan = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(1, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(2, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(3, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(4, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(5, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(6, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(7, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(8, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(9, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(10, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(11, thisYear) ? supplier.TotalLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod == DateHelpers.ConvertFiscalPeriod(12, thisYear) ? supplier.TotalLC : 0,

                ThisPriorFcst = priorFcsts.Where(p => p.FiscalYear == "20" + thisYear.ToString() && p.PONumber == supplier.PONumber).Sum(g => g.TotalLC),
                NextPriorFcst = priorFcsts.Where(p => p.FiscalYear == "20" + nextYear.ToString() && p.PONumber == supplier.PONumber).Sum(g => g.TotalLC),
                YANPriorFcst = priorFcsts.Where(p => p.FiscalYear == "20" + yanYear.ToString() && p.PONumber == supplier.PONumber).Sum(g => g.TotalLC),
                YearAfterYanPriorFcst = priorFcsts.Where(p => p.FiscalYear == "20" + yearAfterYanYear.ToString() && p.PONumber == supplier.PONumber).Sum(g => g.TotalLC)

            })
             .GroupBy(s => new { s.NaturalAccountName, s.PONumber, s.POLineDescription })
            .Select(g => new SupplierDetailsViewModel
            {

                PONumber = g.Key.PONumber,
                POLineDescription = g.Key.POLineDescription,
                NaturalAccountName = g.Key.NaturalAccountName,
                Scenario = g.Select(l => l.Scenario).FirstOrDefault(),
                LEComments = g.Select(l => l.LEComments).FirstOrDefault(),
                VarianceComments = g.Select(l => l.VarianceComments).FirstOrDefault(),

                NextFiscalMonthJan = g.Sum(b => b.NextFiscalMonthJan),
                NextFiscalMonthFeb = g.Sum(b => b.NextFiscalMonthFeb),
                NextFiscalMonthMar = g.Sum(b => b.NextFiscalMonthMar),
                NextFiscalMonthApr = g.Sum(b => b.NextFiscalMonthApr),
                NextFiscalMonthMay = g.Sum(b => b.NextFiscalMonthMay),
                NextFiscalMonthJun = g.Sum(b => b.NextFiscalMonthJun),
                NextFiscalMonthJul = g.Sum(b => b.NextFiscalMonthJul),
                NextFiscalMonthAug = g.Sum(b => b.NextFiscalMonthAug),
                NextFiscalMonthSep = g.Sum(b => b.NextFiscalMonthSep),
                NextFiscalMonthOct = g.Sum(b => b.NextFiscalMonthOct),
                NextFiscalMonthNov = g.Sum(b => b.NextFiscalMonthNov),
                NextFiscalMonthDec = g.Sum(b => b.NextFiscalMonthDec),
                ////////////////////////////////////////////////////////////////////////////////////



                ThisFiscalMonthJan = g.Sum(b => b.ThisFiscalMonthJan),
                ThisFiscalMonthFeb = g.Sum(b => b.ThisFiscalMonthFeb),
                ThisFiscalMonthMar = g.Sum(b => b.ThisFiscalMonthMar),
                ThisFiscalMonthApr = g.Sum(b => b.ThisFiscalMonthApr),
                ThisFiscalMonthMay = g.Sum(b => b.ThisFiscalMonthMay),
                ThisFiscalMonthJun = g.Sum(b => b.ThisFiscalMonthJun),
                ThisFiscalMonthJul = g.Sum(b => b.ThisFiscalMonthJul),
                ThisFiscalMonthAug = g.Sum(b => b.ThisFiscalMonthAug),
                ThisFiscalMonthSep = g.Sum(b => b.ThisFiscalMonthSep),
                ThisFiscalMonthOct = g.Sum(b => b.ThisFiscalMonthOct),
                ThisFiscalMonthNov = g.Sum(b => b.ThisFiscalMonthNov),
                ThisFiscalMonthDec = g.Sum(b => b.ThisFiscalMonthDec),

                YearAfterYanPriorFcst = g.Select(l => l.YearAfterYanPriorFcst).FirstOrDefault(),
                ThisPriorFcst = g.Select(l => l.ThisPriorFcst).FirstOrDefault(),
                NextPriorFcst = g.Select(l => l.NextPriorFcst).FirstOrDefault(),
                YANPriorFcst = g.Select(l => l.YANPriorFcst).FirstOrDefault(),


            });

            return lineItems;
        }

        [HttpGet()]
        public IActionResult DeleteDetail(string naturalAccountName, string poNumber)
        {

            var supplier = _appData.GetCurrentSupplier();
            var department = _appData.GetCurrentDepartment().Result;

            var id = _pendingData.GetPendingID(naturalAccountName, department, supplier, poNumber);

            if (id >= 0)
            {
                var pending = new Pending()
                {
                    CSID = id,
                    NaturalAccountName = naturalAccountName,
                    Department = department,
                    SupplierName = supplier,
                    PONumber = poNumber
                };

                _pendingData.Delete(pending);

                //return Ok("");
                return new JsonResult(null);
            }

            return new JsonResult(id);
            
        }

        void AddNewCurrentStart(string period, string quarter, string year, string supplier, decimal budget, SupplierDetailsViewModel viewModel)
        {
            //TODO: make static
            
            var currentDepartment = _appData.GetCurrentDepartment().Result;

            var currStart = new CurrentStart()
            {
                NaturalAccountName = viewModel.NaturalAccountName,
                POLineDescription = viewModel.POLineDescription,
                PONumber = viewModel.PONumber,
                Comments = viewModel.LEComments,
                VarianceComments = viewModel.VarianceComments,
                SupplierName = supplier,
                DepartmentNameNum = currentDepartment,
                FiscalPeriod = period,
                FiscalQuarter = quarter,
                FiscalYear = year,
                BudgetLC = budget,
                BudgetUSD = budget,
                TotalLC = budget,
                TotalUSD = budget

            };
            _currentStartData.AddForecast(currStart);
            
            SaveData();
        }

        void UdateCurrentStartEntity(CurrentStart currentStartFromRepo, SupplierDetailsViewModel viewModelData)
        {
            if(currentStartFromRepo != null)
            {
                //currentStartFromRepo.BudgetLC = viewModelData.ThisFiscalMonthMar;
            }

        }
        private IActionResult UpdateRentCurrentStartInternal(CurrentStart currentStartFromRepo, JsonPatchDocument<CurrentStartDTO> currentStartDoc)
        {
            if (currentStartDoc == null || currentStartFromRepo == null)
            {
                return BadRequest("No Current Start to Update!");
            }

            var currentStartToPatch = _mapper.Map<CurrentStart, CurrentStartDTO>(currentStartFromRepo);

            //Add mapping
            currentStartDoc.ApplyTo(currentStartToPatch);

            _mapper.Map(currentStartToPatch, currentStartFromRepo);
            SaveData();
            return NoContent();
        }

    }
}
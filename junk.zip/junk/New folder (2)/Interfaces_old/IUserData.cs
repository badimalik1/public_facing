﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Data.Interfaces
{
    public interface IUserData
    {
        User GetUser(string username, string password);
        ICollection<DepartmentString> GetDepartments(int userId);
    }
}

﻿using LE.Core;
using LE.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LE.Data.Implementations
{
    public class TaxData : ITaxData
    {

        private readonly LEDbContext _db;

        public TaxData(LEDbContext db)
        {
            _db = db;
        }
        public IEnumerable<CurrentStart> ReadTaxForecast(string dept)
        {
            var taxes = _db.CurrentStarts
                .Where(a => a.DepartmentNameNum == dept)
                .Where(r => r.AccountNumber == 70205)
                .Where(s => s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                .OrderBy(a => a.SupplierName)
                .Skip(5000 * (0))
                .Take(5000)
                .ToList();

            return taxes;
        }
    }
}

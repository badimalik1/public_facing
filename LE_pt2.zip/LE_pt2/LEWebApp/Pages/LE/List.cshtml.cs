 using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LE.Core;
using LE.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LEWebApp.Pages.LE
{
    public class ListModel : PageModel
    {
        public string Message { get; set; }
        private readonly IConfiguration _config;
        private readonly ITargetedSupplierData _targetedSupplierData;
        private readonly ILogger<ListModel> _logger;

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }
        public IEnumerable<TargetedSupplier> TargetedSuppliers { get; set; }

        public ListModel(IConfiguration config, ITargetedSupplierData targetedSupplierData, ILogger<ListModel> logger)
        {
            _config = config;
            _logger = logger;
            _targetedSupplierData = targetedSupplierData;
        }

        public void OnGet()
        {
            Message = "BAM!";
            //var ts = _targetedSupplierData.GetAll();
           // _logger.LogInformation("List Get called");
            Task.Run(
                async () =>
                {
                     TargetedSuppliers = await _targetedSupplierData.GetSuppliersByName(SearchTerm);
                });
        }
    }
}
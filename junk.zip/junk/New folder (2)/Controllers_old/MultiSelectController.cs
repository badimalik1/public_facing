﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using LE.Data;
using LE.Core;
using LEWebApp.Models;
using System.Diagnostics;

namespace LEWebApp.Controllers
{
    [Route("api/multiselect")]
    [ApiController]
    public class MultiSelectController : Controller
    {
        private readonly LEDbContext _db;
        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }


        public MultiSelectController(LEDbContext db)
        {
            _db = db;
        }


        public JsonResult ServerFiltering_GetTargetedSuppliers(string text)
        {

            var suppliers =_db.TargetedSuppliers
                .OrderBy(a => a.SupplierName)
               .Skip(10 * (0))
                 .Take(10000)
               .ToList();


            var supplierList = suppliers.Select(supplier => new LE.Core.SupplierViewModel { SupplierId = supplier.Id, SupplierName = supplier.SupplierName });

            if (!string.IsNullOrEmpty(text))
            {
                SearchTerm = text;

                try
                {
                    var suppList = supplierList.Where(s => s.SupplierName != null && s.SupplierName.Contains(SearchTerm));
                    return Json(suppList.ToList());

                }
                catch(Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }
                
            }

            return Json(supplierList.ToList());
        }
    }
}

﻿using LEWebApp.Helpers;
using LEWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class AppProxyController : Controller
    {
        private EmailHelper _emailHelper;
        private readonly IHostingEnvironment _env;

        public AppProxyController(EmailHelper emailHelper, IHostingEnvironment env)
        {
            _env = env;
            _emailHelper = emailHelper;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult SendEmail()
        {
            var emailModel = new EmailModel("badi.malik@gmail.com", // To  
                "Email Test", // Subject  
                "Sending Email using Asp.Net Core.", // Message  
                false // IsBodyHTML  
            );
            _emailHelper.SendEmail(emailModel);
            return RedirectToAction("Index");
        }

        public ActionResult SaveFile(string contentType, string base64, string fileName)
        {
            var fileContents = Convert.FromBase64String(base64);
            System.IO.File.WriteAllBytes(_env.ContentRootPath + "\\App_data\\sample.xlsx", fileContents);
            return View("Index");
        }
    }
}

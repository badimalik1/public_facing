﻿using LE.Core;
using LE.Data.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Implementations
{
    public class UserData : BaseDataImpl, IUserData
    {
        User _user { get; set; }
        private readonly LEDbContext _db;

        public UserData(LEDbContext db)
        {
            _db = db;
        }

        protected HttpClient CreateHttpClient()
        {
            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return httpClient;
        }

        public User GetUser(string username, string password)
        {
            var user = _db.Users
                            .SingleOrDefault(u => u.Email == username && u.Password == password);

            //HACK: fix later
            //..var departments = _context.DepartmentStrings;
            var departmentNameNums = _db.DepartmentStrings
                                    .Select(d => _db.DepartmentStrings.Where(n => n.UserId == user.Id));


            user.Departments = new List<DepartmentString>();

            foreach (var dpt in departmentNameNums)
            {
                foreach (var dp in dpt)
                {
                    user.Departments.Add(dp);
                }
                break;
            }

            return user;

        }


        public ICollection<DepartmentString> GetDepartments(int userId)
        {

            var depts = new List<DepartmentString>();

            var departmentNameNums = _db.DepartmentStrings
                                        .Select(d => _db.DepartmentStrings.Where(n => n.UserId ==  userId));


            foreach (var dpt in departmentNameNums)
            {
                foreach (var dp in dpt)
                {
                    depts.Add(dp);
                }
                break;
            }
            return depts;


        }


        public async Task<User> GetUserAPI(string username, string password)
        {
            using (httpClient = CreateHttpClient())
            {
                //TODO: get from config
                httpClient.BaseAddress = new Uri("https://localhost:44328/");//baseUri
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var timeSpan = timeoutInSeconds >= 1 ? new TimeSpan(0, 0, timeoutInSeconds) : TimeSpan.FromSeconds(DEFAULT_TIMEOUT);
                httpClient.Timeout = timeSpan;

                var request = new HttpRequestMessage(HttpMethod.Get, "api/user?username =" +username+"&password ="+ password);

                var uri = httpClient.BaseAddress.ToString() + request.RequestUri;

                try
                {
                    var regResponse = await httpClient.GetAsync(uri);

                    if (regResponse.IsSuccessStatusCode)
                    {
                        var regResponseString = await regResponse.Content.ReadAsStringAsync();
                        var user = JsonConvert.DeserializeObject<User>(regResponseString);

                        return user;
                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

                return null;

            }
        }
    }
}

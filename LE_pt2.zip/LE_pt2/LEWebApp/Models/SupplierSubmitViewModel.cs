﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Models
{
    public class SupplierSubmitViewModel
    {
        public int CurrentStartId { get; set; }
        public string FiscalDate { get; set; }
        public string FiscalQuarter { get; set; }
        public string FiscalPeriod { get; set; }
        public string FiscalYear { get; set; }
        public string POLineDescription { get; set; }
        public string LEComents { get; set; }
        public string SupplierName { get; set; }
        public decimal TotalLC { get; set; }
        public decimal TotalUSD { get; set; }
        public decimal BudgetLC { get; set; }
        public decimal BudgetUSD { get; set; }
        public decimal ActualLC { get; set; }
        public decimal ActualUSD { get; set; }


    }



}

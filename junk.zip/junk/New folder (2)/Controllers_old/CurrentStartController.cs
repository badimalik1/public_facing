﻿using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    //[EnableCors("_myAllowSpecificOrigins")]
    //[Route("api/currentStart")]
    public class CurrentStartController : Controller
    {
        public User UserData { get; set; }
        private readonly IAppData _appData;
        public string CurrentDepartment { get; set; }
        private readonly ICurrentStartData _currentStartData;

        public ICollection<DepartmentString> Departments { get; set; }

        public IEnumerable<CurrentStart> CurrentStarts { get; set; }

        private readonly ILogger<CurrentStartController> _logger;

        public CurrentStartController(ICurrentStartData currentStartData, IAppData appData, ILogger<CurrentStartController> logger)
        {

            _appData = appData;
            _currentStartData = currentStartData;
            UserData = _appData.GetUser();
            _logger = logger;

        }

        [HttpGet()]
        public IActionResult GetSupplierCurrentStarts()
        {
            try
            {


                Task.Run(async () =>
                {
                    _logger.LogInformation("appdata1");
                    CurrentDepartment = await _appData.GetCurrentDepartment();
                    _logger.LogInformation("appdata2");
                });

                Departments = new Collection<DepartmentString>();

                _logger.LogInformation("userdata1");
                if (UserData != null && UserData.Departments != null)
                {
                    
                    foreach (var dp in UserData.Departments)
                    {
                        Departments.Add(dp);
                        _logger.LogInformation("Departments: " + dp.DepartmentNameNum);
                    }
                }

                _logger.LogInformation("userdata2");
                var dept = CurrentDepartment = CurrentDepartment != null ? CurrentDepartment : Departments.FirstOrDefault().DepartmentNameNum;
                var currentStarts = _currentStartData.ReadSupplierForecast(dept);

                var lastYear = (DateTime.Now.Year - 1);
                var thisYear = (DateTime.Now.Year);
                var nextYear = (DateTime.Now.Year + 1);
                var yearAfterNext = (DateTime.Now.Year + 1);

                var fiscalYearExtracts = currentStarts
                                        .Where(c => c.FiscalYear != lastYear.ToString() && c.Scenario != "Actual");


                var currentStartActuals = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());

                var highestActualsBy = currentStartActuals
                    .GroupBy(s => s.SupplierName)
                    .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                    .ToList();

                var supplierList = highestActualsBy.Select(supplier => new SupplierViewModel
                {
                    SupplierId = supplier.Id,
                    SupplierName = supplier.SupplierName,
                    FiscalYear1 = supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC,
                    FiscalYear2 = fiscalYearExtracts.Where(f => f.FiscalYear == thisYear.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.BudgetLC ?? default(decimal),
                    FiscalYear3 = fiscalYearExtracts.Where(f => f.FiscalYear == nextYear.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.BudgetLC ?? default(decimal),
                    FiscalYear4 = fiscalYearExtracts.Where(f => f.FiscalYear == yearAfterNext.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.BudgetLC ?? default(decimal)
                });


                _logger.LogDebug("Return!!");
                return new JsonResult(supplierList);
            }catch(Exception ex)
            {
                _logger.LogDebug("CONTROLLER ERROR: " + ex.Message);
            }

            return BadRequest("Fail: in controller");
        }

        [HttpGet()]
        public IActionResult GetCurrentStarts(string departmentId)
        {
            _logger.LogInformation("controller departmentId: " + departmentId);
            var currentStarts = _currentStartData.ReadSupplierForecast(departmentId);

            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 1);

            var fiscalYearExtracts = currentStarts
                                    .Where(c => c.FiscalYear != lastYear.ToString() && c.Scenario != "Actual");


            var currentStartActuals = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());

            var highestActualsBy = currentStartActuals
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();

            var supplierList = highestActualsBy.Select(supplier => new SupplierViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                FiscalYear1 = supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC,
                FiscalYear2 = fiscalYearExtracts.Where(f => f.FiscalYear == thisYear.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.BudgetLC ?? default(decimal),
                FiscalYear3 = fiscalYearExtracts.Where(f => f.FiscalYear == nextYear.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.BudgetLC ?? default(decimal),
                FiscalYear4 = fiscalYearExtracts.Where(f => f.FiscalYear == yearAfterNext.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.BudgetLC ?? default(decimal)
            });

            //TODO: store current dept here
            CurrentDepartment = departmentId;
            _appData.SetDepartment(departmentId);
            return new JsonResult(supplierList);
        }
    }
}

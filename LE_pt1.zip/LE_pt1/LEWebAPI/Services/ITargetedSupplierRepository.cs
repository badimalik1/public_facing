﻿using LEWebAPI.Entities;
using LEWebAPI.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Services
{
    public interface ITargetedSupplierRepository
    {
        bool Save();
        bool SupplierExists(string supplierName);
        void AddTargetedSupplier(TargetedSupplier result);
        IEnumerable<TargetedSupplier> GetSuppliersByName(string name);
        IEnumerable<TargetedSupplier> GetTargetedSuppliers(SupplierResourceParameters supplierResourceParameters);

    }
}

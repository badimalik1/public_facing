﻿using LE.Core;
using LE.Data.Interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LE.Data.Implementations
{
    public class PendingData : IPendingData
    {
        private readonly LEDbContext _db;

        private readonly ILogger<PendingData> _logger;

        public PendingData(LEDbContext db, ILogger<PendingData> logger)
        {
            _db = db;
            _logger = logger;
        }

        public  bool Commit() { return (_db.SaveChanges() >= 0); }
        public void Delete(Pending pnd) 
        {
            try
            {
                var currentStart = _db.CurrentStarts.Where(c => c.Id == pnd.CSID).FirstOrDefault();

                if(currentStart != null)
                { 
                    _db.CurrentStarts.Remove(currentStart);
                    Commit();
                
                    var pending = _db.Pending.Where(p => p.CSID == pnd.CSID &&
                                                         p.Department == pnd.Department &&
                                                         p.NaturalAccountName == pnd.NaturalAccountName &&
                                                         p.SupplierName == pnd.SupplierName &&
                                                         p.PONumber == pnd.PONumber).FirstOrDefault();
                    if(pending != null)
                    {
                        _db.Pending.Remove(pending);
                        Commit();
                    }
                }

            }
            catch(Exception ex)
            {
                _logger.LogError("PendingData - Delete: " + ex.Message);
            }

        }
        public int GetPendingID(string account, string department, string supplier, string poNumber)
        {

            try
            {

                var pendRec = _db.Pending.Where(p => p.Department == department &&
                                                p.NaturalAccountName == account &&
                                                p.SupplierName == supplier &&
                 
                                                p.PONumber == poNumber).FirstOrDefault();
                if (pendRec != null)
                    return pendRec.CSID;

                return -1;

            }
            catch (Exception ex)
            {
                _logger.LogError("PendingData - GetPendingID: " + ex.Message);
            }

            return 0;
             
        }
        public int AddPending(Pending pending)
        {
            _db.Pending.Add(pending);
            var saved = Commit();

            if (!saved)
                return 0;

            return pending.Id;
        }

    }
}

﻿using AutoMapper;
using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class UserController : Controller
    {

        public User UserInfo { get; set; }
        private readonly IAppData _appData;
        private readonly IUserData _userData;
        private readonly IMapper _mapper;

        public string CurrentDepartment { get; set; }


        public ICollection<DepartmentString> Departments { get; set; }
        public UserController(IAppData appData, IUserData userData, IMapper mapper)
        {
            _appData = appData;
            _userData = userData;
            _mapper = mapper;

        }

        public IActionResult GetUser(string username, string password)
        {
            var user = _appData.GetUser(username, password);
            return new JsonResult(user);
        }

        public IActionResult GetDepartments(int Id)
        {
            var departments = _userData.GetDepartments(Id);
            return new JsonResult(departments);

        }


        public IActionResult Login(string email, string password)
        {
            UserInfo = _userData.GetUser(email, password);

            if (UserInfo != null)
            {
                _appData.SetUser(UserInfo);
                return RedirectToPage("/LE/SupplierForecast");

            }

            ModelState.AddModelError("", "The username or password is incorrect.");
            return View("LoginFail");
        }

        [AcceptVerbs("PATCH")]
        public IActionResult Patch([FromBody] JsonPatchDocument<DTOS.UserDTO > PatchEntity)
        {
            if (UserInfo == null)
                UserInfo = _appData.GetUser();

            //UserInfo.CompletionDate = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            
            var entity = _userData.GetUser(UserInfo.Email, UserInfo.Password);

            if (entity == null)
            {
                return NotFound();
            }
            try
            {
                DTOS.UserDTO usrDTOMap = _mapper.Map<DTOS.UserDTO>(entity);

                PatchEntity.ApplyTo(usrDTOMap, ModelState); // Must have Microsoft.AspNetCore.Mvc.NewtonsoftJson installed

                var isValid = TryValidateModel(UserInfo);

                if (!isValid)
                {
                    return BadRequest(ModelState);
                }

                _mapper.Map<DTOS.UserDTO, User>(usrDTOMap);
                _userData.Save();

                return Ok(entity);
            }
            catch(Exception ex)
            {

            }
            return NoContent();
           
        }
    }
}

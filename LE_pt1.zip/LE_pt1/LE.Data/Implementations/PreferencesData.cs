﻿using LE.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LE.Data.Implementations
{
    public class PreferencesData : IPreferencesData
    {
        private readonly LEDbContext _db;

        public PreferencesData(LEDbContext db)
        {
            _db = db;
        }

        public string GetStartYear()
        {
            return _db.Preferences
                    .FirstOrDefault().StartYear;
        }

        public string GetStartDate()
        {
            return _db.Preferences
                    .FirstOrDefault().StartDate;
        }

        public string GetEndDate()
        {
            return _db.Preferences
                    .FirstOrDefault().EndDate;
        }

        public string GetForecastPeriod()
        {
            return _db.Preferences
                    .FirstOrDefault().ForecastMonthPeriod;
        }
    }
}

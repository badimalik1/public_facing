﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LEWebApp.Models
{
    public class PriorForecast
    {
        public int Id { get; set; }
        public string ProjectName { get; set; }
        public string Scenario { get; set; }
        public string POLineDescription { get; set; }
        public string DepartmentNameNum { get; set; }
        public decimal BudgetUSD_1 { get; set; }
        public decimal BudgetLC_1 { get; set; }
        public string Comments { get; set; }
        public string FiscalPeriod { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentNumber { get; set; }
        public string DepartmentGroup { get; set; }
        public string DepartmentSubGroup { get; set; }
        public string CostCenterNumber { get; set; }
        public string FiscalYear { get; set; }
        public string FiscalQuarter { get; set; }
        public string AccountGroup { get; set; }
        public string NaturalAccountName { get; set; }
        public string ProjectTaskNumber { get; set; }
        public string PONumber { get; set; }
        public string SupplierName { get; set; }
        public string SupplierNumber { get; set; }
        public string PurchaseInvoiceNumber { get; set; }
        public decimal ActualUSD { get; set; }
        public decimal ActualLC { get; set; }
        public string CountryCity { get; set; }
        public string Region { get; set; }
        public string Region_Rpt { get; set; }
        public string FPAAccrualsReclasses { get; set; }
        public string SupplierType { get; set; }
        public string FiscalDate { get; set; }
        public string LocalCurrency { get; set; }
        public decimal BudgetUSD { get; set; }
        public decimal BudgetLC { get; set; }
        public string OriginalSupplierName { get; set; }
        public string DepartmentRollOut { get; set; }
        public string UniqueListACC { get; set; }
        public string UniqueListDEPT { get; set; }
        public decimal TotalUSD { get; set; }
        public decimal TotalLC { get; set; }
    }
}

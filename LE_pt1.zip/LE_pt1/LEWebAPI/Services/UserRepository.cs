﻿using LEWebAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Services
{


    public class UserRepository : IUserRepository
    {
        User _user;
        LEDbContext _context;      
        IApplicationDataRepository _appData;

        public UserRepository(LEDbContext context, IApplicationDataRepository appData)
        {
            _appData = appData;
            _context = context;
        }
        public void AddUser(User userObj)
        {
            throw new NotImplementedException();
        }

        public void DeleteUser(User userObj)
        {
            throw new NotImplementedException();
        }


        public User GetUser(string username, string password)
        {
            if (_user == null)
            {
                var user = _context.Users
                    .SingleOrDefault(u => u.Email == username && u.Password == password);

                //HACK: fix later
                //..var departments = _context.DepartmentStrings;
                var departmentNameNums = _context.DepartmentStrings
                                        .Select(d => _context.DepartmentStrings.Where(n => n.UserId == user.Id));

                user.Departments = new List<DepartmentString>();

                foreach (var dpt in departmentNameNums)
                {
                    foreach (var dp in dpt)
                    {
                        user.Departments.Add(dp);
                    }
                    break;
                }
                _user = user;
            }
            _appData.SetUser(_user);
            return _user;
        }
        public ICollection<DepartmentString> GetDepartments(int userId)
        {
            if (_user == null)
            {
                var departmentNameNums = _context.DepartmentStrings
                                                        .Select(d => _context.DepartmentStrings.Where(n => n.UserId == userId));

                var depts = new List<DepartmentString>();

                foreach (var dpt in departmentNameNums)
                {
                    foreach (var dp in dpt)
                    {
                        depts.Add(dp);
                    }
                    break;
                }
                return depts;
            }
                

            return null;
                
        }

        public User UpdateUser(User userObj)
        {
            throw new NotImplementedException();
        }
    }
}

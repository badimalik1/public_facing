﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Data.Interfaces
{
    public interface IRentData
    {
        IEnumerable<CurrentStart> ReadRentForecast(string dept);
        IEnumerable<PriorForecast> ReadPriorForecastRents(string dept);
    }
}

﻿using LEWebAPI.Entities;
using LEWebAPI.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Services
{
    public class LERepository : ILERepository
    {
        LEDbContext _context;

        public LERepository(LEDbContext context)
        {

             _context = context;
        }

        public bool SupplierExists(string supplierName)
        {
            //TODO: search gileadwide suppliers as well

            return _context.GileadWideSuppliers.Any(t => t.SupplierName == supplierName);
        }

        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }

        public IEnumerable<GileadWideSupplier> GetGileadWideSuppliers(SupplierResourceParameters supplierResourceParameters)
        {
            return _context.GileadWideSuppliers
                .OrderBy(a => a.SupplierRegInitiatorDeptID)
                .ThenBy(a => a.Id)
                .Skip(500 * (supplierResourceParameters.PageNumber - 1)) //supplierResourceParameters.PageSize 
                .Take(500) //supplierResourceParameters.PageSize 
                .ToList();
        }

        public IEnumerable<PO> GetPOes(SupplierResourceParameters supplierResourceParameters)
        {
            return _context.POes
                .OrderBy(a => a.SupplierName)
                .ThenBy(a => a.Id)
                .Skip(supplierResourceParameters.PageSize * (supplierResourceParameters.PageNumber - 1))
                .Take(supplierResourceParameters.PageSize)
                .ToList();
        }

        public void AddGileadWideSupplier(GileadWideSupplier result)
        {
            _context.GileadWideSuppliers.Add(result);
        }

   

    }
}

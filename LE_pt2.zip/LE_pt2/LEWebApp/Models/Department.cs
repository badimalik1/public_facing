﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LEWebApp.Models
{
   public class Department
    {
        public int Id { get; set; }
        public string DepartmentNameNum { get; set; }
        public string CostCenter { get; set; }
        public string CostCenterName { get; set; }

        public string LE { get; set; }
        public string DP_Department { get; set; }
        public string DepartmentRollOut { get; set; }
        public string DepartmentGroup { get; set; }

        public string DepartmentName { get; set; }
        public string DepartmentSubGroup { get; set; }
        public string SupplierIDBudgetLogic { get; set; }

        public string Region { get; set; }

        public string Region_Rpt { get; set; }

        public string LocalCurrency  { get; set; }

        public string LegalEntity { get; set; }

        public string LocationNumber  { get; set; }

        public string CountryGEO { get; set; }

        public string CityGEO { get; set; }

        public string LatitudeGEO { get; set; }
        public string Longitude { get; set; }

        public string FMOpsSubGroup  { get; set; }

        public string ForecastTE { get; set; }
        public string ForecastMS { get; set; }

        public string ForecastScheme { get; set; }

        public string FreeFormSupplier { get; set; }

        public string ForecastOwner { get; set; }

        public string ForecastOwnerSecondary { get; set; }

        public string ForecastReviewer { get; set; }

        public string ForecastReviewerFinal { get; set; }

        public string FPA_One  { get; set; }

        public string FPA_Two { get; set; }

        public string FPA_Three { get; set; }

        public string FPA_Four  { get; set; }

        public string FPA_Five { get; set; }

        public Int64 DepartmentNumber_Num { get; set; }
        public string DepartmentNumber_Str { get; set; }
       
    }
}

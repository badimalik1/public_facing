﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;

namespace LEWebApp.MappingProfiles
{
    public class EntityToDTOProfile : Profile
    {
        public EntityToDTOProfile()
        {
            CreateMap<LE.Core.User, DTOS.UserDTO>();
            CreateMap<DTOS.UserDTO, LE.Core.User>();


            //**********************************************************

            CreateMap<LE.Core.DepartmentString, DTOS.DepartmentStringsDTO>();
            CreateMap<DTOS.DepartmentStringsDTO, LE.Core.DepartmentString>();

            //**********************************************************

        }
    }
}

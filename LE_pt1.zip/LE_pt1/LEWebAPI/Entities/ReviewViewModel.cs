﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Entities
{
    public class ReviewViewModel
    {
        public int SupplierId { get; set; }
        public string AccountGroup { get; set; }
        public string SupplierName { get; set; }
        public string NaturalAccountName { get; set; }

        public string LastFiscalYear { get; set; }
        public string LastFiscalQuarter { get; set; }
        public string LastFiscalPeriod { get; set; }
        public int LastFiscalDate { get; set; }
        public decimal LastFiscalMonthJan { get; set; }
        public decimal LastFiscalMonthFeb { get; set; }
        public decimal LastFiscalMonthMar { get; set; }
        public decimal LastFiscalMonthApr { get; set; }
        public decimal LastFiscalMonthMay { get; set; }
        public decimal LastFiscalMonthJun { get; set; }
        public decimal LastFiscalMonthJul { get; set; }
        public decimal LastFiscalMonthAug { get; set; }
        public decimal LastFiscalMonthSep { get; set; }
        public decimal LastFiscalMonthOct { get; set; }
        public decimal LastFiscalMonthNov { get; set; }
        public decimal LastFiscalMonthDec { get; set; }
        /// <summary>
        /// ////////////////////////////////////////////////////////////////
        /// </summary>
        //******************************this year********************************//
        public string ThisFiscalYear { get; set; }
        public string ThisFiscalQuarter { get; set; }
        public string ThisFiscalPeriod { get; set; }
        public int ThisFiscalDate { get; set; }
        public decimal ThisFiscalMonthJan { get; set; }
        public decimal ThisFiscalMonthFeb { get; set; }
        public decimal ThisFiscalMonthMar { get; set; }
        public decimal ThisFiscalMonthApr { get; set; }
        public decimal ThisFiscalMonthMay { get; set; }
        public decimal ThisFiscalMonthJun { get; set; }
        public decimal ThisFiscalMonthJul { get; set; }
        public decimal ThisFiscalMonthAug { get; set; }
        public decimal ThisFiscalMonthSep { get; set; }
        public decimal ThisFiscalMonthOct { get; set; }
        public decimal ThisFiscalMonthNov { get; set; }
        public decimal ThisFiscalMonthDec { get; set; }

        /// <summary>
        /// ////////////////////////////////////////////////////////////////
        /// </summary>
        //******************************next year********************************//

        public string NextFiscalYear { get; set; }
        public string NextFiscalQuarter { get; set; }
        public string NextFiscalPeriod { get; set; }
        public int NextFiscalDate { get; set; }
        public decimal NextFiscalMonthJan { get; set; }
        public decimal NextFiscalMonthFeb { get; set; }
        public decimal NextFiscalMonthMar { get; set; }
        public decimal NextFiscalMonthApr { get; set; }
        public decimal NextFiscalMonthMay { get; set; }
        public decimal NextFiscalMonthJun { get; set; }
        public decimal NextFiscalMonthJul { get; set; }
        public decimal NextFiscalMonthAug { get; set; }
        public decimal NextFiscalMonthSep { get; set; }
        public decimal NextFiscalMonthOct { get; set; }
        public decimal NextFiscalMonthNov { get; set; }
        public decimal NextFiscalMonthDec { get; set; }

    }
}

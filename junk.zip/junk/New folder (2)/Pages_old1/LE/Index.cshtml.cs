﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using LE.Core;
using LE.Data;

namespace LEWebApp.Pages.LE
{
    public class IndexModel : PageModel
    {
        private readonly LEDbContext _context;

        public IndexModel(LEDbContext context)
        {
            _context = context;
        }

        public IList<TargetedSupplier> TargetedSupplier { get;set; }

        public async Task OnGetAsync()
        {
            TargetedSupplier = await _context.TargetedSuppliers.ToListAsync();
        }
    }
}

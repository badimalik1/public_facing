﻿using LE.Core;
using LE.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Implementations
{
    public class PriorForecastData : IPriorForecastData
    {
        private readonly LEDbContext _db;

        public PriorForecastData(LEDbContext db)
        {
            _db = db;
        }
        public int Commit()
        {
            throw new NotImplementedException();
        }

        public PriorForecast Delete(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<PriorForecast> GetAll(string dept)
        {
            var priorForcasts = _db.PriorForecasts
                                    .Where(a => a.DepartmentNameNum == dept)
                                    .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits" && a.AccountGroup != "AC_72000-Deprecation & Amortization" &&
                                                a.AccountGroup != "AC_73000-Other General Expense" && a.AccountGroup != "AC_68000-Promotional Programs" &&
                                                a.AccountGroup != "AC_63000-Training & Education" && a.AccountGroup != "AC_67000-Grants & Medical Education" &&
                                                a.AccountGroup != "AC_66000-Insurance")
                                    .Where(n => n.NaturalAccountName != "Airfare" && !n.NaturalAccountName.StartsWith("Meals & Entertainment") && !n.NaturalAccountName.StartsWith("Other Travel & Lodging") &&
                                                n.NaturalAccountName != "Business Gifts" && n.NaturalAccountName != "Employee Relations 1")
                                    .Where(s => s.SupplierName != "No Supplier Name" && s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                                    .Where(r => r.AccountNumber != 70015 && r.AccountNumber != 70020 &&
                                               r.AccountNumber != 70025 && r.AccountNumber != 70205 &&
                                               r.AccountNumber != 70065 && r.AccountNumber != 70070)
                                    .OrderBy(a => a.SupplierName)
                                    .Skip(5000 * (0))
                                    .Take(5000)
                                    .ToList();

            return priorForcasts;
        }
        public IEnumerable<PriorForecast> ReadByFiscalPeriod(string dept, string fiscalPeriod)
        {
            var priorForcasts = _db.PriorForecasts
                                    .Where(a => a.DepartmentNameNum == dept)
                                    .Where(f=> f.FiscalPeriod == fiscalPeriod)
                                    .OrderBy(a => a.SupplierName)
                                    .Skip(5000 * (0))
                                    .Take(5000)
                                    .ToList();

            return priorForcasts;
        }

        public PriorForecast GetById(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<PriorForecast> GetBySuplierName(string supplierName, string departmentId)
        {
            return _db.PriorForecasts
                      .Where(d => d.SupplierName == supplierName && d.DepartmentNameNum == departmentId)
                      .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits")
                      .Where(n => n.NaturalAccountName != "Airfare")
                      .OrderBy(a => a.NaturalAccountName)
                      .Skip(1000 * (0))
                      .Take(1000)
                      .ToList();
        }

        public int GetCountOfSuppliers()
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<PriorForecast>> GetSuppliersByName(string name)
        {
            throw new NotImplementedException();
        }


    }
}

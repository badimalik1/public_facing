using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc.UI;
using LE.Core;
using LE.Data;
using LE.Data.Interfaces;

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace LEWebApp.Pages.LE
{
    public class SupplierForecastModel : PageModel
    {
        private readonly IConfiguration _config;
        private readonly ILogger<SupplierForecastModel> _logger;
        private readonly ICurrentStartData _currentStartData;
        private readonly ITargetedSupplierData _targetedSupplierData;
        private readonly IAppData _appData;

        
        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        public string FullName { get; set; }

        public ICollection<DepartmentString> Departments { get; set; }

        public User UserData { get; set; }

        public string CurrentDepartment { get; set; }
        public int Year { get; set;  }

        public IEnumerable<Models.SupplierSubmitViewModel> _supplierViewModel { get; set; }

        public IEnumerable<TargetedSupplier> TargetedSuppliers { get; set; }

        IEnumerable<int> _supplierIds { get; set; }

        public SupplierForecastModel(IConfiguration config,  IAppData appData, ITargetedSupplierData targetedSupplierData, ILogger<SupplierForecastModel> logger)
        {
            _config = config;
            _logger = logger;
            _appData = appData;
            _targetedSupplierData = targetedSupplierData;
            TargetedSuppliers = new List<TargetedSupplier>();

        }
        public async Task OnGetAsync()
        {
            UserData = _appData.GetUser();

            if(UserData != null)
                FullName = UserData.FirstName + " " + UserData.LastName;

            Departments = new Collection<DepartmentString>();
            foreach(var dp in UserData.Departments)
            {
                Departments.Add(dp);
            }

            Year = DateTime.Now.Year;

            CurrentDepartment = await _appData.GetCurrentDepartment();

            //_supplierIds = await _appData.GetSupplierIds();

            //if(_supplierIds != null)
            //{
            //    foreach (var id in _supplierIds)
            //    {
            //        var supplier = await _targetedSupplierData.GetById(id);
            //        TargetedSuppliers.ToList().Add(supplier);
            //    }

            //}
            _logger.LogInformation("Supplier Forecast: OnGetAsync" );

            //var time = DateTime.FromOADate(43881);


        }


    }

}

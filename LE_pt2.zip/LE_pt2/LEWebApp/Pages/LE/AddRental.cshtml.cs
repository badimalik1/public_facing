using System;
using System.Collections.Generic;
using System.Linq;
using LE.Core;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using LE.Data.Interfaces;

namespace LEWebApp.Pages.LE
{
    public class AddRentalModel : PageModel
    {
        [BindProperty]
        public PO PO { get; set; }

        public bool PONumberReqired { get; set; }

        [BindProperty]
        //[ValidationHelper(nameof(PONumberReqired), "true", ErrorMessage = "PO Number is Required")]
        public string PONumber { get; set; }

        private readonly IAppData _appData;       
        private readonly IPendingData _pendingData;
        private readonly INaturalAccountData _accountData;
        private readonly ICurrentStartData _currentStartData;

        string _departmentID = "";
        string _supplierName = "";

        //[FromQuery(Name = "supplierName")]
        //public string SupplierName { get; set; }

        public AddRentalModel(IAppData appData, ICurrentStartData currentStartData,
                              IPendingData pendingData, INaturalAccountData accountData)
        {
            _appData = appData;
            _accountData = accountData;
            _pendingData = pendingData;
            _currentStartData = currentStartData;
            _supplierName = _appData.GetCurrentSupplier();
        }

        public IActionResult OnPostAsync()
        {
            var POVal = (string.IsNullOrEmpty(PONumber) || string.IsNullOrWhiteSpace(PONumber));

            if (_appData.GetPORequired() && POVal)
            {
                PONumberReqired = true;
                ModelState.AddModelError("PONumber", "This account already exists for this supplier, to add another instance of this account, please add a PO number (real or a placeholder).");
            }

            if (!ModelState.IsValid)
            {
                return Page();
            }

            _departmentID = _appData.GetCurrentDepartment().Result;
            var naturalAccountName = _appData.GetNaturalAccountLineItem();
            var accounts = _accountData.GetRentAccountsBySupplierName(" ").ToList();

            var accountItem = accounts.Where(a => a.NaturalAccountName == naturalAccountName).FirstOrDefault();

            var currentStart = new CurrentStart()
            {
                SupplierName = "No Supplier Name",
                DepartmentNameNum = _departmentID,
                NaturalAccountName = naturalAccountName,
                POLineDescription = PO.POLineDescription ?? " ",
                PONumber = PONumber ?? " ",
                FiscalYear = "2021",
                FiscalPeriod = "Mar-21",
                AccountNumber = accountItem.AccountNum,
                AccountGroup = accountItem.AccountGroup,
                TotalLC = 0,
                TotalUSD = 0,
                Scenario = "FCST"

            };

            var addId = _currentStartData.AddForecast(currentStart);
            var pending = new Pending()
            {
                CSID = addId,
                Department = _departmentID,
                NaturalAccountName = naturalAccountName,
                SupplierName = "No Supplier Name",
                PONumber = PONumber
            };

            _pendingData.AddPending(pending);


            return RedirectToPage("./RentForecast");
        }
    }
}

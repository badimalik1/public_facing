﻿using LEWebAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Services
{
    public interface IUserRepository
    {
        void AddUser(User userObj);
        void DeleteUser(User userObj);
        User UpdateUser(User userObj);
        User GetUser(string username, string password);
        ICollection<DepartmentString> GetDepartments(int userId);
    }
}

﻿using Kendo.Mvc.UI;
using LE.Core;
using LE.Data.Interfaces;
using LEWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    [Route("api/spreadsheet")]
    public class SpreadsheetController : Controller
    {
        private readonly ICurrentStartData _currentStartData;
        public SpreadsheetController( ICurrentStartData currentStart)
        {
            _currentStartData = currentStart;
        }
        public IActionResult Index()
        {
            return View();
        }

        //[HttpPost]
        //public ActionResult TaxData_Submit(SpreadsheetSubmitViewModel stagingInfos)
        //{

        //    var result = new List<SupplierSubmitViewModel>();
        //    return Json(result);

        //    // return StatusCode(200, "The data has been posted.");
        //}


        public IActionResult SupplierDetails(string supplierName)
        {
            //var currentStarts = _currentstartRepository.GetCurrentStarts(supplierResourceParameters, departmentId);

            //var highestBy = currentStarts
             //   .GroupBy(s => s.SupplierName)
             //   .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
              //  .ToList();


            return Redirect("~/LE/SupplierDetails");
        }

        [HttpPost]
        public RedirectResult Data_Source_Spreadsheet_Submit()
        {
            var testdata = HttpContext.Request.ContentLength;

            //var result = new List<SupplierSubmitViewModel>();
            // return Json(result);

            // return View();
            //return RedirectToPage("Review");
            return Redirect("https://localhost:44308/LE/Review");

        }

    }
}

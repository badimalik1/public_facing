﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Interfaces
{
    public interface IGileadWideSupplierData
    {
        Task<GileadWideSupplier> GetById(int id);
        IEnumerable<GileadWideSupplier> GetBySuplierNumber(int supplierNumber);

    }
}

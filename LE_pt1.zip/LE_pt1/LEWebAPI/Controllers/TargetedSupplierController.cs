﻿
using AutoMapper;
using LEWebAPI.DTOs;
using LEWebAPI.Entities;
using LEWebAPI.Helpers;
using LEWebAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Controllers
{
    [Route("api/targetedsuppliers")]
    public class TargetedSupplierController : Controller
    {
        private readonly IMapper _mapper;
        private ITargetedSupplierRepository _targetedSupplierRepository;
     
        public TargetedSupplierController(ITargetedSupplierRepository targetedSupplierRepository, IMapper mapper)
        {
            _mapper = mapper;
            _targetedSupplierRepository = targetedSupplierRepository;
        }
 
        public IActionResult  GetTargetedSuppliers(SupplierResourceParameters supplierResourceParameters)
        {
           
            var targetedSuppliers = _targetedSupplierRepository.GetTargetedSuppliers(supplierResourceParameters)
                .Where(s=> s.OperatingUnit == "US-OU-01");
            return new JsonResult(targetedSuppliers);

        }

        [Route("getSuppliersByName")]
        [HttpGet("{name}")]
        public IActionResult GetSuppliersByName(string name)
        {
            var targetedSuppliers = _targetedSupplierRepository.GetSuppliersByName(name);
            return new JsonResult(targetedSuppliers);
        }

        [Route("createTargetdSupplier")]
        [HttpPost("targetedSupplier")]
        public IActionResult CreateTargetedSupplier([FromBody]TargetedSupplierDTO targetedSupplier)
        {

            if (targetedSupplier == null)
            {
                return BadRequest();
            }

            //if (currentStart.Description == currentStart.Name)
            //{
            //    ModelState.AddModelError("Description", "The provided description should be different from the name");
            //}

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }


            if (_targetedSupplierRepository.SupplierExists(targetedSupplier.SupplierName))
            {
                return BadRequest();
            }

            var result = _mapper.Map<TargetedSupplierDTO, Entities.TargetedSupplier>(targetedSupplier);

            _targetedSupplierRepository.AddTargetedSupplier(result);
            if (!_targetedSupplierRepository.Save())
            {
                return StatusCode(500, "Problem creating destination.");
            }

            var createdTargetedSupplier = _mapper.Map<Entities.TargetedSupplier, Models.TargetedSupplierDTO>(result);

          
            return new JsonResult(createdTargetedSupplier);
            //CreatedAtRoute("GetCurrentStarts", new { createdTargetedSupplier.SupplierName }, createdTargetedSupplier)
            //return NoContent();
        }
    }
}

﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LE.Core
{
    public class DepartmentString
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string DepartmentNameNum { get; set; }
        [ForeignKey("User")]
        public int UserId { get; set; }

        public User User { get; set; }
    }

}

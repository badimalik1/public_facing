﻿using AutoMapper;
using AutoMapper.Configuration;
using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace LEWebApp.Controllers
{
    //[EnableCors("_myAllowSpecificOrigins")]
    //[Route("api/currentStart")]
    public class CurrentStartController : Controller
    {
        public User UserData { get; set; }
        private readonly IAppData _appData;
        private readonly IPreferencesData _prefsData;
        public string CurrentDepartment { get; set; }
        private readonly ICurrentStartData _currentStartData;

        public ICollection<DepartmentString> Departments { get; set; }

        public IEnumerable<CurrentStart> CurrentStarts { get; set; }

        private readonly ILogger _logger;

        public CurrentStartController(ICurrentStartData currentStartData, IAppData appData,
                                      ILogger<CurrentStartController> logger, IPreferencesData prefsData)
        {

            _appData = appData;
            _prefsData = prefsData;
            _currentStartData = currentStartData;
            UserData = _appData.GetUser();
            _logger = logger;

        }

        [HttpGet()]
        public IActionResult GetSupplierCurrentStarts()
        {
            Task.Run(async () =>
            {
                CurrentDepartment = await _appData.GetCurrentDepartment();
            });

            Departments = new Collection<DepartmentString>();
            foreach (var dp in UserData.Departments)
            {
                Departments.Add(dp);
            }
            var dept = CurrentDepartment = CurrentDepartment != null ? CurrentDepartment : Departments.FirstOrDefault().DepartmentNameNum;
            var currentStarts = _currentStartData.ReadSupplierForecast(dept);

            var startYear = int.Parse(_prefsData.GetStartYear());

            var lastYear = (startYear - 1);
            var thisYear = (startYear);
            var nextYear = (startYear + 1);
            var yearAfterNext = (startYear + 2);

            var fiscalYearExtracts = currentStarts
                                    .Where(c => c.FiscalYear != lastYear.ToString() && c.Scenario != "Actual");


            var currentStartActuals = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());

            IEnumerable<CurrentStart> highestActuals = null;
            if (currentStartActuals.Count() > 0)
            {
                highestActuals = currentStartActuals
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.TotalLC).First())
                .ToList();

            }
            else
            {
                highestActuals = fiscalYearExtracts
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.TotalLC).First())
                .ToList();
            }

            var supplierList = highestActuals.Select(supplier => new SupplierViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                FiscalYear1 = supplier.TotalLC != 0 ? supplier.TotalLC : supplier.TotalLC,
                FiscalYear2 = fiscalYearExtracts.Where(f => f.FiscalYear == thisYear.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.TotalLC ?? default(decimal),
                FiscalYear3 = fiscalYearExtracts.Where(f => f.FiscalYear == nextYear.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.TotalLC ?? default(decimal),
                FiscalYear4 = fiscalYearExtracts.Where(f => f.FiscalYear == yearAfterNext.ToString() && supplier.SupplierName == f.SupplierName).FirstOrDefault()?.TotalLC ?? default(decimal)
            });

            return new JsonResult(supplierList);
        }


        public IActionResult GetCurrentStarts(string departmentId)
        {
 
            var lastYear = (DateTime.Now.Year - 1);
            var thisYear = (DateTime.Now.Year);
            var nextYear = (DateTime.Now.Year + 1);
            var yearAfterNext = (DateTime.Now.Year + 2);

            try
            {
                //TODO: give this hack its own method

                var dept = HttpUtility.UrlDecode(departmentId);
                var dept2 = HttpUtility.UrlDecode(dept);

                int foundStr = dept.IndexOf("amp;");
                int foundStr2 = dept2.IndexOf(" ", foundStr+1);

                if(foundStr != foundStr2 && foundStr>= 0)
                {
                    dept = dept.Remove(foundStr, foundStr2-foundStr);
                }
                //////////////////////////////////////////////////////
                
                var currentStarts = _currentStartData.ReadSupplierForecast(dept);
                IEnumerable<CurrentStart> highestActuals = null;
                IEnumerable<SupplierViewModel> supplierList = null;
                if (currentStarts.Count() > 0)
                {
                    highestActuals = currentStarts
                    .GroupBy(s => s.SupplierName)
                    .Select(g => g.OrderByDescending(t => t.TotalLC).First())
                    .ToList();

                    var gbFiscal = currentStarts
                        .GroupBy(f => f.FiscalYear).ToList();

                    var highest = gbFiscal
                    .GroupBy(s => s.Select( (supplier) => new
                    {
                        Id = supplier.Id,
                        SupplierName = supplier.SupplierName,
                        FiscalYear = supplier.FiscalYear, 
                        TotalLC = supplier.TotalLC

                    })).ToList();

                
                    var year1 = highest[0];
                    var year1_totals = year1.Key
                        .GroupBy(s => s.SupplierName)
                        .Select(g => g.OrderByDescending(t => t.TotalLC).First())                
                        .ToList();

                    var year2 = highest[1];
                    var year2_totals = year2.Key
                        .GroupBy(s => s.SupplierName)
                        .Select(g => g.OrderByDescending(t => t.TotalLC).First())
                        .ToList();

                    var year3 = highest[2];
                    var year3_totals = year3.Key
                        .GroupBy(s => s.SupplierName)
                        .Select(g => g.OrderByDescending(t => t.TotalLC).First())
                        .ToList();

                
                    //var year4 = highest[3];
                    //var year4_totals = year4.Key
                    //    .GroupBy(s => s.SupplierName)
                    //   .Select(g => g.OrderByDescending(t => t.TotalLC).First())
                    //    .ToList();



                    supplierList = year1_totals.Select(supplier => new SupplierViewModel
                    {
                        SupplierId = supplier.Id,
                        SupplierName = supplier.SupplierName,
                        FiscalYear1 = (decimal?)(year1_totals.Where(f => f.SupplierName == supplier.SupplierName).FirstOrDefault()?.TotalLC) ?? default,
                        FiscalYear2 = (decimal?)(year2_totals.Where(f => f.SupplierName == supplier.SupplierName).FirstOrDefault()?.TotalLC) ?? default,
                        FiscalYear3 = (decimal?)(year3_totals.Where(f => f.SupplierName == supplier.SupplierName).FirstOrDefault()?.TotalLC) ?? default,
                        //FiscalYear4 = (decimal?)(year4_totals.Where(f => f.SupplierName == supplier.SupplierName).FirstOrDefault()?.TotalLC) ?? default
                    });

                    //cache supplier names
                    List<string> forecastStrings = new List<string>();
                    highestActuals.ToList().ForEach(n => { forecastStrings.Add(n.SupplierName); });

                    if (forecastStrings.Count > 0)
                        _appData.SetSupplierNames(forecastStrings);

                }
                else
                {
                    return new JsonResult(null);  
                }

                //cache current dept 
                CurrentDepartment = departmentId;
                _appData.SetDepartment(departmentId);



                return new JsonResult(supplierList);
            }
            catch (Exception ex)
            {
                _logger.LogError("GetCurrentStarts failed: " + ex);
                //return BadRequest("Get Current Start Failed - CurrentStartController: " + ex);
                return new JsonResult(null);
            }
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Data.Interfaces
{
    public interface IPreferencesData
    {
        string GetStartYear();
        string GetStartDate();
        string GetEndDate();
        string GetForecastPeriod();
    }
}

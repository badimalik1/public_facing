﻿using Kendo.Mvc.UI;
using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class TaxController : Controller
    {
        public User UserData { get; set; }
        private readonly IAppData _appData;
        private readonly IPreferencesData _prefsData;
        public string CurrentDepartment { get; set; }
        private readonly ITaxData _taxData;

        public ICollection<DepartmentString> Departments { get; set; }

        public IEnumerable<CurrentStart> CurrentStarts { get; set; }

        public TaxController(ITaxData taxData, IAppData appData, IPreferencesData prefsData)
        {

            _appData = appData;
            _taxData = taxData;
            _prefsData = prefsData;
            UserData = _appData.GetUser();

        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public RedirectResult Data_Source_Spreadsheet_Submit()
        {
            var testdata = HttpContext.Request.ContentLength;

            //var result = new List<SupplierSubmitViewModel>();
            // return Json(result);

            // return View();
            //return RedirectToPage("Review");
            return Redirect("https://localhost:44308/LE/Review");

        }

        [HttpGet()]
        [AcceptVerbs("Get")]
        public IActionResult GetCurrentStartTaxes(string departmentId)
        {
            Task.Run(async () =>
            {
                CurrentDepartment = await _appData.GetCurrentDepartment();
            });

            Departments = new Collection<DepartmentString>();
            foreach (var dp in UserData.Departments)
            {
                Departments.Add(dp);
            }
            var dept = CurrentDepartment = CurrentDepartment != null ? CurrentDepartment : departmentId;


            var currentStarts = _taxData.ReadTaxForecast(dept);

            var startYear = int.Parse(_prefsData.GetStartYear());

            var lastYear = (startYear - 1);
            var thisYear = (startYear);
            var nextYear = (startYear + 1);
            var yearAfterNext = (startYear + 2);

            //var fiscalYearExtracts = currentStarts
            //                        .Where(c => c.FiscalYear != lastYear.ToString() && c.Scenario != "Actual");


            //var currentStartActuals = currentStarts.Where(r => r.FiscalYear == lastYear.ToString());

            //var highestActualsBy = currentStartActuals
            //    .GroupBy(s => s.SupplierName)
            //    .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
            //    .ToList();



            var supplierList = currentStarts.Select(supplier => new RentsViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                POLineDescription = supplier.POLineDescription,
                LEComments = supplier.Comments,
                Scenario = supplier.Scenario,
                VarianceComments = supplier.VarianceComments,

                ///////////////////////last year///////////////////////////////////////
                LastFiscalYear = supplier.FiscalYear,
                LastFiscalQuarter = supplier.FiscalQuarter,
                LastFiscalPeriod = supplier.FiscalPeriod,
                LastFiscalDate = supplier.FiscalDate,
                LastFiscalMonthJan = (supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthFeb = (supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMar = (supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthApr = (supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMay = (supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJun = (supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJul = (supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthAug = (supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthSep = (supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthOct = (supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthNov = (supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthDec = (supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ///////////////////////this year/////////////////////////////////////////////
                ThisFiscalYear = supplier.FiscalYear,
                ThisFiscalQuarter = supplier.FiscalQuarter,
                ThisFiscalPeriod = supplier.FiscalPeriod,
                ThisFiscalDate = supplier.FiscalDate,
                ThisFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                /////////////////////////////////////next year///////////////////////////////////////////
                NextFiscalYear = supplier.FiscalYear,
                NextFiscalQuarter = supplier.FiscalQuarter,
                NextFiscalPeriod = supplier.FiscalPeriod,
                NextFiscalDate = supplier.FiscalDate,
                NextFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                //////////////////////////////////YAN////////////////////////////////////////////////////////////////////
                YANFiscalYear = supplier.FiscalYear,
                YANFiscalQuarter = supplier.FiscalQuarter,
                YANFiscalPeriod = supplier.FiscalPeriod,
                YANFiscalDate = supplier.FiscalDate,
                YANFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0



            });

            var tmp = supplierList.GroupBy(s => new { s.SupplierName, s.POLineDescription })
            .Select(g =>
                new RentsViewModel
                {
                    SupplierName = g.Key.SupplierName,
                    POLineDescription = g.Key.POLineDescription,
                    LEComments = g.Select(l => l.LEComments).FirstOrDefault(),
                    //LastFiscalYear = g.Key.LastFiscalYear,
                    //LastFiscalQuarter = g.FiscalQuarter,
                    //LastFiscalPeriod = g.FiscalPeriod,
                    //LastFiscalDate = g.FiscalDate,
                    LastPriorFcst = g.Select(l => l.LastPriorFcst).FirstOrDefault(),


                    LastFiscalMonthJan = g.Sum(b => b.LastFiscalMonthJan),
                    LastFiscalMonthFeb = g.Sum(b => b.LastFiscalMonthFeb),
                    LastFiscalMonthMar = g.Sum(b => b.LastFiscalMonthMar),
                    LastFiscalMonthApr = g.Sum(b => b.LastFiscalMonthApr),
                    LastFiscalMonthMay = g.Sum(b => b.LastFiscalMonthMay),
                    LastFiscalMonthJun = g.Sum(b => b.LastFiscalMonthJun),
                    LastFiscalMonthJul = g.Sum(b => b.LastFiscalMonthJul),
                    LastFiscalMonthAug = g.Sum(b => b.LastFiscalMonthAug),
                    LastFiscalMonthSep = g.Sum(b => b.LastFiscalMonthSep),
                    LastFiscalMonthOct = g.Sum(b => b.LastFiscalMonthOct),
                    LastFiscalMonthNov = g.Sum(b => b.LastFiscalMonthNov),
                    LastFiscalMonthDec = g.Sum(b => b.LastFiscalMonthDec),
                    ////////////////////////////////////////////////////////////////////////////////////

                    ThisPriorFcst = g.Select(l => l.ThisPriorFcst).FirstOrDefault(),

                    ThisFiscalMonthJan = g.Sum(b => b.ThisFiscalMonthJan),
                    ThisFiscalMonthFeb = g.Sum(b => b.ThisFiscalMonthFeb),
                    ThisFiscalMonthMar = g.Sum(b => b.ThisFiscalMonthMar),
                    ThisFiscalMonthApr = g.Sum(b => b.ThisFiscalMonthApr),
                    ThisFiscalMonthMay = g.Sum(b => b.ThisFiscalMonthMay),
                    ThisFiscalMonthJun = g.Sum(b => b.ThisFiscalMonthJun),
                    ThisFiscalMonthJul = g.Sum(b => b.ThisFiscalMonthJul),
                    ThisFiscalMonthAug = g.Sum(b => b.ThisFiscalMonthAug),
                    ThisFiscalMonthSep = g.Sum(b => b.ThisFiscalMonthSep),
                    ThisFiscalMonthOct = g.Sum(b => b.ThisFiscalMonthOct),
                    ThisFiscalMonthNov = g.Sum(b => b.ThisFiscalMonthNov),
                    ThisFiscalMonthDec = g.Sum(b => b.ThisFiscalMonthDec),

                    /////////////////////////////////////////////////////////////////////////////////////
                    ///
                    NextPriorFcst = g.Select(l => l.NextPriorFcst).FirstOrDefault(),

                    NextFiscalMonthJan = g.Sum(b => b.NextFiscalMonthJan),
                    NextFiscalMonthFeb = g.Sum(b => b.NextFiscalMonthFeb),
                    NextFiscalMonthMar = g.Sum(b => b.NextFiscalMonthMar),
                    NextFiscalMonthApr = g.Sum(b => b.NextFiscalMonthApr),
                    NextFiscalMonthMay = g.Sum(b => b.NextFiscalMonthMay),
                    NextFiscalMonthJun = g.Sum(b => b.NextFiscalMonthJun),
                    NextFiscalMonthJul = g.Sum(b => b.NextFiscalMonthJul),
                    NextFiscalMonthAug = g.Sum(b => b.NextFiscalMonthAug),
                    NextFiscalMonthSep = g.Sum(b => b.NextFiscalMonthSep),
                    NextFiscalMonthOct = g.Sum(b => b.NextFiscalMonthOct),
                    NextFiscalMonthNov = g.Sum(b => b.NextFiscalMonthNov),
                    NextFiscalMonthDec = g.Sum(b => b.NextFiscalMonthDec),

                    /////////////////////////////////////////////////////////////////////////////////////////////////////
                    ///

                    YANPriorFcst = g.Select(l => l.YANPriorFcst).FirstOrDefault(),

                    YANFiscalMonthJan = g.Sum(b => b.YANFiscalMonthJan),
                    YANFiscalMonthFeb = g.Sum(b => b.YANFiscalMonthFeb),
                    YANFiscalMonthMar = g.Sum(b => b.YANFiscalMonthMar),
                    YANFiscalMonthApr = g.Sum(b => b.YANFiscalMonthApr),
                    YANFiscalMonthMay = g.Sum(b => b.YANFiscalMonthMay),
                    YANFiscalMonthJun = g.Sum(b => b.YANFiscalMonthJun),
                    YANFiscalMonthJul = g.Sum(b => b.YANFiscalMonthJul),
                    YANFiscalMonthAug = g.Sum(b => b.YANFiscalMonthAug),
                    YANFiscalMonthSep = g.Sum(b => b.YANFiscalMonthSep),
                    YANFiscalMonthOct = g.Sum(b => b.YANFiscalMonthOct),
                    YANFiscalMonthNov = g.Sum(b => b.YANFiscalMonthNov),
                    YANFiscalMonthDec = g.Sum(b => b.YANFiscalMonthDec),


                }
            );

            return new JsonResult(tmp);
        }

        [HttpPost()]
        [AcceptVerbs("Post")]
        public IActionResult CreateTaxSupplier(string[] currentStart)
        {


            if (currentStart == null)
            {
                return BadRequest();
            }

            var startYear = int.Parse(_prefsData.GetStartYear());

            var lastYear = (startYear - 1);
            var thisYear = (startYear-1);
            var nextYear = (startYear );
            var yearAfterNext = (startYear + 2);

            try
            {
                var supplierData = JsonConvert.DeserializeObject<RentsViewModel[]>(currentStart[0]);

                var supplierDataList = supplierData.ToList();

                CurrentStart currStartAdd = null;
                var fiscalDate = Convert.ToInt32(DateTime.Now.ToOADate());

                foreach (var item in supplierDataList)
                {

                    var currStart = _taxData.GetCurrentStart(item.SupplierId);

                    currStartAdd = GetNewCurrentStart(currStart);
                    currStartAdd.SupplierName = item.SupplierName;


                    if (item.ThisFiscalMonthApr != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthApr;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthApr;
                        currStartAdd.FiscalPeriod = "Apr-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthAug != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthAug;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthAug;
                        currStartAdd.FiscalPeriod = "Aug-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthDec != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthDec;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthDec;
                        currStartAdd.FiscalPeriod = "Dec-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthFeb != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthFeb;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthFeb;
                        currStartAdd.FiscalPeriod = "Feb-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthJan != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthJan;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthJan;
                        currStartAdd.FiscalPeriod = "Jan-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthJul != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthJul;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthJul;
                        currStartAdd.FiscalPeriod = "Jul-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthJun != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthJun;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthJun;
                        currStartAdd.FiscalPeriod = "Jun-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthMar != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthMar;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthMar;
                        currStartAdd.FiscalPeriod = "Mar-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthMay != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthMay;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthMay;
                        currStartAdd.FiscalPeriod = "May-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthNov != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthNov;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthNov;
                        currStartAdd.FiscalPeriod = "Nov-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthOct != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthOct;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthOct;
                        currStartAdd.FiscalPeriod = "Oct-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.ThisFiscalMonthSep != 0)
                    {
                        currStartAdd.FiscalYear = thisYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthSep;
                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthSep;
                        currStartAdd.FiscalPeriod = "Sep-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    if (item.NextFiscalMonthApr != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthApr;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthApr;
                        currStartAdd.FiscalPeriod = "Apr-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthAug != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthAug;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthAug;
                        currStartAdd.FiscalPeriod = "Aug-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthDec != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthDec;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthDec;
                        currStartAdd.FiscalPeriod = "Dec-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthFeb != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthFeb;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthFeb;
                        currStartAdd.FiscalPeriod = "Feb-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthJan != 0)
                    {
                        currStartAdd.FiscalYear = DateTime.Now.Year.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthJan;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthJan;
                        currStartAdd.FiscalPeriod = "Jan-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthJul != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthJul;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthJul;
                        currStartAdd.FiscalPeriod = "Jul-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthJun != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthJun;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthJun;
                        currStartAdd.FiscalPeriod = "Jun-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthMar != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthMar;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthMar;
                        currStartAdd.FiscalPeriod = "Mar-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthMay != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthMay;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthMay;
                        currStartAdd.FiscalPeriod = "May-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthNov != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthNov;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthNov;
                        currStartAdd.FiscalPeriod = "Nov-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthOct != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthOct;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthOct;
                        currStartAdd.FiscalPeriod = "Oct-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    if (item.NextFiscalMonthSep != 0)
                    {
                        currStartAdd.FiscalYear = nextYear.ToString();
                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthSep;
                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthSep;
                        currStartAdd.FiscalPeriod = "Sep-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                        if (item.VarianceComments != null && item.VarianceComments != " ")
                        {
                            currStartAdd.VarianceComments = item.VarianceComments;
                        }
                        _taxData.AddCurrentStart(currStartAdd);
                        SaveData();
                        currStartAdd = GetNewCurrentStart(currStart);
                        currStartAdd.SupplierName = item.SupplierName;
                    }
                    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    //if (item.YANFiscalMonthApr != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthApr;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthApr;
                    //    currStartAdd.FiscalPeriod = "Apr-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q2-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthAug != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthAug;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthAug;
                    //    currStartAdd.FiscalPeriod = "Aug-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q3-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);

                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthDec != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthDec;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthDec;
                    //    currStartAdd.FiscalPeriod = "Dec-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q4-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthFeb != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthFeb;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthFeb;
                    //    currStartAdd.FiscalPeriod = "Feb-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q1-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthJan != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.NextFiscalMonthSep;
                    //    currStartAdd.BudgetUSD = item.NextFiscalMonthSep;
                    //    currStartAdd.FiscalPeriod = "Jan-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q1-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthJul != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthJan;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthJan;
                    //    currStartAdd.FiscalPeriod = "Jul-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q3-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthJun != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthJun;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthJun;
                    //    currStartAdd.FiscalPeriod = "Jun-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q2-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthMar != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthMar;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthMar;
                    //    currStartAdd.FiscalPeriod = "Mar-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q1-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthMay != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthMay;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthMay;
                    //    currStartAdd.FiscalPeriod = "May-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q2-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthNov != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthNov;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthNov;
                    //    currStartAdd.FiscalPeriod = "Nov-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q4-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthOct != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthOct;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthOct;
                    //    currStartAdd.FiscalPeriod = "Oct-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q4-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //if (item.YANFiscalMonthSep != 0)
                    //{
                    //    currStartAdd.FiscalYear = yearAfterNext.ToString();
                    //    currStartAdd.BudgetLC = item.YANFiscalMonthSep;
                    //    currStartAdd.BudgetUSD = item.YANFiscalMonthSep;
                    //    currStartAdd.FiscalPeriod = "Sep-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q3-" + yearAfterNext.ToString().Substring(yearAfterNext.ToString().Length - 2);
                    //    if (item.VarianceComments != null && item.VarianceComments != " ")
                    //    {
                    //        currStartAdd.VarianceComments = item.VarianceComments;
                    //    }
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    currStartAdd = GetNewCurrentStart(currStart);
                    //    currStartAdd.SupplierName = item.SupplierName;
                    //}
                    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                    //if (item.LastFiscalMonthApr != 0) { }
                    //if (item.LastFiscalMonthAug != 0) { }                    
                    //if (item.LastFiscalMonthFeb != 0) { }
                    //if (item.LastFiscalMonthJan != 0) { }
                    //if (item.LastFiscalMonthJul != 0) { }
                    //if (item.LastFiscalMonthJun != 0) { }
                    //if (item.LastFiscalMonthMar != 0) { }
                    //if (item.LastFiscalMonthMay != 0) { }
                    //if (item.LastFiscalMonthSep != 0) { }

                    //if (item.LastFiscalMonthOct != 0)
                    //{
                    //    currStartAdd.FiscalYear = lastYear.ToString();
                    //    currStartAdd.BudgetLC = item.LastFiscalMonthOct;
                    //    currStartAdd.BudgetUSD = item.LastFiscalMonthOct;
                    //    currStartAdd.FiscalPeriod = "Oct-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q4" + "-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);

                    //    //if(item.LastFiscalMonthDec != currStart.BudgetLC && item.SupplierId == currStart.Id) _taxData.UpdateCurrentStart(currStart)) else
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //}
                    //if (item.LastFiscalMonthNov != 0)
                    //{
                    //    currStartAdd.FiscalYear = lastYear.ToString();
                    //    currStartAdd.BudgetLC = item.LastFiscalMonthNov;
                    //    currStartAdd.BudgetUSD = item.LastFiscalMonthNov;
                    //    currStartAdd.FiscalPeriod = "Nov-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q4" + "-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);

                    //    //if(item.LastFiscalMonthDec != currStart.BudgetLC && item.SupplierId == currStart.Id) _taxData.UpdateCurrentStart(currStart)) else
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //}
                    //if (item.LastFiscalMonthDec != 0)
                    //{
                    //    currStartAdd.FiscalYear = lastYear.ToString();
                    //    currStartAdd.BudgetLC = item.LastFiscalMonthDec;
                    //    currStartAdd.BudgetUSD = item.LastFiscalMonthDec;
                    //    currStartAdd.FiscalPeriod = "Dec-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);
                    //    currStartAdd.FiscalQuarter = "Q4" + "-" + lastYear.ToString().Substring(lastYear.ToString().Length - 2);

                    //    //if (item.LastFiscalMonthDec != currStart.BudgetLC  && item.SupplierId == currStart.Id)
                    //    //{

                    //    //    var content = currStart.ToPatchJsonContent();//Invoke the extension method to serialize the object
                    //    //    //UpdateRentCurrentStartInternal(currStart.Id, patchDoc);
                    //    //}
                    //    //else { 
                    //    _taxData.AddCurrentStart(currStartAdd);
                    //    SaveData();
                    //    //}
                    //}


                }

                return new JsonResult(currStartAdd);

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            return Ok();

        }
        private IActionResult SaveData()
        {
            if (!_taxData.Save())
            {
                return StatusCode(500, "Problem creating Current Start Record.");
            }

            return Ok();
        }
        private CurrentStart GetNewCurrentStart(CurrentStart currStart)
        {

            var currStartAdd = new CurrentStart()
            {
                ProjectName = currStart.ProjectName,
                Scenario = "SEPLE",
                POLineDescription = currStart.POLineDescription,
                DepartmentNameNum = currStart.DepartmentNameNum,
                BudgetUSD_1 = currStart.BudgetUSD_1,
                BudgetLC_1 = currStart.BudgetLC_1,
                Comments = currStart.Comments,

                DepartmentName = currStart.DepartmentName,
                DepartmentNumber = currStart.DepartmentNumber,
                DepartmentGroup = currStart.DepartmentGroup,
                DepartmentSubGroup = currStart.DepartmentSubGroup,
                CostCenterNumber = currStart.CostCenterNumber,

                AccountGroup = currStart.AccountGroup,
                AccountNumber = currStart.AccountNumber,
                NaturalAccountName = currStart.NaturalAccountName,
                ProjectTaskNumber = currStart.ProjectTaskNumber,
                PONumber = currStart.PONumber,

                SupplierNumber = currStart.SupplierNumber,
                PurchaseInvoiceNumber = currStart.PurchaseInvoiceNumber,
                ActualUSD = 0,
                CountryCity = currStart.CountryCity,
                Region = currStart.Region,
                Region_Rpt = currStart.Region_Rpt,
                FPAAccrualsReclasses = currStart.FPAAccrualsReclasses,
                SupplierType = currStart.SupplierType,
                FiscalDate = Convert.ToInt32(DateTime.Now.ToOADate()).ToString(),
                LocalCurrency = currStart.LocalCurrency,
                OriginalSupplierName = currStart.OriginalSupplierName,
                DepartmentRollOut = currStart.DepartmentRollOut,
                UniqueListACC = currStart.UniqueListACC,
                UniqueListDEPT = currStart.UniqueListDEPT,

            };

            return currStartAdd;
        }

    }
}

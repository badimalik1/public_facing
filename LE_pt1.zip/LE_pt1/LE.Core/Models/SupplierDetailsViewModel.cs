﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LE.Core
{
    public class SupplierDetailsViewModel
    {
        public int CurrentStartId { get; set; }
        public string NaturalAccountName { get; set; }
        public string PONumber { get; set; }
        public string POLineDescription { get; set; }
        public string LEComments { get; set; }

        public string Scenario { get; set; }

        public string Blank { get; set; }
        public string VarianceComments { get; set; }

        /// <summary>
        /// ///////////////////////////////////////////////////
        /// 
        /// 
        /// </summary>
        /// 
        
        public decimal? ThisPriorFcst { get; set; }
        public decimal? NextPriorFcst { get; set; }
        public decimal? YANPriorFcst { get; set; }
        public decimal? YearAfterYanPriorFcst { get; set; }

        public decimal? NextFiscalMonthJan { get; set; }
        public decimal? NextFiscalMonthFeb { get; set; }
        public decimal? NextFiscalMonthMar { get; set; }
        public decimal? NextFiscalMonthApr { get; set; }
        public decimal? NextFiscalMonthMay { get; set; }
        public decimal? NextFiscalMonthJun { get; set; }
        public decimal? NextFiscalMonthJul { get; set; }
        public decimal? NextFiscalMonthAug { get; set; }
        public decimal? NextFiscalMonthSep { get; set; }
        public decimal? NextFiscalMonthOct { get; set; }
        public decimal? NextFiscalMonthNov { get; set; }
        public decimal? NextFiscalMonthDec { get; set; }

        public decimal? LastYearTotal { get; set; }

        /////////////////////////////////////////////////////////////
        ///
        public decimal? ThisFiscalMonthJan { get; set; }
        public decimal? ThisFiscalMonthFeb { get; set; }
        public decimal? ThisFiscalMonthMar { get; set; }
        public decimal? ThisFiscalMonthApr { get; set; }
        public decimal? ThisFiscalMonthMay { get; set; }
        public decimal? ThisFiscalMonthJun { get; set; }
        public decimal? ThisFiscalMonthJul { get; set; }
        public decimal? ThisFiscalMonthAug { get; set; }
        public decimal? ThisFiscalMonthSep { get; set; }
        public decimal? ThisFiscalMonthOct { get; set; }
        public decimal? ThisFiscalMonthNov { get; set; }
        public decimal? ThisFiscalMonthDec { get; set; }
    }
}

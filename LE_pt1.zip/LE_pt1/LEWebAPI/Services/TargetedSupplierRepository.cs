﻿using LEWebAPI.Entities;
using LEWebAPI.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Services
{
    public class TargetedSupplierRepository : ITargetedSupplierRepository
    {
        LEDbContext _context;
        public TargetedSupplierRepository(LEDbContext context)
        {

            _context = context;
        }

        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }

        public void AddTargetedSupplier(TargetedSupplier result)
        {
            _context.TargetedSuppliers.Add(result);
        }
        public IEnumerable<TargetedSupplier> GetTargetedSuppliers(SupplierResourceParameters supplierResourceParameters)
        {
            return _context.TargetedSuppliers
                .OrderBy(a => a.DepartmentID)
                .ThenBy(a => a.Id)
                .Skip(500 * (supplierResourceParameters.PageNumber - 1)) //supplierResourceParameters.PageSize 
                .Take(500) //supplierResourceParameters.PageSize 
                .ToList();
        }

        public bool SupplierExists(string supplierName)
        {
            //TODO: search gileadwide suppliers as well

            return _context.TargetedSuppliers.Any(t => t.SupplierName == supplierName) ;
        }

        public IEnumerable<TargetedSupplier> GetSuppliersByName(string name)
        {
            return from t in _context.TargetedSuppliers
                   where string.IsNullOrEmpty(name) || t.SupplierName.StartsWith(name)
                   orderby t.SupplierName
                   select t;

        }

           

    }
}

﻿using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAppData _appData;
        private readonly INaturalAccountData _accountData;
        public AccountController(IAppData appData, INaturalAccountData accountData)
        {
            _appData = appData;
            _accountData = accountData;

        }


        [HttpGet()]
        [AcceptVerbs("Get")]
        public IActionResult GetAccounts()
        {
            var currentSupplier = _appData.GetCurrentSupplier();
            var accounts = _accountData.GetAccountsBySupplierName(currentSupplier).ToList();
            
            return new JsonResult(accounts);
        }

        [HttpGet()]
        [AcceptVerbs("Get")]
        public IActionResult GetRentalAccounts()
        {
            var currentSupplier = _appData.GetCurrentSupplier();
            var accounts = _accountData.GetRentAccountsBySupplierName(currentSupplier).ToList();

            return new JsonResult(accounts);
        }
    }
}

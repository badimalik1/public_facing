﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Core
{
   public  class TargetedSupplier
    {
        public int Id { get; set; }
        public int SupplierNumber { get; set; }
        public string SupplierName { get; set; }
        public string SupplierParentName { get; set; }
        public string DepartmentID { get; set; }
        public string SupplierInactiveDate { get; set; }
        public string DepartmentOwner { get; set; }
        public string DepartmentLevel2Name { get; set; }
        public string DepartmentLevel3Name { get; set; }
        public string DepartmentLevel4Name { get; set; }
        public string DepartmentLevel5Name { get; set; }
        public string DepartmentLevel6Name { get; set; }
        public string DepartmentLevel7Name { get; set; }
        public string DepartmentLevel8Name { get; set; }
        public string FPAOwner { get; set; }
        public string EVPOwner { get; set; }
        public string SVPOwner { get; set; }
        public string VPOwner { get; set; }
        public string ExecutiveDirectorOwner { get; set; }
        public string SeniorDirectorOwner { get; set; }
        public string OperatingUnit { get; set; }
        public string OperatingUnitCountry { get; set; }
        public string Location { get; set; }
        public int LegalEntity { get; set; }
        public string LegalEntityName { get; set; }
        public int CostCenter { get; set; }
        public string CostCenterName { get; set; }
        public decimal Spend { get; set; }
        public string Description { get; set; }
        //public string InvoiceCurrency { get; set; }
        // public string Usd_Spend { get; set; }
        // public string Local_Spend { get; set; }
    }
}

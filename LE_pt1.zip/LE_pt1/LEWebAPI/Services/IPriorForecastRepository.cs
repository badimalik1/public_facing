﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LEWebAPI.Entities;
using LEWebAPI.Helpers;

namespace LEWebAPI.Services
{
    public interface IPriorForecastRepository
    {
        IEnumerable<PriorForecast> GetPriorForecasts(SupplierResourceParameters supplierResourceParameters);
        IEnumerable<PriorForecast> GetPriorForecast(SupplierResourceParameters supplierResourceParameters, string departmentNumber);
        IEnumerable<PriorForecast> GetPriorForecastTaxes(SupplierResourceParameters supplierResourceParameters, string departmentNumber);
        IEnumerable<PriorForecast> GetPriorForecastRents(SupplierResourceParameters supplierResourceParameters, string departmentNumber);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Models
{
    public class SupplierDetailsViewModel
    {
        public string NaturalAccountName { get; set; }
        public string PONumber { get; set; }
        public string POLineDescription { get; set; }
        public string LEComents { get; set; }

        /// <summary>
        /// ///////////////////////////////////////////////////
        /// </summary>
        public decimal LastFiscalMonthJan { get; set; }
        public decimal LastFiscalMonthFeb { get; set; }
        public decimal LastFiscalMonthMar { get; set; }
        public decimal LastFiscalMonthApr { get; set; }
        public decimal LastFiscalMonthMay { get; set; }
        public decimal LastFiscalMonthJun { get; set; }
        public decimal LastFiscalMonthJul { get; set; }
        public decimal LastFiscalMonthAug { get; set; }
        public decimal LastFiscalMonthSep { get; set; }
        public decimal LastFiscalMonthOct { get; set; }
        public decimal LastFiscalMonthNov { get; set; }
        public decimal LastFiscalMonthDec { get; set; }

        public decimal LastYearTotal { get; set; }

        /////////////////////////////////////////////////////////////
        ///
        public decimal ThisFiscalMonthJan { get; set; }
        public decimal ThisFiscalMonthFeb { get; set; }
        public decimal ThisFiscalMonthMar { get; set; }
        public decimal ThisFiscalMonthApr { get; set; }
        public decimal ThisFiscalMonthMay { get; set; }
        public decimal ThisFiscalMonthJun { get; set; }
        public decimal ThisFiscalMonthJul { get; set; }
        public decimal ThisFiscalMonthAug { get; set; }
        public decimal ThisFiscalMonthSep { get; set; }
        public decimal ThisFiscalMonthOct { get; set; }
        public decimal ThisFiscalMonthNov { get; set; }
        public decimal ThisFiscalMonthDec { get; set; }
    }
}

﻿using LE.Data;
using LEWebApp.DTOS;
using LE.Core;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;

namespace LEWebApp.Controllers
{
    public class SupplierController : Controller
    {
        IMapper _mapper;
        ITargetedSupplierData _targetedSupplierData;
        public SupplierController(ITargetedSupplierData targetedSupplierData, IMapper mapper)
        {
            _mapper = mapper;
            _targetedSupplierData = targetedSupplierData;
        }

        [HttpPost]
        public RedirectResult Data_Source_Spreadsheet_Submit()
        {
            var testdata = HttpContext.Request.ContentLength;

            //var result = new List<SupplierSubmitViewModel>();
            // return Json(result);

            // return View();
            //return RedirectToPage("Review");
            return Redirect("https://localhost:44308/LE/RentForecast");

        }

       
        [HttpPost()]
        public IActionResult CreateTargetedSupplier([FromBody] TargetedSupplierDTO targetedSupplier)
        {

            if (targetedSupplier == null)
            {
                return BadRequest();
            }

            //if (currentStart.Description == currentStart.Name)
            //{
            //    ModelState.AddModelError("Description", "The provided description should be different from the name");
            //}

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }


            if (_targetedSupplierData.SupplierExists(targetedSupplier.SupplierName))
            {
                return BadRequest();
            }

            var result = _mapper.Map<TargetedSupplierDTO, TargetedSupplier>(targetedSupplier);

            _targetedSupplierData.AddTargetedSupplier(result);
            if (!_targetedSupplierData.Save())
            {
                return StatusCode(500, "Problem creating destination.");
            }

            var createdTargetedSupplier = _mapper.Map<TargetedSupplier, TargetedSupplierDTO>(result);


            return new JsonResult(createdTargetedSupplier);
            //CreatedAtRoute("GetCurrentStarts", new { createdTargetedSupplier.SupplierName }, createdTargetedSupplier)
            //return NoContent();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LEWebAPI.Entities
{
    public enum OperatingUnitTypes
    {
        None, 
        Unknown,
        USOU06,
        NLOU01,
        UKOU03
    }
}

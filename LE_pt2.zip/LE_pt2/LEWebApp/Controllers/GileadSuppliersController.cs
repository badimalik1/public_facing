﻿using LE.Data;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Controllers
{
    public class GileadSuppliersController : Controller
    {
        private readonly LEDbContext _db;
        private readonly IAppData _appData;

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        public GileadSuppliersController(LEDbContext db, IAppData appData)
        {
            _db = db;
            _appData = appData;

        }

        [HttpGet]
        public JsonResult ServerFiltering_GetGileadWideSuppliers(string text)
        {
            var suppliers = _db.GileadWideSuppliers
                 .Where(t => t.OperatingUnitCountry == "US")
                 .OrderBy(a => a.SupplierName)
                .Skip(10 * (0))
                  .Take(80000)
                .ToList();

            var supplierList = suppliers.Select(supplier => new LE.Core.SupplierViewModel { SupplierId = supplier.Id, SupplierName = supplier.SupplierName });

            if (!string.IsNullOrEmpty(text))
            {
                SearchTerm = text.ToUpper();

                try
                {
                    var suppList = supplierList.Where(s => s.SupplierName != null && s.SupplierName.Contains(SearchTerm));
                    return Json(suppList.ToList());

                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

            }

            return Json(supplierList.ToList());
        }
    }
}

﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Interfaces
{
    public interface IPriorForecastData
    {
        Task<IEnumerable<PriorForecast>> GetAll();

        Task<IEnumerable<PriorForecast>> GetSuppliersByName(string name);
        PriorForecast GetById(int id);
        IEnumerable<PriorForecast> GetBySuplierNumber(int supplierNumber);
        PriorForecast Update(PriorForecast updatedPriorForcast);
        PriorForecast Delete(int id);
        int GetCountOfSuppliers();
        int Commit();
    }
}

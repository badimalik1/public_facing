﻿using LEWebApp.Helpers;
using LEWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using LE.Data.Interfaces;

namespace LEWebApp.Controllers
{
    public class AppProxyController : Controller
    {
        private readonly IAppData _appData;
        private readonly ICurrentStartData _currentStartData;
        private EmailHelper _emailHelper;
        private readonly IHostingEnvironment _env;

        public AppProxyController(EmailHelper emailHelper, IHostingEnvironment env,
                                  IAppData appData, ICurrentStartData currentStartData)
        {
            _env = env;
            _appData = appData;
            _emailHelper = emailHelper;
            _currentStartData = currentStartData;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult SendEmail()
        {
            var emailModel = new EmailModel("badi.malik@gmail.com", // To  
                "Email Test", // Subject  
                "Sending Email using Asp.Net Core.", // Message  
                false // IsBodyHTML  
            );
            _emailHelper.SendEmail(emailModel);
            return RedirectToAction("Index");
        }

        public ActionResult SaveFile(string contentType, string base64, string fileName)
        {
            var fileContents = Convert.FromBase64String(base64);
            System.IO.File.WriteAllBytes(_env.ContentRootPath + "\\App_data\\sample.xlsx", fileContents);
            return View("Index");
        }


        [HttpGet()]
        public IEnumerable<int> GetSupplierIds()
        {
            return _appData.GetSuppliersKnown();
        }

        [HttpPost()]
        public IActionResult SetNaturalAccountLineItem(string account)
        {
            _appData.SetNaturalAccountLineItem(account);

            _appData.SetPORequired(isRequired(account));

            return Ok();
        }

        [HttpPost()]
        public void SetSuppliersKnown(string[] supplierId)
        {

            var idList = new List<int>();

            string[] ids = JsonConvert.DeserializeObject<string[]>(supplierId[0]);

            foreach (var id in ids)
            {
                idList.Add(int.Parse(id));
            }


            _appData.SetSuppliersKnown(idList);
        }

        [HttpPost()]
        public void SetSuppliersGileadWide(string[] supplierId)
        {
            var idList = new List<int>();

            string[] ids = JsonConvert.DeserializeObject<string[]>(supplierId[0]);

            foreach (var id in ids)
            {
                idList.Add(int.Parse(id));
            }

            _appData.SetSuppliersGilead(idList);
        }


        [HttpPost()]
        public void SetNewSupplier(string supplierName, string supplierDescription)
        {
            _appData.SetNewSupplier(supplierName, supplierDescription);
        }

        bool isRequired(string account)
        {

            var deptID = _appData.GetCurrentDepartment().Result;
            var supplierName = _appData.GetCurrentSupplier();
            var currStartList = _currentStartData.GetForcastsByName(supplierName, deptID);

            return currStartList.Any(p => p.NaturalAccountName == account);

        }

    }
}

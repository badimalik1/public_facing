﻿
using LEWebAPI.Entities;
using LEWebAPI.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Services
{
    public interface ILERepository
    {
               
        IEnumerable<GileadWideSupplier> GetGileadWideSuppliers(SupplierResourceParameters supplierResourceParameters);
       
    }
}

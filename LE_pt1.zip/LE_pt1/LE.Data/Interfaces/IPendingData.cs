﻿using LE.Core;
using System;
using System.Text;
using System.Collections.Generic;

namespace LE.Data.Interfaces
{
    public interface IPendingData
    {
        bool Commit();
        void Delete(Pending pnd);
        int GetPendingID(string account, string department, string supplier, string poNumber);
        int AddPending(Pending pending);
    }
}

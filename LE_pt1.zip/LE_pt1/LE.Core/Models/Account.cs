﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LE.Core
{
    public class Account
    {
        public int Id { get; set; }
        public string AccountName { get; set; }
        public string AccountGroup { get; set; }
        public int AccountNum { get; set; }

        public string NaturalAccountName { get; set; }
        public string Controllable { get; set; }
        public string Discretionary { get; set; }
        public string ForecastType { get; set; }



    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LEWebApp.Pages.LE
{
    public class RefactorModel : PageModel
    {
        public string SupplierName { get; set; }
        public void OnGet()
        {
            SupplierName = "AEH";
        }
    }
}

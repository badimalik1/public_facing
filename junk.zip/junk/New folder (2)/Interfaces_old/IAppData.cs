﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Interfaces
{
    public interface IAppData
    {
        User GetUser();
        Task SetUser(User user);

        string GetName();
        void SetName(string name);

        string GetSection();
        void SetSection(string section);

        Task<string> GetCurrentDepartment();
        void SetDepartment(string department);

        Task<IEnumerable<int>> GetSupplierIds();

        User GetUser(string username, string password);
        ICollection<DepartmentString> GetDepartments(int userId);

        Task<object> SetApplicationData(string route, object postObj);

    }
}

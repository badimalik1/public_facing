﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Entities
{
    public class ExportTableViewModel
    {
        public string AccountGroup { get; set; }
        public string DepartmentNameNum { get; set; }
        public decimal ThisFiscalMonthJan { get; set; }
        public decimal ThisFiscalMonthFeb { get; set; }
        public decimal ThisFiscalMonthMar { get; set; }
        public decimal ThisFiscalMonthApr { get; set; }
        public decimal ThisFiscalMonthMay { get; set; }
        public decimal ThisFiscalMonthJun { get; set; }
        public decimal ThisFiscalMonthJul { get; set; }
        public decimal ThisFiscalMonthAug { get; set; }
        public decimal ThisFiscalMonthSep { get; set; }
        public decimal ThisFiscalMonthOct { get; set; }
        public decimal ThisFiscalMonthNov { get; set; }
        public decimal ThisFiscalMonthDec { get; set; }

        public decimal NextFiscalMonthJan { get; set; }
        public decimal NextFiscalMonthFeb { get; set; }
        public decimal NextFiscalMonthMar { get; set; }
        public decimal NextFiscalMonthApr { get; set; }
        public decimal NextFiscalMonthMay { get; set; }
        public decimal NextFiscalMonthJun { get; set; }
        public decimal NextFiscalMonthJul { get; set; }
        public decimal NextFiscalMonthAug { get; set; }
        public decimal NextFiscalMonthSep { get; set; }
        public decimal NextFiscalMonthOct { get; set; }
        public decimal NextFiscalMonthNov { get; set; }
        public decimal NextFiscalMonthDec { get; set; }

        public decimal YANFiscalMonthJan { get; set; }
        public decimal YANFiscalMonthFeb { get; set; }
        public decimal YANFiscalMonthMar { get; set; }
        public decimal YANFiscalMonthApr { get; set; }
        public decimal YANFiscalMonthMay { get; set; }
        public decimal YANFiscalMonthJun { get; set; }
        public decimal YANFiscalMonthJul { get; set; }
        public decimal YANFiscalMonthAug { get; set; }
        public decimal YANFiscalMonthSep { get; set; }
        public decimal YANFiscalMonthOct { get; set; }
        public decimal YANFiscalMonthNov { get; set; }
        public decimal YANFiscalMonthDec { get; set; }

        public decimal YANYFiscalMonthJan { get; set; }
        public decimal YANYFiscalMonthFeb { get; set; }
        public decimal YANYFiscalMonthMar { get; set; }
        public decimal YANYFiscalMonthApr { get; set; }
        public decimal YANYFiscalMonthMay { get; set; }
        public decimal YANYFiscalMonthJun { get; set; }
        public decimal YANYFiscalMonthJul { get; set; }
        public decimal YANYFiscalMonthAug { get; set; }
        public decimal YANYFiscalMonthSep { get; set; }
        public decimal YANYFiscalMonthOct { get; set; }
        public decimal YANYFiscalMonthNov { get; set; }
        public decimal YANYFiscalMonthDec { get; set; }
    }
}

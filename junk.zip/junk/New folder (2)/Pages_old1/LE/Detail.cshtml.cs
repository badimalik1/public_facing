﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LE.Core;
using LE.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LEWebApp.Pages.LE
{
    public class DetailModel : PageModel
    {
        private readonly ITargetedSupplierData _supplierData;
        public TargetedSupplier Supplier { get; set; }
        public IEnumerable<TargetedSupplier> Suppliers { get; set; }

        public DetailModel(ITargetedSupplierData supplierData)
        {
            _supplierData = supplierData;
        }
        public void OnGet(int supplierNumber)
        {
           
            Suppliers = _supplierData.GetBySuplierNumber(supplierNumber);
            Task.Run(
                    async () =>
                    {
                        Supplier = await _supplierData.GetById(Suppliers.FirstOrDefault().Id);
                    });

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using LE.Core;
using LE.Data;
using Newtonsoft.Json;
using LE.Data.Interfaces;

namespace LEWebApp.Pages.LE
{
    public class CreateModel : PageModel
    {
        private ITargetedSupplierData _targetedSupplier;
        private readonly IAppData _appData;

        public IEnumerable<TargetedSupplier> Suppliers;

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }
        public IEnumerable<TargetedSupplier> TargetedSuppliers { get; set; }

        public CreateModel(ITargetedSupplierData targetedSupplierData, IAppData appData)
        {
            //_context = context;
            _appData = appData;
            _targetedSupplier = targetedSupplierData;
        }

        public async Task OnGetAsync(string searchTerm)
        {
            //Suppliers = await _targetedSupplier.GetAll();

            TargetedSuppliers = await _targetedSupplier.GetSuppliersByName(SearchTerm);
            //return Page();
        }

        [BindProperty]
        public TargetedSupplier TargetedSupplier { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            TargetedSupplier.SpendLC = 0;
            TargetedSupplier.SpendUSD = 0;
            TargetedSupplier.DepartmentID = await _appData.GetCurrentDepartment();

            var newSupplier = _targetedSupplier.AddSupplier(TargetedSupplier);
            //var json = JsonConvert.SerializeObject(newSupplier);

            //await _appData.SetApplicationData("api/app/SetAddedSuppliers?supplierId=" + newSupplier.Id.ToString(), newSupplier.Id);
            List<int> supplierList = new List<int>();
            supplierList.Add(newSupplier.Id);

            _appData.SetSuppliersKnown(supplierList);
            return RedirectToPage("./SupplierForecast");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LEWebAPI.Models;

using AutoMapper;

namespace LEWebAPI.MappingProfiles
{
    public class EntityToDTOProfile : Profile
    {
        public EntityToDTOProfile()
        {
            CreateMap<Entities.CurrentStart, CurrentStartDTO>();
            CreateMap<CurrentStartDTO, Entities.CurrentStart>();

            CreateMap<Entities.CurrentStart, DTOs.CurrentStartDTO>();
            CreateMap<DTOs.CurrentStartDTO, Entities.CurrentStart>();

            CreateMap<Models.CurrentStartDTO, DTOs.CurrentStartDTO>();
            CreateMap<DTOs.CurrentStartDTO, Models.CurrentStartDTO>();

            CreateMap<Entities.CurrentStart, DTOs.CurrentStartDTO>();
            CreateMap<DTOs.CurrentStartDTO, Entities.CurrentStart>();

            //**********************************************************

            CreateMap<Entities.TargetedSupplier, TargetedSupplierDTO>();
            CreateMap<TargetedSupplierDTO, Entities.TargetedSupplier>();

            CreateMap<Entities.TargetedSupplier, DTOs.TargetedSupplierDTO>();
            CreateMap<DTOs.TargetedSupplierDTO, Entities.TargetedSupplier>();

            CreateMap<Models.TargetedSupplierDTO, DTOs.TargetedSupplierDTO>();
            CreateMap<DTOs.TargetedSupplierDTO, Models.TargetedSupplierDTO>();

            CreateMap<Entities.TargetedSupplier, DTOs.TargetedSupplierDTO>();
            CreateMap<DTOs.TargetedSupplierDTO, Entities.TargetedSupplier>();

            //**********************************************************

        }
    }
}

﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Data.Interfaces
{
    public interface IReviewData
    {
        IEnumerable<CurrentStart> ReadRentForecast(string dept);
    }
}

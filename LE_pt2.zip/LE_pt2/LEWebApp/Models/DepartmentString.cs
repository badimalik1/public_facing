﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LEWebApp.Models
{
    public class DepartmentString
    {
        
        public int Id { get; set; }
        public string DepartmentNameNum { get; set; }
   
        public int UserId { get; set; }

        public User User { get; set; }
    }

}

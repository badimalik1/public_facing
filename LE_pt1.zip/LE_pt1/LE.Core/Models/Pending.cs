﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LE.Core
{
    public class Pending
    {
        public int Id { get; set; }
        public int CSID { get; set; }
        public string PONumber { get; set; }
        public string Department { get; set; }
        public string SupplierName { get; set; }
        public string NaturalAccountName { get; set; }


    }
}

﻿using LE.Core;
using LE.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//TODO: add PO data
namespace LE.Data.Implementations
{
    public class NaturalAccountData : BaseDataImpl, INaturalAccountData
    {
        protected readonly LEDbContext _db;

        public NaturalAccountData(LEDbContext db)
        {
            _db = db;
        }

        public IEnumerable<Account> GetAccountsBySupplierName(string supplierName)
        {
            var accounts = _db.Accounts
                .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits" && a.AccountGroup != "AC_67000-Grants & Medical Education")
                .Where(a => a.AccountGroup != "AC_63000-Training & Education" && a.AccountGroup != "AC_68000-Promotional Programs")
                .Where(a => a.AccountGroup != "AC_66000-Insurance" && a.AccountGroup != "AC_72000-Depreciation & Amortization")
                .Where(a => a.AccountGroup != "AC_73000-Other General Expense")
                .Where(n => n.NaturalAccountName != "Airfare" && n.NaturalAccountName != "Meals & Entertainment 1"
                    && n.NaturalAccountName != "Meals & Entertainment 2" && n.NaturalAccountName != "Meals & Entertainment 3"
                    && n.NaturalAccountName != "Other Travel & Lodging 1" && n.NaturalAccountName != "Other Travel & Lodging 2"
                    && n.NaturalAccountName != "Employee Relations 1" && n.NaturalAccountName != "Business Gifts"
                    && n.NaturalAccountName != "Building Lease Expense - Short-Term Lease" && n.NaturalAccountName != "Lease Expense - Variable Lease Cost for Equipment"
                    && n.NaturalAccountName != "Lease Expense - Immaterial Lease" && n.NaturalAccountName != "Property & Local Taxes"
                    && n.NaturalAccountName != "Operating Lease Expense - Interest Component" && n.NaturalAccountName != "Operating Lease Expense Amortization Component")
                .OrderBy(n => n.NaturalAccountName);

            return accounts;

        }

        public IEnumerable<Account> GetRentAccountsBySupplierName(string supplierName)
        {
            var accounts = _db.Accounts
                .Where(a => a.AccountGroup != "AC_61000-Compensation & Benefits" && a.AccountGroup != "AC_67000-Grants & Medical Education")
                .Where(a => a.AccountGroup != "AC_63000-Training & Education" && a.AccountGroup != "AC_68000-Promotional Programs")
                .Where(a => a.AccountGroup != "AC_66000-Insurance" && a.AccountGroup != "AC_72000-Depreciation & Amortization")
                .Where(a => a.AccountGroup != "AC_73000-Other General Expense")
                .Where(n => n.NaturalAccountName == "Building Lease Expense - Short-Term Lease" 
                    || n.NaturalAccountName == "Lease Expense - Immaterial Lease" 
                    || n.NaturalAccountName == "Operating Lease Expense - Interest Component" 
                    || n.NaturalAccountName == "Operating Lease Expense Amortization Component")
                .OrderBy(n => n.NaturalAccountName);

            return accounts;

        }
    }
}

﻿using LE.Core;
using LE.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LE.Data.Implementations
{
    public class RentData : IRentData
    {
        private readonly LEDbContext _db;

        public RentData(LEDbContext db)
        {
            _db = db;
        }

        public bool Save()
        {
            return (_db.SaveChanges() >= 0);
        }
        public void AddCurrentStart(CurrentStart result)
        {
            _db.CurrentStarts.Add(result);
        }

        public CurrentStart GetCurrentStart(int id)
        {
            return _db.CurrentStarts
                            .Where(a => a.Id == id).FirstOrDefault();
        }
        public IEnumerable<CurrentStart> ReadRentForecast(string dept)
        {
            var rents = _db.CurrentStarts
                .Where(a => a.DepartmentNameNum == dept)
                .Where(n => n.NaturalAccountName == "Building Lease Expense - Short-Term Lease" || n.NaturalAccountName.Contains("Short-Term Lease") || n.NaturalAccountName.Contains("Lease Expense") &&
                            n.NaturalAccountName == "Variable Lease Cost for Building" || n.NaturalAccountName == "Lease Expense" || n.NaturalAccountName == "Immaterial Lease" &&
                            n.NaturalAccountName.Contains("Operating Lease Expense") || n.POLineDescription.Contains("Lease") || n.NaturalAccountName.Contains("Lease"))
                .Where(r => r.AccountNumber != 70205)
                .Where(s => s.SupplierName != "#NA" && s.SupplierName != "NULL" && s.SupplierName != null)
                .Where(t => !t.POLineDescription.Contains("Tax") && !t.AccountGroup.Contains("Tax"))
                .OrderBy(a => a.SupplierName)
                .Skip(10000 * (0))
                .Take(10000)
                .ToList();

            return rents;
        }

        public IEnumerable<CurrentStart> GetByFiscalPeriod(string fiscalPeriod, int accountNum, string poLineDescription, string supplierName)
        {
            
            var cs = _db.CurrentStarts
                      .Where(f => f.FiscalPeriod == fiscalPeriod)
                      .Where(a=> a.AccountNumber == accountNum)
                      .Where(p => p.POLineDescription == poLineDescription)
                      .Where(n => n.SupplierName == supplierName).ToList();
            
            if (cs != null && cs.Count() == 0)
                return null;

            return cs;

        }

        public IEnumerable<PriorForecast> ReadPriorForecastRents(string dept)
        {
            var priorForcasts = _db.PriorForecasts
                .Where(a => a.DepartmentNameNum == dept)
                .Where(n => n.NaturalAccountName == "Building Lease Expense" || n.NaturalAccountName.Contains("Short-Term Lease") || n.NaturalAccountName.Contains("Lease Expense") &&
                            n.NaturalAccountName == "Variable Lease Cost for Building" || n.NaturalAccountName == "Lease Expense" || n.NaturalAccountName == "Immaterial Lease" &&
                            n.NaturalAccountName.Contains("Operating Lease Expense") || n.POLineDescription.Contains("Lease") || n.NaturalAccountName.Contains("Lease"))
                .Where(r => r.AccountNumber != 70205)
                .Where(s => s.SupplierName != "#NA" && s.SupplierName != "Null" && s.SupplierName != null)
                .Where(t => !t.POLineDescription.Contains("Tax") && !t.AccountGroup.Contains("Tax"))
                .OrderBy(a => a.SupplierName)
                .Skip(5000 * (0))
                .Take(5000)
                .ToList();

            return priorForcasts;
        }
    }
}

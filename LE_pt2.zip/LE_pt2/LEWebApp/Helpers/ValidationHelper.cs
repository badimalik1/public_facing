﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Helpers
{
    public class ValidationHelper : ValidationAttribute
    {
        public string PropertyName { get; set; }
        public object Value { get; set; }
        public string GetErrorMessage() => $"PO Number is Required.";

        public ValidationHelper(string propertyName, object value, string errorMessage = "")
        {
            PropertyName = propertyName;
            ErrorMessage = errorMessage;
            Value = value;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var instance = validationContext.ObjectInstance;
            var type = instance.GetType();
            try {
                    var proprtyvalue = type.GetProperty(PropertyName).GetValue(instance, null);

                    if (proprtyvalue.ToString() == Value.ToString() && value == null)
                    {
                        return new ValidationResult(GetErrorMessage());
                    }
                    return ValidationResult.Success;


            }
            catch(Exception ex) 
            {
                Debug.WriteLine("Validation Exception: "+ ex.Message);
            }
            return ValidationResult.Success;
        }

    }
}
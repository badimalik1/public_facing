﻿using LEWebAPI.Entities;
using LEWebAPI.Services;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Controllers
{
    [EnableCors("_myAllowSpecificOrigins")]
    [Route("api/app")]
    public class ApplicationDataController : Controller
    {
        private IApplicationDataRepository _appDataRepository;

        public ApplicationDataController(IApplicationDataRepository appDataRepository)
        {
            _appDataRepository = appDataRepository;
        }

        public User GetUser()
        {
            return _appDataRepository.GetUser();
        }
        [Route("SetUser")]
        public void SetUser(User user)
        {

            _appDataRepository.SetUser(user);
        }

        [Route("GetCurrentDepartment")]
        public string GetCurrentDepartment()
        {
            return _appDataRepository.GetCurrentDepartment();
        }

        [Route("SetCurrentDepartment")]
        public void SetDepartment(string department)
        {
            _appDataRepository.SetDepartment(department);
        }

        [Route("GetSupplierIds")]
        public IEnumerable<int> GetSupplierIds()
        {
            return _appDataRepository.GetSuppliersKnown();
        }

        [HttpPost("{supplierId}")]
        [Route("SetAddedSuppliers")]
        public void SetSuppliersKnown(string[] supplierId)
        {
            //var formData = Request.Form["supplierId"];
            var idList = new List<int>();
            if (supplierId.Length == 1)
            {
                idList.Add(int.Parse(supplierId[0]));
            }
            else
            {
                string[] ids = JsonConvert.DeserializeObject<string[]>(supplierId[0]);
            
                foreach(var id in ids )
                {
                    idList.Add(int.Parse(id));
                }
            }

            _appDataRepository.SetSuppliersKnown(idList);
        }


        [Route("SetNewSupplier")]
        public void SetNewSupplier(string supplierName, string supplierDescription)
        {
            _appDataRepository.SetNewSupplier(supplierName, supplierDescription);
        }

        public string GetName()
        {
            return _appDataRepository.GetName();
        }

        public void SetName(string name)
        {
            _appDataRepository.SetName(name);
        }

        public string GetSection()
        {
            return _appDataRepository.GetSection();
        }

        public void SetSection(string section)
        {
            _appDataRepository.SetSection(section);
        }

    }
}

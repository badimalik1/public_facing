﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebApp.Helpers
{
    public static class DateHelpers
    {

        public static int GetQuarter(this DateTime date)
        {
            if (date.Month >= 4 && date.Month <= 6)
                return 2;
            else if (date.Month >= 7 && date.Month <= 9)
                return 3;
            else if (date.Month >= 10 && date.Month <= 12)
                return 4;
            else
                return 1;
        }

        public static string GetFiscalQuarter()
        {
            DateTime now = DateTime.Today;

            return "Q" + now.GetQuarter().ToString() + "-" + now.ToString("yy");

        }

        public static string GetFiscalPeriod()
        {
            DateTime now = DateTime.Today;

            return now.ToString("MMM") + "-" + now.ToString("yy");

        }

        public static string FromExcelSerialDate(int SerialDate)
        {
            return DateTime.FromOADate(SerialDate).ToString();
        }

        public static string ConvertFiscalPeriod(int month, string year)
        {
            string fiscaPeriod = null;

            switch (month)
            {
                case 1:
                    fiscaPeriod = "Jan-" + year;
                    break;
                case 2:
                    fiscaPeriod = "Feb-" + year;
                    break;
                case 3:
                    fiscaPeriod = "Mar-" + year;
                    break;
                case 4:
                    fiscaPeriod = "Apr-" + year;
                    break;
                case 5:
                    fiscaPeriod = "May-" + year;
                    break;
                case 6:
                    fiscaPeriod = "Jun-" + year;
                    break;
                case 7:
                    fiscaPeriod = "Jul-" + year;
                    break;
                case 8:
                    fiscaPeriod = "Aug-" + year;
                    break;
                case 9:
                    fiscaPeriod = "Sep-" + year;
                    break;
                case 10:
                    fiscaPeriod = "Oct-" + year;
                    break;
                case 11:
                    fiscaPeriod = "Nov-" + year;
                    break;
                case 12:
                    fiscaPeriod = "Dec-" + year;
                    break;
                default: break;
            }

            return fiscaPeriod;

        }
    }
}

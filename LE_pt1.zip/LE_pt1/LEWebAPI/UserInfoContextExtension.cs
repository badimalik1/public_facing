﻿
using LEWebAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LEWebAPI
{
    public static class UserInfoContextExtension
    {
        public static void EnsureSeedDataForContext(this LEDbContext context)
        {
            if (context.Users.Any())
            {
                return;
            }


            var users = new List<User>()
            {
                new User()
                {
                   Email = "badi.malik1@gilead.com",
                   FirstName = "Badi",
                   LastName = "Malik",
                   Password = "helloworld",
                   Departments = new List<string>()
                   {
                        "Facilities Admin (DP_0016301001)",
                        "FC-FAC Site Wide Costs (DP_0016398001)",
                        "Foster City Corporate Security (DP_0016306001)"
                   }

                },
                new User()
                {
                   Email = "stephani.slater@gilead.com",
                   FirstName = "Stephani",
                   LastName = "Slater",
                   Password = "password",
                   Departments = new List<string>()
                   {
                       "Procurement US Remote (DP_0016505004)",
                       "FC Facilities Operations (DP_0016307001)",
                       "Seattle Side Wide Costs (DP_0016398004)"
                   }
                },
                new User()
                {
                   Email = "jennifer.hedborn1@gilead.com",
                   FirstName = "Jennifer",
                   LastName = "Hedborn",
                   Password = "password",
                   Departments = new List<string>()
                   {
                        "Italy Facilities (DP_2036304001)",
                        "Facilities Pudong (DP_4196304001)",
                        "Austria Facilities (DP_2136304001)"

                   }
                },
                new User()
                {
                   Email = "Lucerne.Tsang@gilead.com",
                   FirstName = "Lucerne",
                   LastName = "Tsang",
                   Password = "password",
                   Departments = new List<string>()
                   {
                        "Foster City Fac & Maintenance (DP_0016304001)",
                        "Remote Fac & Maintenance (DP_0016304012)",
                        "Operations Admin (DP_0016350001)"
                   }
                },
                new User()
                {
                   Email = "Jon.Bessette@gilead.com",
                   FirstName = "Jon",
                   LastName = "Bessette",
                   Password = "password",
                   Departments = new List<string>()
                   {
                       "FC H&S - Research (DP_0016314001)",
                       "Brazil Facilities (DP_5016304001)",
                       "FC-FAC Site Wide Costs (DP_0016398001)"
                   }
                },
            };

            context.Users.AddRange(users);
            context.SaveChanges();
        }




    }
}

﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Interfaces
{
    public interface ICurrentStartData
    {
        int Commit();
        int GetCountOfForcasts();
        CurrentStart Delete(int id);
        CurrentStart GetById(int id);
        Task<IEnumerable<CurrentStart>> GetAll();
        CurrentStart Update(CurrentStart updatedForcast);
        CurrentStart AddForecast(CurrentStart newForcast);
        Task<IEnumerable<CurrentStart>> GetByDepartment(string dept);
        Task<IEnumerable<CurrentStart>> GetForcastsByName(string name, string dept);
        Task<IEnumerable<CurrentStart>> GetCurrentStartByIdAPI(string deptId);

        IEnumerable<CurrentStart> ReadSupplierForecast(string dept);
    }
}

﻿using LE.Core;
using LE.Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;


namespace LEWebApp.Controllers
{
    public class RentController : Controller
    {
        public User UserData { get; set; }
        private readonly IAppData _appData;
        private readonly IPreferencesData _prefsData;
        public string CurrentDepartment { get; set; }
        private readonly IRentData _rentData;
        private readonly ICurrentStartData _currentStartData;

        public ICollection<DepartmentString> Departments { get; set; }

        public IEnumerable<CurrentStart> CurrentStarts { get; set; }

        public RentController(ICurrentStartData currentStarData, IRentData rentData,
                              IAppData appData, IPreferencesData prefsData)
        {

            _appData = appData;
            _rentData = rentData;
            _prefsData = prefsData;
            _currentStartData = currentStarData;
            UserData = _appData.GetUser();

        }
        [HttpPost]
        public RedirectResult Data_Source_Spreadsheet_Submit(SupplierSubmitViewModel submitViewModel)
        {
            var testdata = HttpContext.Request.ContentLength;

            //var result = new List<SupplierSubmitViewModel>();
            // return Json(result);

            // return View();
            //return RedirectToPage("Review");
            return Redirect("https://localhost:44308/LE/Tax");

        }

        [HttpGet()]
        public IActionResult GetRentCurrentStarts(string departmentId)
        {
            Task.Run(async () =>
            {
                CurrentDepartment = await _appData.GetCurrentDepartment();
            });

            Departments = new Collection<DepartmentString>();
            foreach (var dp in UserData.Departments)
            {
                Departments.Add(dp);
            }
            var dept = CurrentDepartment = CurrentDepartment != null ? CurrentDepartment : departmentId;

            var currentStarts = _rentData.ReadRentForecast(dept);

            var priorFcsts = _rentData.ReadPriorForecastRents(dept);

            var startYear = int.Parse(_prefsData.GetStartYear());

            var lastYear = (startYear - 1);
            var thisYear = (startYear);
            var nextYear = (startYear + 1);
            var yearAfterNext = (startYear + 2);

            var tmp = currentStarts.Where(d => d.DepartmentNameNum == departmentId && d.NaturalAccountName == "Building Lease Expense - Short-Term Lease");
            foreach (var cs in tmp)
            {
                Debug.WriteLine("id: " + cs.Id + " : acct: " + cs.NaturalAccountName);
            }
            var supplierList = currentStarts.Select(supplier => new RentsViewModel
            {
                SupplierId = supplier.Id,
                SupplierName = supplier.SupplierName,
                POLineDescription = supplier.POLineDescription,
                LEComments = supplier.Comments,
                Scenario = supplier.Scenario,
                VarianceComments = supplier.VarianceComments,
                NaturalAccountNumber = "AC_" + supplier.AccountNumber.ToString(),
                NaturalAccountName = supplier.NaturalAccountName,

                ///////////////////////last year///////////////////////////////////////
                LastFiscalYear = supplier.FiscalYear,
                LastFiscalQuarter = supplier.FiscalQuarter,
                LastFiscalPeriod = supplier.FiscalPeriod,
                LastFiscalDate = supplier.FiscalDate,
                LastPriorFcst = priorFcsts.Where(p => p.FiscalYear == lastYear.ToString() && p.ProjectTaskNumber == supplier.ProjectTaskNumber).Select(g => g.TotalLC).FirstOrDefault(),
                LastFiscalMonthJan = (supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthFeb = (supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMar = (supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthApr = (supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthMay = (supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJun = (supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthJul = (supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthAug = (supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthSep = (supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthOct = (supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthNov = (supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                LastFiscalMonthDec = (supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == lastYear.ToString()) ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ///////////////////////this year/////////////////////////////////////////////
                ThisFiscalYear = supplier.FiscalYear,
                ThisFiscalQuarter = supplier.FiscalQuarter,
                ThisFiscalPeriod = supplier.FiscalPeriod,
                ThisFiscalDate = supplier.FiscalDate,
                ThisPriorFcst = priorFcsts.Where(p => p.FiscalYear == thisYear.ToString() && p.ProjectTaskNumber == supplier.ProjectTaskNumber).Select(g => g.TotalLC).FirstOrDefault(),
                ThisFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                /////////////////////////////////////next year///////////////////////////////////////////
                NextFiscalYear = supplier.FiscalYear,
                NextFiscalQuarter = supplier.FiscalQuarter,
                NextFiscalPeriod = supplier.FiscalPeriod,
                NextFiscalDate = supplier.FiscalDate,
                NextPriorFcst = priorFcsts.Where(p => p.FiscalYear == nextYear.ToString() && p.ProjectTaskNumber == supplier.ProjectTaskNumber).Select(g => g.TotalLC).FirstOrDefault(),
                NextFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                //////////////////////////////////YAN////////////////////////////////////////////////////////////////////
                YANFiscalYear = supplier.FiscalYear,
                YANFiscalQuarter = supplier.FiscalQuarter,
                YANFiscalPeriod = supplier.FiscalPeriod,
                YANFiscalDate = supplier.FiscalDate,
                YANPriorFcst = priorFcsts.Where(p => p.FiscalYear == yearAfterNext.ToString() && p.ProjectTaskNumber == supplier.ProjectTaskNumber).Select(g => g.TotalLC).FirstOrDefault(),
                YANFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0

            })
            .GroupBy(s => new { s.SupplierName, s.POLineDescription })
            .Select(g =>
                new RentsViewModel
                {
                    SupplierId = g.Select(s => s.SupplierId).FirstOrDefault(),
                    NaturalAccountNumber = g.Select(l => l.NaturalAccountNumber.ToString()).FirstOrDefault(),
                    NaturalAccountName = g.Select(l => l.NaturalAccountName).FirstOrDefault(),
                    SupplierName = g.Key.SupplierName,
                    POLineDescription = g.Key.POLineDescription,
                    LEComments = g.Select(l => l.LEComments).FirstOrDefault(),
                    //LastFiscalYear = g.Key.LastFiscalYear,
                    //LastFiscalQuarter = g.FiscalQuarter,
                    //LastFiscalPeriod = g.FiscalPeriod,
                    //LastFiscalDate = g.FiscalDate,
                    LastPriorFcst = g.Select(l => l.LastPriorFcst).FirstOrDefault(),
                    ThisPriorFcst = g.Select(l => l.ThisPriorFcst).FirstOrDefault(),
                    NextPriorFcst = g.Select(l => l.NextPriorFcst).FirstOrDefault(),
                    YANPriorFcst = g.Select(l => l.YANPriorFcst).FirstOrDefault(),

                    LastFiscalMonthJan = g.Sum(b => b.LastFiscalMonthJan),
                    LastFiscalMonthFeb = g.Sum(b => b.LastFiscalMonthFeb),
                    LastFiscalMonthMar = g.Sum(b => b.LastFiscalMonthMar),
                    LastFiscalMonthApr = g.Sum(b => b.LastFiscalMonthApr),
                    LastFiscalMonthMay = g.Sum(b => b.LastFiscalMonthMay),
                    LastFiscalMonthJun = g.Sum(b => b.LastFiscalMonthJun),
                    LastFiscalMonthJul = g.Sum(b => b.LastFiscalMonthJul),
                    LastFiscalMonthAug = g.Sum(b => b.LastFiscalMonthAug),
                    LastFiscalMonthSep = g.Sum(b => b.LastFiscalMonthSep),
                    LastFiscalMonthOct = g.Sum(b => b.LastFiscalMonthOct),
                    LastFiscalMonthNov = g.Sum(b => b.LastFiscalMonthNov),
                    LastFiscalMonthDec = g.Sum(b => b.LastFiscalMonthDec),
                    ////////////////////////////////////////////////////////////////////////////////////

                    ThisFiscalMonthJan = g.Sum(b => b.ThisFiscalMonthJan),
                    ThisFiscalMonthFeb = g.Sum(b => b.ThisFiscalMonthFeb),
                    ThisFiscalMonthMar = g.Sum(b => b.ThisFiscalMonthMar),
                    ThisFiscalMonthApr = g.Sum(b => b.ThisFiscalMonthApr),
                    ThisFiscalMonthMay = g.Sum(b => b.ThisFiscalMonthMay),
                    ThisFiscalMonthJun = g.Sum(b => b.ThisFiscalMonthJun),
                    ThisFiscalMonthJul = g.Sum(b => b.ThisFiscalMonthJul),
                    ThisFiscalMonthAug = g.Sum(b => b.ThisFiscalMonthAug),
                    ThisFiscalMonthSep = g.Sum(b => b.ThisFiscalMonthSep),
                    ThisFiscalMonthOct = g.Sum(b => b.ThisFiscalMonthOct),
                    ThisFiscalMonthNov = g.Sum(b => b.ThisFiscalMonthNov),
                    ThisFiscalMonthDec = g.Sum(b => b.ThisFiscalMonthDec),

                    /////////////////////////////////////////////////////////////////////////////////////

                    NextFiscalMonthJan = g.Sum(b => b.NextFiscalMonthJan),
                    NextFiscalMonthFeb = g.Sum(b => b.NextFiscalMonthFeb),
                    NextFiscalMonthMar = g.Sum(b => b.NextFiscalMonthMar),
                    NextFiscalMonthApr = g.Sum(b => b.NextFiscalMonthApr),
                    NextFiscalMonthMay = g.Sum(b => b.NextFiscalMonthMay),
                    NextFiscalMonthJun = g.Sum(b => b.NextFiscalMonthJun),
                    NextFiscalMonthJul = g.Sum(b => b.NextFiscalMonthJul),
                    NextFiscalMonthAug = g.Sum(b => b.NextFiscalMonthAug),
                    NextFiscalMonthSep = g.Sum(b => b.NextFiscalMonthSep),
                    NextFiscalMonthOct = g.Sum(b => b.NextFiscalMonthOct),
                    NextFiscalMonthNov = g.Sum(b => b.NextFiscalMonthNov),
                    NextFiscalMonthDec = g.Sum(b => b.NextFiscalMonthDec),

                    /////////////////////////////////////////////////////////////////////////////////////////////////////
                    ///

                    YANFiscalMonthJan = g.Sum(b => b.YANFiscalMonthJan),
                    YANFiscalMonthFeb = g.Sum(b => b.YANFiscalMonthFeb),
                    YANFiscalMonthMar = g.Sum(b => b.YANFiscalMonthMar),
                    YANFiscalMonthApr = g.Sum(b => b.YANFiscalMonthApr),
                    YANFiscalMonthMay = g.Sum(b => b.YANFiscalMonthMay),
                    YANFiscalMonthJun = g.Sum(b => b.YANFiscalMonthJun),
                    YANFiscalMonthJul = g.Sum(b => b.YANFiscalMonthJul),
                    YANFiscalMonthAug = g.Sum(b => b.YANFiscalMonthAug),
                    YANFiscalMonthSep = g.Sum(b => b.YANFiscalMonthSep),
                    YANFiscalMonthOct = g.Sum(b => b.YANFiscalMonthOct),
                    YANFiscalMonthNov = g.Sum(b => b.YANFiscalMonthNov),
                    YANFiscalMonthDec = g.Sum(b => b.YANFiscalMonthDec),


                }
            );


            // var highestBy = currentStarts
            //     .GroupBy(s => s.SupplierName)
            //     .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
            //     .ToList();

            //TODO: get priorforecast and cache it
            //var groupList = supplierList
            //    .GroupBy(s => s.SupplierName)
            //    .ToList();


            //var groupList =
            //    from supplier in supplierList
            //    group supplier by supplier.SupplierName into newGroup
            //    orderby newGroup.Key
            //    select newGroup;

            return new JsonResult(supplierList);
        }

        private IActionResult SaveData()
        {
            if (!_rentData.Save())
            {
                return StatusCode(500, "Problem creating Current Start Record.");
            }

            return Ok();
        }

        /* private IActionResult UpdateRentCurrentStartInternal(int id, JsonPatchDocument<CurrentStartDTO> currentStartDoc)
         {
             if (currentStartDoc == null)
             {
                 return BadRequest("No Current Start to Update!");
             }

             if (!_rentData.CurrentStartExists(id)) // change to id
             {
                 return NotFound();
             }
             var currentStartFromRepo = _rentData.GetCurrentStart(id);
             if (currentStartFromRepo == null)
             {
                 return NotFound();
             }

             var currentStartToPatch = _mapper.Map<Entities.CurrentStart, DTOs.CurrentStartDTO>(currentStartFromRepo);

             //Add mapping
             currentStartDoc.ApplyTo(currentStartToPatch);

             _mapper.Map(currentStartToPatch, currentStartFromRepo);

             _rentData.UpdateCurrentStart(currentStartFromRepo);

             if (!_rentData.Save())
             {
                 return StatusCode(500, "Problem updating Current Start Record.");
             }

             return NoContent();
         }*/


        [HttpPost()]
        public IActionResult CreateRentSupplier(string[] currentStart)
        {
            //TODO:long winded - optimize later
            var startYear = int.Parse(_prefsData.GetStartYear());

            //var lastYear = (startYear - 1);
            var thisYear = (startYear-1);
            var nextYear = (startYear );
           // var yearAfterNext = (startYear + 2);

            if (currentStart == null)
            {
                return BadRequest();
            }

            try
            {
                var supplierData = JsonConvert.DeserializeObject<RentsViewModel[]>(currentStart[0]);

                var supplierDataList = supplierData.ToList();

                CurrentStart currStartAdd = null;
                var fiscalDate = Convert.ToInt32(DateTime.Now.ToOADate());
                
                foreach (var item in supplierDataList)
                {
                    var currStart = _rentData.GetCurrentStart(item.SupplierId);

                    currStartAdd = GetNewCurrentStart(currStart);
                    currStartAdd.SupplierName = item.SupplierName;
                    //TODO:check exists before saving

                    if (item.ThisFiscalMonthJan == null)
                        item.ThisFiscalMonthJan = 0;

                    var fiscalPeriod = "Jan-" + thisYear.ToString().Substring(2, 2);
                    var year = thisYear;
                    var budget = item.ThisFiscalMonthJan.GetValueOrDefault(0);
                    var quarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                    var accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    var cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthJan != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthJan;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthJan;
                            currStartAdd.FiscalPeriod = "Jan-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthJan != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthJan != csItem.BudgetLC || item.ThisFiscalMonthJan != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthJan != csItem.TotalLC || item.ThisFiscalMonthJan != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthJan;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJan;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthJan;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthJan;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;
                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthJan;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthJan;
                                        currStartAdd.FiscalPeriod = "Jan-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                       
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if(csItem.POLineDescription == item.POLineDescription &&
                                    csItem.SupplierName == item.SupplierName )
                                {
                                    if (item.ThisFiscalMonthJan != csItem.BudgetLC || item.ThisFiscalMonthJan != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthJan != csItem.TotalLC || item.ThisFiscalMonthJan != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthJan;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJan;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthJan;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthJan;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthFeb == null)
                        item.ThisFiscalMonthFeb = 0;

                     fiscalPeriod = "Feb-" + thisYear.ToString().Substring(2, 2);
                     year = thisYear;
                     budget = item.ThisFiscalMonthFeb.GetValueOrDefault(0);
                     quarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                     accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                     cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);


                    if (item.ThisFiscalMonthFeb != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthFeb;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthFeb;
                            currStartAdd.FiscalPeriod = "Feb-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {

                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthFeb != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthFeb != csItem.BudgetLC || item.ThisFiscalMonthFeb != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthFeb != csItem.TotalLC || item.ThisFiscalMonthFeb != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthFeb;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthFeb;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthFeb;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthFeb;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthFeb;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthFeb;
                                        currStartAdd.FiscalPeriod = "Feb-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.POLineDescription == item.POLineDescription &&
                                    csItem.SupplierName == item.SupplierName )
                                {
                                    if (item.ThisFiscalMonthFeb != csItem.BudgetLC || item.ThisFiscalMonthFeb != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthFeb != csItem.TotalLC || item.ThisFiscalMonthFeb != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthFeb;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthFeb;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthFeb;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthFeb;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthMar == null)
                        item.ThisFiscalMonthMar = 0;

                     fiscalPeriod = "Mar-" + thisYear.ToString().Substring(2, 2);
                     year = thisYear;
                     budget = item.ThisFiscalMonthMar.GetValueOrDefault(0);
                     quarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                     accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                     cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);
                     
                    if (item.ThisFiscalMonthMar != 0)
                    {
                        if(cStart == null)
                        { 
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthMar;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthMar;
                            currStartAdd.FiscalPeriod = "Mar-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;
                            
                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p=> p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthMar != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthMar != csItem.BudgetLC || item.ThisFiscalMonthMar != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthMar != csItem.TotalLC || item.ThisFiscalMonthMar != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthMar;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthMar;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthMar;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthMar;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthMar;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthMar;
                                        currStartAdd.FiscalPeriod = "Mar-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q1-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        //TODO: find out why it loops twice
                        if (cStart != null && cStart.Count() > 0)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthMar != csItem.BudgetLC || item.ThisFiscalMonthMar != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthMar != csItem.TotalLC || item.ThisFiscalMonthMar != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthMar;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthMar;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthMar;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthMar;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthApr == null)
                        item.ThisFiscalMonthApr = 0;

                     fiscalPeriod = "Apr-" + thisYear.ToString().Substring(2, 2);
                     year = thisYear;
                     budget = item.ThisFiscalMonthApr.GetValueOrDefault(0);
                     quarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                     accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                     cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthApr != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthApr;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthApr;
                            currStartAdd.FiscalPeriod = "Apr-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthApr != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthApr != csItem.BudgetLC || item.ThisFiscalMonthApr != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthApr != csItem.TotalLC || item.ThisFiscalMonthApr != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthApr;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthApr;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthApr;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthApr;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthApr;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthApr;
                                        currStartAdd.FiscalPeriod = "Apr-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthApr != csItem.BudgetLC || item.ThisFiscalMonthApr != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthApr != csItem.TotalLC || item.ThisFiscalMonthApr != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthApr;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthApr;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthApr;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthApr;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }
                    if (item.ThisFiscalMonthMay == null)
                        item.ThisFiscalMonthMay = 0;

                     fiscalPeriod = "May-" + thisYear.ToString().Substring(2, 2);
                     year = thisYear;
                     budget = item.ThisFiscalMonthMay.GetValueOrDefault(0);
                     quarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                     accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                     cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthMay != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthMay;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthMay;
                            currStartAdd.FiscalPeriod = "May-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthMay != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthMay != csItem.BudgetLC || item.ThisFiscalMonthMay != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthMay != csItem.TotalLC || item.ThisFiscalMonthMay != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthMay;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthMay;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthMay;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthMay;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthMay;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthMay;
                                        currStartAdd.FiscalPeriod = "May-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                       
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthMay != csItem.BudgetLC || item.ThisFiscalMonthMay != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthMay != csItem.TotalLC || item.ThisFiscalMonthMay != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthMay;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthMay;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthMay;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthMay;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthJun == null)
                        item.ThisFiscalMonthJun = 0;

                     fiscalPeriod = "Jun-" + thisYear.ToString().Substring(2, 2);
                     year = thisYear;
                     budget = item.ThisFiscalMonthJun.GetValueOrDefault(0);
                     quarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                     accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                     cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthJun != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthJun;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthJun;
                            currStartAdd.FiscalPeriod = "Jun-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthJun != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthJun != csItem.BudgetLC || item.ThisFiscalMonthJun != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthJun != csItem.TotalLC || item.ThisFiscalMonthJun != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthJun;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJun;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthJun;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthJun;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthJun;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthJun;
                                        currStartAdd.FiscalPeriod = "Jun-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q2-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthJun != csItem.BudgetLC || item.ThisFiscalMonthJun != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthJun != csItem.TotalLC || item.ThisFiscalMonthJun != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthJun;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJun;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthJun;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthJun;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthJul == null)
                        item.ThisFiscalMonthJul = 0;

                     fiscalPeriod = "Jul-" + thisYear.ToString().Substring(2, 2);
                     year = thisYear;
                     budget = item.ThisFiscalMonthJul.GetValueOrDefault(0);
                     quarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                     accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                     cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthJul != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthJul;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthJul;
                            currStartAdd.FiscalPeriod = "Jul-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthJul != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthJul != csItem.BudgetLC || item.ThisFiscalMonthJul != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthJul != csItem.TotalLC || item.ThisFiscalMonthJul != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthJul;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJul;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthJul;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthJul;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthJul;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthJul;
                                        currStartAdd.FiscalPeriod = "Jul-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthJul != csItem.BudgetLC || item.ThisFiscalMonthJul != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthJul != csItem.TotalLC || item.ThisFiscalMonthJul != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthJul;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthJul;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthJul;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthJul;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthAug == null)
                        item.ThisFiscalMonthAug = 0;

                    fiscalPeriod = "Aug-" + thisYear.ToString().Substring(2, 2);
                    year = thisYear;
                    budget = item.ThisFiscalMonthAug.GetValueOrDefault(0);
                    quarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthAug != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthAug;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthAug;
                            currStartAdd.FiscalPeriod = "Aug-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthAug != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthAug != csItem.BudgetLC || item.ThisFiscalMonthAug != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthAug != csItem.TotalLC || item.ThisFiscalMonthAug != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthAug;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthAug;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthAug;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthAug;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthAug;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthAug;
                                        currStartAdd.FiscalPeriod = "Aug-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {

                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthAug != csItem.BudgetLC || item.ThisFiscalMonthAug != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthAug != csItem.TotalLC || item.ThisFiscalMonthAug != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthAug;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthAug;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthAug;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthAug;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthSep == null)
                        item.ThisFiscalMonthSep = 0;

                    fiscalPeriod = "Sep-" + thisYear.ToString().Substring(2, 2);
                    year = thisYear;
                    budget = item.ThisFiscalMonthSep.GetValueOrDefault(0);
                    quarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthSep != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthSep;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthSep;
                            currStartAdd.FiscalPeriod = "Sep-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthSep != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthSep != csItem.BudgetLC || item.ThisFiscalMonthSep != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthSep != csItem.TotalLC || item.ThisFiscalMonthSep != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthSep;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthSep;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthSep;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthSep;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthSep;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthSep;
                                        currStartAdd.FiscalPeriod = "Sep-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q3-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                         
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthSep != csItem.BudgetLC || item.ThisFiscalMonthSep != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthSep != csItem.TotalLC || item.ThisFiscalMonthSep != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthSep;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthSep;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthSep;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthSep;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthOct == null)
                        item.ThisFiscalMonthOct = 0;

                    fiscalPeriod = "Oct-" + thisYear.ToString().Substring(2, 2);
                    year = thisYear;
                    budget = item.ThisFiscalMonthOct.GetValueOrDefault(0);
                    quarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthOct != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthOct;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthOct;
                            currStartAdd.FiscalPeriod = "Oct-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthOct != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthOct != csItem.BudgetLC || item.ThisFiscalMonthOct != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthOct != csItem.TotalLC || item.ThisFiscalMonthOct != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthOct;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthOct;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthOct;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthOct;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthOct;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthOct;
                                        currStartAdd.FiscalPeriod = "Oct-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
 
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthOct != csItem.BudgetLC || item.ThisFiscalMonthOct != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthOct != csItem.TotalLC || item.ThisFiscalMonthOct != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthOct;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthOct;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthOct;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthOct;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthNov == null)
                        item.ThisFiscalMonthNov = 0;

                    fiscalPeriod = "Nov-" + thisYear.ToString().Substring(2, 2);
                    year = thisYear;
                    budget = item.ThisFiscalMonthNov.GetValueOrDefault(0);
                    quarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthNov != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthNov;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthNov;
                            currStartAdd.FiscalPeriod = "Nov-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthNov != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthNov != csItem.BudgetLC || item.ThisFiscalMonthNov != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthNov != csItem.TotalLC || item.ThisFiscalMonthNov != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthNov;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthNov;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthNov;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthNov;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthNov;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthNov;
                                        currStartAdd.FiscalPeriod = "Nov-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {

                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthNov != csItem.BudgetLC || item.ThisFiscalMonthNov != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthNov != csItem.TotalLC || item.ThisFiscalMonthNov != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthNov;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthNov;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthNov;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthNov;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.ThisFiscalMonthDec == null)
                        item.ThisFiscalMonthDec = 0;

                    fiscalPeriod = "Dec-" + thisYear.ToString().Substring(2, 2);
                    year = thisYear;
                    budget = item.ThisFiscalMonthDec.GetValueOrDefault(0);
                    quarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.ThisFiscalMonthDec != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = thisYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthDec;
                            currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthDec;
                            currStartAdd.FiscalPeriod = "Dec-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.ThisFiscalMonthDec != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.ThisFiscalMonthDec != csItem.BudgetLC || item.ThisFiscalMonthDec != csItem.BudgetUSD ||
                                            item.ThisFiscalMonthDec != csItem.TotalLC || item.ThisFiscalMonthDec != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.ThisFiscalMonthDec;
                                            csItem.BudgetUSD = (decimal)item.ThisFiscalMonthDec;
                                            csItem.TotalLC = (decimal)item.ThisFiscalMonthDec;
                                            csItem.TotalUSD = (decimal)item.ThisFiscalMonthDec;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = thisYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.ThisFiscalMonthDec;
                                        currStartAdd.BudgetUSD = (decimal)item.ThisFiscalMonthDec;
                                        currStartAdd.FiscalPeriod = "Dec-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q4-" + thisYear.ToString().Substring(thisYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {

                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.ThisFiscalMonthDec != csItem.BudgetLC || item.ThisFiscalMonthDec != csItem.BudgetUSD ||
                                        item.ThisFiscalMonthDec != csItem.TotalLC || item.ThisFiscalMonthDec != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.ThisFiscalMonthDec;
                                        csItem.BudgetUSD = (decimal)item.ThisFiscalMonthDec;
                                        csItem.TotalLC = (decimal)item.ThisFiscalMonthDec;
                                        csItem.TotalUSD = (decimal)item.ThisFiscalMonthDec;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    if (item.NextFiscalMonthJan == null)
                        item.NextFiscalMonthJan = 0;

                    fiscalPeriod = "Jan-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.NextFiscalMonthJan != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = DateTime.Now.Year.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthJan;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthJan;
                            currStartAdd.FiscalPeriod = "Jan-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthJan != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthJan != csItem.BudgetLC || item.NextFiscalMonthJan != csItem.BudgetUSD ||
                                            item.NextFiscalMonthJan != csItem.TotalLC || item.NextFiscalMonthJan != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthJan;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthJan;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthJan;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthJan;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = DateTime.Now.Year.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthJan;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthJan;
                                        currStartAdd.FiscalPeriod = "Jan-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthJan != csItem.BudgetLC || item.NextFiscalMonthJan != csItem.BudgetUSD ||
                                        item.NextFiscalMonthJan != csItem.TotalLC || item.NextFiscalMonthJan != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthJan;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthJan;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthJan;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthJan;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthFeb == null)
                        item.NextFiscalMonthFeb = 0;

                    fiscalPeriod = "Feb-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.NextFiscalMonthFeb != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthFeb;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthFeb;
                            currStartAdd.FiscalPeriod = "Feb-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthFeb != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthFeb != csItem.BudgetLC || item.NextFiscalMonthFeb != csItem.BudgetUSD ||
                                            item.NextFiscalMonthFeb != csItem.TotalLC || item.NextFiscalMonthFeb != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthFeb;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthFeb;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthFeb;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthFeb;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthFeb;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthFeb;
                                        currStartAdd.FiscalPeriod = "Feb-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthFeb != csItem.BudgetLC || item.NextFiscalMonthFeb != csItem.BudgetUSD ||
                                        item.NextFiscalMonthFeb != csItem.TotalLC || item.NextFiscalMonthFeb != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthFeb;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthFeb;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthFeb;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthFeb;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthMar == null)
                        item.NextFiscalMonthMar = 0;

                    fiscalPeriod = "Mar-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.NextFiscalMonthMar != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthMar;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthMar;
                            currStartAdd.FiscalPeriod = "Mar-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthMar != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthMar != csItem.BudgetLC || item.NextFiscalMonthMar != csItem.BudgetUSD ||
                                            item.NextFiscalMonthMar != csItem.TotalLC || item.NextFiscalMonthMar != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthMar;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthMar;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthMar;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthMar;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthMar;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthMar;

                                        currStartAdd.TotalLC = (decimal)item.NextFiscalMonthMar;
                                        currStartAdd.TotalUSD = (decimal)item.NextFiscalMonthMar;

                                        currStartAdd.FiscalPeriod = "Mar-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q1-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthMar != csItem.BudgetLC || item.NextFiscalMonthMar != csItem.BudgetUSD ||
                                        item.NextFiscalMonthMar != csItem.TotalLC || item.NextFiscalMonthMar != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthMar;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthMar;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthMar;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthMar;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthApr == null)
                        item.NextFiscalMonthApr = 0;

                    fiscalPeriod = "Apr-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);


                    if (item.NextFiscalMonthApr != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthApr;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthApr;
                            currStartAdd.FiscalPeriod = "Apr-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthApr != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthApr != csItem.BudgetLC || item.NextFiscalMonthApr != csItem.BudgetUSD ||
                                            item.NextFiscalMonthApr != csItem.TotalLC || item.NextFiscalMonthApr != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthApr;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthApr;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthApr;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthApr;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthApr;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthApr;
                                        currStartAdd.FiscalPeriod = "Apr-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthApr != csItem.BudgetLC || item.NextFiscalMonthApr != csItem.BudgetUSD ||
                                        item.NextFiscalMonthApr != csItem.TotalLC || item.NextFiscalMonthApr != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthApr;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthApr;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthApr;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthApr;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthMay == null)
                        item.NextFiscalMonthMay = 0;

                    fiscalPeriod = "May-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);


                    if (item.NextFiscalMonthMay != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthMay;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthMay;
                            currStartAdd.FiscalPeriod = "May-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthMay != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthMay != csItem.BudgetLC || item.NextFiscalMonthMay != csItem.BudgetUSD ||
                                            item.NextFiscalMonthMay != csItem.TotalLC || item.NextFiscalMonthMay != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthMay;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthMay;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthMay;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthMay;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthMay;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthMay;
                                        currStartAdd.FiscalPeriod = "May-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthMay != csItem.BudgetLC || item.NextFiscalMonthMay != csItem.BudgetUSD ||
                                        item.NextFiscalMonthMay != csItem.TotalLC || item.NextFiscalMonthMay != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthMay;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthMay;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthMay;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthMay;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthJun == null)
                        item.NextFiscalMonthJun = 0;

                    fiscalPeriod = "Jun-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.NextFiscalMonthJun != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthJun;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthJun;
                            currStartAdd.FiscalPeriod = "Jun-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthJun != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthJun != csItem.BudgetLC || item.NextFiscalMonthJun != csItem.BudgetUSD ||
                                            item.NextFiscalMonthJun != csItem.TotalLC || item.NextFiscalMonthJun != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthJun;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthJun;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthJun;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthJun;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthJun;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthJun;
                                        currStartAdd.FiscalPeriod = "Jun-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q2-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthJun != csItem.BudgetLC || item.NextFiscalMonthJun != csItem.BudgetUSD ||
                                        item.NextFiscalMonthJun != csItem.TotalLC || item.NextFiscalMonthJun != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthJun;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthJun;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthJun;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthJun;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthJul == null)
                        item.NextFiscalMonthJul = 0;

                    fiscalPeriod = "Jul-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);


                    if (item.NextFiscalMonthJul != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthJul;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthJul;
                            currStartAdd.FiscalPeriod = "Jul-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthJul != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthJul != csItem.BudgetLC || item.NextFiscalMonthJul != csItem.BudgetUSD ||
                                            item.NextFiscalMonthJul != csItem.TotalLC || item.NextFiscalMonthJul != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthJul;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthJul;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthJul;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthJul;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthJul;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthJul;
                                        currStartAdd.FiscalPeriod = "Jul-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthJul != csItem.BudgetLC || item.NextFiscalMonthJul != csItem.BudgetUSD ||
                                        item.NextFiscalMonthJul != csItem.TotalLC || item.NextFiscalMonthJul != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthJul;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthJul;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthJul;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthJul;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthAug == null)
                        item.NextFiscalMonthAug = 0;

                    fiscalPeriod = "Aug-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.NextFiscalMonthAug != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthAug;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthAug;
                            currStartAdd.FiscalPeriod = "Aug-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthAug != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthAug != csItem.BudgetLC || item.NextFiscalMonthAug != csItem.BudgetUSD ||
                                            item.NextFiscalMonthAug != csItem.TotalLC || item.NextFiscalMonthAug != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthAug;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthAug;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthAug;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthAug;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthAug;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthAug;
                                        currStartAdd.FiscalPeriod = "Aug-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthAug != csItem.BudgetLC || item.NextFiscalMonthAug != csItem.BudgetUSD ||
                                        item.NextFiscalMonthAug != csItem.TotalLC || item.NextFiscalMonthAug != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthAug;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthAug;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthAug;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthAug;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthSep == null)
                        item.NextFiscalMonthSep = 0;

                    fiscalPeriod = "Sep-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.NextFiscalMonthSep != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthSep;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthSep;
                            currStartAdd.FiscalPeriod = "Sep-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthSep != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthSep != csItem.BudgetLC || item.NextFiscalMonthSep != csItem.BudgetUSD ||
                                            item.NextFiscalMonthSep != csItem.TotalLC || item.NextFiscalMonthSep != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthSep;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthSep;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthSep;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthSep;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthSep;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthSep;
                                        currStartAdd.FiscalPeriod = "Sep-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q3-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthSep != csItem.BudgetLC || item.NextFiscalMonthSep != csItem.BudgetUSD ||
                                        item.NextFiscalMonthSep != csItem.TotalLC || item.NextFiscalMonthSep != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthSep;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthSep;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthSep;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthSep;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    fiscalPeriod = "Oct-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.NextFiscalMonthOct == null)
                        item.NextFiscalMonthOct = 0;

                    if (item.NextFiscalMonthOct != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthOct;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthOct;
                            currStartAdd.FiscalPeriod = "Oct-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthOct != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthOct != csItem.BudgetLC || item.NextFiscalMonthOct != csItem.BudgetUSD ||
                                            item.NextFiscalMonthOct != csItem.TotalLC || item.NextFiscalMonthOct != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthOct;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthOct;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthOct;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthOct;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthOct;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthOct;
                                        currStartAdd.FiscalPeriod = "Oct-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthOct != csItem.BudgetLC || item.NextFiscalMonthOct != csItem.BudgetUSD ||
                                        item.NextFiscalMonthOct != csItem.TotalLC || item.NextFiscalMonthOct != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthOct;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthOct;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthOct;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthOct;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthNov == null)
                        item.NextFiscalMonthNov = 0;

                    fiscalPeriod = "Nov-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;
                    quarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.NextFiscalMonthNov != 0)
                    {
                        if (cStart == null)
                        {
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthNov;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthNov;
                            currStartAdd.FiscalPeriod = "Nov-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthNov != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthNov != csItem.BudgetLC || item.NextFiscalMonthNov != csItem.BudgetUSD ||
                                            item.NextFiscalMonthNov != csItem.TotalLC || item.NextFiscalMonthNov != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthNov;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthNov;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthNov;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthNov;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthNov;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthNov;
                                        currStartAdd.FiscalPeriod = "Nov-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthNov != csItem.BudgetLC || item.NextFiscalMonthNov != csItem.BudgetUSD ||
                                        item.NextFiscalMonthNov != csItem.TotalLC || item.NextFiscalMonthNov != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthNov;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthNov;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthNov;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthNov;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }

                    if (item.NextFiscalMonthDec == null)
                        item.NextFiscalMonthDec = 0;

                    fiscalPeriod = "Dec-" + nextYear.ToString().Substring(2, 2);
                    year = nextYear;                    
                    quarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                    accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                    cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);

                    if (item.NextFiscalMonthDec != 0)
                    {
                        if(cStart == null)
                        { 
                            currStartAdd.FiscalYear = nextYear.ToString();
                            currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthDec;
                            currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthDec;
                            currStartAdd.FiscalPeriod = "Dec-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                            if (item.VarianceComments != null && item.VarianceComments != " ")
                            {
                                currStartAdd.VarianceComments = item.VarianceComments;
                            }
                            _rentData.AddCurrentStart(currStartAdd);
                            SaveData();
                            currStartAdd = GetNewCurrentStart(currStart);
                            currStartAdd.SupplierName = item.SupplierName;
                        }
                        else
                        {
                            decimal total = 0;

                            if (cStart.Count() > 0)
                            {
                                total = cStart.Where(p => p.POLineDescription == item.POLineDescription)
                                              .Sum(t => t.BudgetUSD);

                                //TODO: find out which one to add to
                                if (item.NextFiscalMonthDec != total)
                                {
                                    if (total != 0)
                                    {
                                        foreach (var tempCS in cStart)
                                        {
                                            tempCS.BudgetLC = 0;
                                            tempCS.BudgetUSD = 0;
                                            tempCS.TotalLC = 0;
                                            tempCS.TotalUSD = 0;
                                            SaveData();
                                        }
                                    }
                                    var csItem = cStart.FirstOrDefault(c => (c.POLineDescription == item.POLineDescription) &&
                                                                      (c.SupplierName == item.SupplierName));

                                    if (csItem != null)
                                    {
                                        if (item.NextFiscalMonthDec != csItem.BudgetLC || item.NextFiscalMonthDec != csItem.BudgetUSD ||
                                            item.NextFiscalMonthDec != csItem.TotalLC || item.NextFiscalMonthDec != csItem.TotalUSD)
                                        {
                                            csItem.BudgetLC = (decimal)item.NextFiscalMonthDec;
                                            csItem.BudgetUSD = (decimal)item.NextFiscalMonthDec;
                                            csItem.TotalLC = (decimal)item.NextFiscalMonthDec;
                                            csItem.TotalUSD = (decimal)item.NextFiscalMonthDec;
                                        }
                                        if (item.VarianceComments != csItem.VarianceComments)
                                        {
                                            if (item.VarianceComments != " " && item.VarianceComments != "0")
                                                csItem.VarianceComments = item.VarianceComments;

                                        }
                                        SaveData();
                                    }
                                    else
                                    {
                                        currStartAdd.FiscalYear = nextYear.ToString();
                                        currStartAdd.BudgetLC = (decimal)item.NextFiscalMonthDec;
                                        currStartAdd.BudgetUSD = (decimal)item.NextFiscalMonthDec;
                                        currStartAdd.FiscalPeriod = "Dec-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        currStartAdd.FiscalQuarter = "Q4-" + nextYear.ToString().Substring(nextYear.ToString().Length - 2);
                                        if (item.VarianceComments != null && item.VarianceComments != " ")
                                        {
                                            currStartAdd.VarianceComments = item.VarianceComments;
                                        }
                                        _rentData.AddCurrentStart(currStartAdd);
                                        SaveData();
                                        currStartAdd = GetNewCurrentStart(currStart);
                                        currStartAdd.SupplierName = item.SupplierName;
                                    }

                                }
                            }

                        }
                    }
                    else
                    {
                        if (cStart != null)
                        {
                            foreach (var csItem in cStart)
                            {
                                if (csItem.SupplierName == item.SupplierName &&
                                    csItem.POLineDescription == item.POLineDescription)
                                {
                                    if (item.NextFiscalMonthDec != csItem.BudgetLC || item.NextFiscalMonthDec != csItem.BudgetUSD ||
                                        item.NextFiscalMonthDec != csItem.TotalLC || item.NextFiscalMonthDec != csItem.TotalUSD)
                                    {
                                        csItem.BudgetLC = (decimal)item.NextFiscalMonthDec;
                                        csItem.BudgetUSD = (decimal)item.NextFiscalMonthDec;
                                        csItem.TotalLC = (decimal)item.NextFiscalMonthDec;
                                        csItem.TotalUSD = (decimal)item.NextFiscalMonthDec;
                                        SaveData();
                                    }
                                }
                            }
                        }
                    }                    
                }

                return new JsonResult(currStartAdd);

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            return Ok();

        }

        private void ZeroSums(string month, int year, RentsViewModel item)
        {

                var fiscalPeriod = "May-" + year.ToString().Substring(2, 2);
                
                var budget = item.ThisFiscalMonthApr.GetValueOrDefault(0);
                var quarter = "Q2-" + year.ToString().Substring(year.ToString().Length - 2);
                var accountNum = int.Parse(item.NaturalAccountNumber.Split("_")[1].ToString());

                var cStart = _rentData.GetByFiscalPeriod(fiscalPeriod, accountNum, item.POLineDescription, item.SupplierName);
                if (cStart != null)
                {
                    foreach (var csItem in cStart)
                    {
                        if (csItem.POLineDescription == item.POLineDescription &&
                            csItem.SupplierName == item.SupplierName &&
                            csItem.NaturalAccountName == item.NaturalAccountName)
                        {
                            //The break down...
                            if (item.ThisFiscalMonthMay != csItem.BudgetLC || item.ThisFiscalMonthMay != csItem.BudgetUSD ||
                                item.ThisFiscalMonthMay != csItem.TotalLC || item.ThisFiscalMonthMay != csItem.TotalUSD)
                            {
                                
                                csItem.BudgetLC = (decimal)item.ThisFiscalMonthMay;
                                csItem.BudgetUSD = (decimal)item.ThisFiscalMonthMay;
                                csItem.TotalLC = (decimal)item.ThisFiscalMonthMay;
                                csItem.TotalUSD = (decimal)item.ThisFiscalMonthMay;
                                SaveData();
                            }
                        }
                    }
                }
            
        }
        private CurrentStart GetNewCurrentStart(CurrentStart currStart)
        {

            var currStartAdd = new CurrentStart()
            {
                ProjectName = currStart.ProjectName,
                Scenario = "SEPLE",
                POLineDescription = currStart.POLineDescription,
                DepartmentNameNum = currStart.DepartmentNameNum,
                BudgetUSD_1 = currStart.BudgetUSD_1,
                BudgetLC_1 = currStart.BudgetLC_1,
                Comments = currStart.Comments,

                DepartmentName = currStart.DepartmentName,
                DepartmentNumber = currStart.DepartmentNumber,
                DepartmentGroup = currStart.DepartmentGroup,
                DepartmentSubGroup = currStart.DepartmentSubGroup,
                CostCenterNumber = currStart.CostCenterNumber,

                AccountGroup = currStart.AccountGroup,
                AccountNumber = currStart.AccountNumber,
                NaturalAccountName = currStart.NaturalAccountName,
                ProjectTaskNumber = currStart.ProjectTaskNumber,
                PONumber = currStart.PONumber,

                SupplierNumber = currStart.SupplierNumber,
                PurchaseInvoiceNumber = currStart.PurchaseInvoiceNumber,
                ActualUSD = 0,
                CountryCity = currStart.CountryCity,
                Region = currStart.Region,
                Region_Rpt = currStart.Region_Rpt,
                FPAAccrualsReclasses = currStart.FPAAccrualsReclasses,
                SupplierType = currStart.SupplierType,
                FiscalDate = Convert.ToInt32(DateTime.Now.ToOADate()).ToString(),
                LocalCurrency = currStart.LocalCurrency,
                OriginalSupplierName = currStart.OriginalSupplierName,
                DepartmentRollOut = currStart.DepartmentRollOut,
                UniqueListACC = currStart.UniqueListACC,
                UniqueListDEPT = currStart.UniqueListDEPT,

            };

            return currStartAdd;
        }
        [HttpGet()]
        public IActionResult GetCurrentStartHyperion(string departmentId)
        {
            //var currentStarts = _rentData.GetCurrentStartRents(departmentId);
            //var priorFcsts = _rentData.GetPriorForecastRents(departmentId);

            var currentStarts = _rentData.ReadRentForecast(departmentId);
            var priorFcsts = _rentData.ReadPriorForecastRents(departmentId);

            var startYear = int.Parse(_prefsData.GetStartYear());

            var lastYear = (startYear - 1);
            var thisYear = (startYear);
            var nextYear = (startYear + 1);
            var yearAfterNext = (startYear + 2);

            //var lastPFTotals = priorFcsts
            //    .Where(p => p.FiscalYear == lastYear.ToString())
            //    .Select(g => g.TotalLC);

            //var thisPFTotals = priorFcsts
            //    .Where(p => p.FiscalYear == thisYear.ToString() )
            //    .Select(g => g.TotalLC); //.Sum(g => g.TotalLC);

            //var nextPFTotals = priorFcsts
            //        .Where(p => p.FiscalYear == nextYear.ToString())
            //        .Select(g => g.TotalLC);


            //var yanPFTotals = priorFcsts
            //        .Where(p => p.FiscalYear == yearAfterNext.ToString())
            //        .Select(g => g.TotalLC);

            var supplierList = currentStarts.Select(supplier => new ExportTableViewModel
            {
                AccountGroup = supplier.AccountGroup.Split("-")[0],
                DepartmentNameNum = supplier.DepartmentNameNum,

                ///////////////////////this year/////////////////////////////////////////////
                ThisFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                ThisFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == thisYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                /////////////////////////////////////next year///////////////////////////////////////////
                NextFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                NextFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == nextYear.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                //////////////////////////////////YAN////////////////////////////////////////////////////////////////////
                YANFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,

                YANYFiscalMonthJan = supplier.FiscalPeriod.Substring(0, 3) == "Jan" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthFeb = supplier.FiscalPeriod.Substring(0, 3) == "Feb" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthMar = supplier.FiscalPeriod.Substring(0, 3) == "Mar" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthApr = supplier.FiscalPeriod.Substring(0, 3) == "Apr" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthMay = supplier.FiscalPeriod.Substring(0, 3) == "May" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthJun = supplier.FiscalPeriod.Substring(0, 3) == "Jun" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthJul = supplier.FiscalPeriod.Substring(0, 3) == "Jul" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthAug = supplier.FiscalPeriod.Substring(0, 3) == "Aug" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthSep = supplier.FiscalPeriod.Substring(0, 3) == "Sep" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthOct = supplier.FiscalPeriod.Substring(0, 3) == "Oct" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthNov = supplier.FiscalPeriod.Substring(0, 3) == "Nov" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0,
                YANYFiscalMonthDec = supplier.FiscalPeriod.Substring(0, 3) == "Dec" && supplier.FiscalYear == yearAfterNext.ToString() ? supplier.ActualLC != 0 ? supplier.ActualLC : supplier.BudgetLC : 0


            });

            var highestBy = currentStarts
                .GroupBy(s => s.SupplierName)
                .Select(g => g.OrderByDescending(t => t.BudgetUSD).First())
                .ToList();

            //TODO: get priorforecast and cache it
            //var groupList = supplierList
            //    .GroupBy(s => s.SupplierName)
            //    .ToList();


            //var groupList =
            //    from supplier in supplierList
            //    group supplier by supplier.SupplierName into newGroup
            //    orderby newGroup.Key
            //    select newGroup;

            return new JsonResult(supplierList);
        }

    }
}

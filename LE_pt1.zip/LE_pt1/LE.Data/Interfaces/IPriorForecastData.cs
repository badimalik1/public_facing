﻿using LE.Core;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LE.Data.Interfaces
{
    public interface IPriorForecastData
    {

        int Commit();
        int GetCountOfSuppliers();
        PriorForecast Delete(int id);
        PriorForecast GetById(int id);
        IEnumerable<PriorForecast> GetAll(string dept);

        IEnumerable<PriorForecast>ReadByFiscalPeriod(string dept, string fiscalPeriod);

        IEnumerable<PriorForecast> GetBySuplierName(string supplierName, string departmentId);


    }
}

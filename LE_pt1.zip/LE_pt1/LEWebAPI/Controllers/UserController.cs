﻿using LEWebAPI.Entities;
using LEWebAPI.Services;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEWebAPI.Controllers
{
    [EnableCors("_myAllowSpecificOrigins")]
    [Route("api/user")]
    public class UserController : Controller
    {
        private IUserRepository _userRepository;

        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
           
        }

        public IActionResult GetUser(string username, string password)
        {
            var user = _userRepository.GetUser(username, password);
            return new JsonResult(user);
        }
        [Route("GetDepartments/{Id}")]
        public IActionResult GetDepartments(int Id)
        {
            var departments = _userRepository.GetDepartments(Id);
            return new JsonResult(departments);

        }

    }
}
